# SomeEngine RHI Spec

> Status: final contract naming and semantics.
>
> Scope: DX12 first, API shaped for Vulkan/Metal/WebGPU later.
>
> Rule: anything not decided here is not part of the contract. Do not add placeholder public names.

---

## 1. Reference Baseline

This spec is derived from open-source APIs and implementations, not from ad-hoc naming:

| Reference | What we adopt | What we reject |
|---|---|---|
| wgpu/WebGPU | `BindGroupLayout` / `BindGroup` / `PipelineLayout` separation; dynamic buffer offsets; explicit validation. | WebGPU's restricted feature set as the ceiling. SomeEngine needs DX12 placed resources and render graph integration. |
| The Forge | `DescriptorSet` grouped by update frequency; explicit `Renderer`, `Queue`, `Cmd`, `ResourceState`, `ResourceHeap`; root constants. | C-style pointer API and one big cross-platform header shape. |
| Veldrid | C# `GraphicsDevice`, `CommandList`, `ResourceLayout`, `ResourceSet`, `dynamicOffsets`. | Object-heavy resource sets as the hot-path identity. SomeEngine uses value handles. |
| bgfx | Small value handles; transient per-frame allocation; encoder idea; explicit capabilities. | Draw-submit sorting model. SomeEngine RenderGraph already owns pass order. |
| Granite | Render-graph-driven resource lifetime; descriptor set caching/allocation; explicit Vulkan barriers. | Vulkan-only naming as public API. |
| D3D12MA | Committed/placed/aliasing memory vocabulary and allocator behavior. | Native C++ allocator dependency in the contract. We keep contract allocator in C# because RG lifetime is already known. |
| Silk.NET | C# native API bindings already used by SomeEngine windowing/input; DX12/DXGI packages provide the first backend binding. | Exposing Silk types through public RHI. Silk stays backend-internal. |
| TerraFX | Reference point for direct Windows metadata bindings. | Not used for the contract because the project already carries Silk and the user decision is to standardize the first DX12 backend on Silk. |

Primary source links:

- wgpu `BindGroupLayout`: https://github.com/gfx-rs/wgpu/blob/64698614786dd55c31bce803c2d5217cf84c2b95/wgpu/src/api/bind_group_layout.rs
- wgpu `BindGroup`: https://github.com/gfx-rs/wgpu/blob/64698614786dd55c31bce803c2d5217cf84c2b95/wgpu/src/api/bind_group.rs
- The Forge `IGraphics.h`: https://github.com/ConfettiFX/The-Forge/blob/a00d6d301b9fd01a1edc99f7c4e38996ce1bee0b/Common_3/Graphics/Interfaces/IGraphics.h
- Veldrid API concepts: https://veldrid.dev/articles/api-concepts.html
- Veldrid `CommandList` dynamic resource set offsets: https://veldrid.dev/api/Veldrid.CommandList.html
- bgfx API header: https://github.com/bkaradzic/bgfx/blob/9849fe96cba81355352e5355ee2d333ea70857ac/include/bgfx/bgfx.h
- Granite render graph article: https://themaister.net/blog/2017/08/15/render-graphs-and-vulkan-a-deep-dive/
- D3D12MA repository: https://github.com/GPUOpen-LibrariesAndSDKs/D3D12MemoryAllocator
- TerraFX.Interop.Windows repository: https://github.com/terrafx/terrafx.interop.windows
- Silk.NET.Direct3D12 package: https://www.nuget.org/packages/Silk.NET.Direct3D12

---

## 2. Hard Decisions

### 2.1 Backend binding

DX12 backend binding is selected by SomeEngine integration cost, not by binding-library preference.

Project facts:

- `SomeEngine.Render` and `SomeEngine.Runtime` already reference `Silk.NET.Windowing` and `Silk.NET.Input`.
- The project targets `net10.0` and already allows unsafe code in `SomeEngine.Render`.
- The current pain is Diligent native build / fork / SharpGen mapping, not whether a C# binding is aesthetically closer to C headers.
- Public RHI must not expose Silk, TerraFX, Vortice, Diligent, or native COM types.
- The first implementation is side-by-side. It must not replace Diligent `RenderContext`, RenderGraph execution, materials, or pipeline code until an explicit migration step does so.

DX12 binding decision:

1. `Silk.NET.Direct3D12` plus `Silk.NET.DXGI` is the DX12 backend binding.
2. Silk package versions stay aligned with the repository's existing Silk package family for the first side-by-side slice. A full Silk package upgrade is a separate dependency batch.
3. `TerraFX.Interop.Windows` is rejected for the contract after the Silk decision. Revisit only if a concrete Silk blocker is proven by code.
4. `Vortice.Windows` is rejected for the contract hot-path backend because it is a higher-level COM wrapper style and does not address the “avoid object-model leakage” goal.
5. A native C++ D3D12 wrapper DLL is rejected because it recreates the native build burden that this RHI is meant to remove.

Required DX12 proof sequence:

1. Compile isolated public RHI contracts and the Silk DX12 backend package binding without touching Diligent execution.
2. Create DXGI factory, adapter, D3D12 device, graphics queue, command allocator/list, and fence.
3. Create swapchain from the existing Silk window native handle in a side-by-side smoke app or opt-in path.
4. Create committed buffer and placed buffer/texture.
5. Create CBV/SRV/UAV descriptor heap and RTV/DSV heap.
6. Create root signature, compute PSO, and dispatch one compute shader.
7. Issue resource barriers.
8. Copy to readback and verify bytes.
9. Run under the repo's normal `net10.0` build without adding native build steps.

### 2.1.1 Backend binding matrix

Final backend binding decisions:

| Backend | Status | Binding layer | Decision |
|---|---|---|---|
| DX12 | Implemented first | `Silk.NET.Direct3D12` + `Silk.NET.DXGI` | Final backend binding. Keep Silk backend types internal or backend-namespaced; public RHI exposes only SomeEngine handles/descriptors. |
| Vulkan | Spec-compatible, not current implementation | `Silk.NET.Vulkan` | Reserved as the first non-DX12 native backend. Do not use Vortice or a C++ Vulkan shim for the public backend plan. |
| Metal | Not contract | native Objective-C/C shim or MoltenVK-through-Vulkan | True Metal requires a small native shim because Metal is Objective-C. For early macOS experiments, route through Vulkan/MoltenVK only if accepted as a compatibility path, not as the final Metal backend. |
| WebGPU | Not contract | Dawn `webgpu.h` or `wgpu-native` C API | Compatibility backend only. Do not use it as the baseline RHI because WebGPU cannot express the full DX12/Vulkan placed-resource and descriptor model. |
| D3D11 | Not planned | none | Rejected for the contract and not a fallback target. |
| OpenGL | Not planned | none | Rejected for the contract and not a fallback target. |

Windowing/input is not an RHI backend. SomeEngine may continue using Silk.NET windowing to obtain native window handles, while each backend owns swapchain/surface creation.

Shader compilation is not owned by RHI. The asset pipeline continues to produce backend bytecode through the existing Slang path; RHI consumes `ShaderModuleDesc.Bytecode`.

Memory allocation:

- contract implements the RenderGraph placed-resource allocator in C#.
- D3D12MA remains a reference implementation for committed/placed/aliasing semantics.
- Do not add D3D12MA as a native dependency in the contract unless a later spec revision explicitly accepts native build cost.

### 2.2 Public Naming

Public service objects do not use an `Rhi` prefix. The namespace already carries the API boundary.
GPU resource identities use the `Handle` suffix.

Final service object names:

```csharp
Device
Queue
CommandList
SwapChain
UploadRing
ReadbackRing
```

Implementation namespace:

```csharp
SomeEngine.RHI
```

Rules:

- Existing `SomeEngine.Render.RHI` remains the Diligent execution namespace during coexistence.
- New code must import the top-level `SomeEngine.RHI` namespace explicitly, so descriptor names do not collide with existing Diligent `RenderContext`, RenderGraph execution, or pipeline code by accident.

Final handle names:

```csharp
AdapterHandle
QueueHandle
SwapChainHandle
FenceHandle
ResourceHeapHandle
BufferHandle
TextureHandle
BufferViewHandle
TextureViewHandle
SamplerHandle
ShaderModuleHandle
PipelineLayoutHandle
ComputePipelineHandle
GraphicsPipelineHandle
DescriptorSetLayoutHandle
DescriptorSetHandle
QueryPoolHandle
```

No public type named `Resource`, `GpuResource`, `BindingTable`, `BindingSet`, or `PipelineHandle` is allowed in the contract.

Rationale:

- `DescriptorSet` is selected over `BindGroup` because SomeEngine shader input is Slang/HLSL `register(..., spaceN)`, and `spaceN` maps directly to descriptor set index.
- `DescriptorSetLayout` and `PipelineLayout` match Vulkan/The Forge/WebGPU concepts without exposing Vulkan names.
- Separate `ComputePipelineHandle` and `GraphicsPipelineHandle` make illegal dispatch/draw state harder to express.

### 2.3 Handle representation

Every handle is a blittable readonly value type:

```csharp
public readonly record struct BufferHandle(uint Index, uint Generation);
```

Rules:

- `Index == 0` is invalid for every handle type.
- `Generation == 0` is invalid for every handle type.
- `default(THandle)` is always invalid.
- Backends must validate generation in debug and checked builds.
- Release builds may skip repeated validation inside command recording after `CommandList` recording begins.

Rationale:

- bgfx and Filament both prove typed handles are a durable graphics API pattern.
- C# value handles avoid leaking COM wrapper objects through RenderGraph, Materials, and Pipeline hot paths.

### 2.4 Hot-path dispatch

No public hot-path command method may be an interface call.

Rules:

- `CommandList` is a sealed class.
- the contract ships one backend implementation: DX12.
- Cross-backend polymorphism is allowed at device creation and resource creation boundaries, not per draw/dispatch.
- Later Vulkan/Metal/WebGPU backends must preserve the same public `CommandList` method names.

Rationale:

- This keeps the contract simple and avoids designing a virtual backend abstraction before more than one backend exists.
- Cross-platform is preserved by descriptor structs and semantics, not by per-command interface dispatch.

---

## 3. Descriptor Model

### 3.1 Descriptor set indices

SomeEngine reserves exactly four descriptor set indices:

| Set index | Name | Update frequency | Contents |
|---:|---|---|---|
| 0 | `Global` | persistent | bindless tables, static engine textures, static samplers, blue noise, global LUTs |
| 1 | `Frame` | per frame | camera, frame constants, lighting globals, history handles that are stable for the frame |
| 2 | `Pass` | per RenderGraph pass | transient RG textures/buffers/views, pass UAVs, pass SRVs |
| 3 | `Material` | per material or material group | material textures, material buffers, material parameter tables |

There is no `Draw` or `Dispatch` descriptor set in the contract.

Per-draw/per-dispatch data uses:

- `SetPushConstants(...)` for up to 64 bytes.
- dynamic buffer offsets for larger data.
- upload-ring slices referenced through `Frame`, `Pass`, or `Material` descriptors.

Rationale:

- The Forge validates grouping descriptors by update frequency.
- wgpu/Veldrid validate static layout plus dynamic offset as a portable model.
- SomeEngine's current hot path needs pass/material separation first, not arbitrary set counts.

### 3.2 Binding key

Runtime binding identity is:

```csharp
public readonly record struct DescriptorBindingKey(
    uint Set,
    uint Binding,
    DescriptorType Type,
    ShaderStageFlags Stages);
```

Rules:

- Slang/HLSL `spaceN` maps to `Set == N`.
- Slang/HLSL register index maps to `Binding`.
- Resource name is debug metadata only.
- Duplicate `(Set, Binding, Type)` with incompatible stage masks is invalid.
- Duplicate `(Set, Binding)` with different `DescriptorType` is invalid.

### 3.3 Descriptor types

Final descriptor enum:

```csharp
public enum DescriptorType : byte
{
    ConstantBuffer,
    StructuredBuffer,
    ByteAddressBuffer,
    Texture,
    Sampler,
    ReadWriteStructuredBuffer,
    ReadWriteByteAddressBuffer,
    ReadWriteTexture,
    AccelerationStructure
}
```

Rules:

- `AccelerationStructure` is reserved in layout metadata but the DX12 backend may reject creation until ray tracing is implemented.
- Combined texture/sampler descriptors are not part of the contract. Texture and sampler are separate descriptors.
- Render target and depth-stencil views are not descriptor set entries. They are render pass attachments.

### 3.4 Descriptor set layout

Final type:

```csharp
public readonly record struct DescriptorSetLayoutDesc(
    string? DebugName,
    uint Set,
    ReadOnlyMemory<DescriptorBindingDesc> Bindings);

public readonly record struct DescriptorBindingDesc(
    uint Binding,
    DescriptorType Type,
    ShaderStageFlags Stages,
    uint Count,
    bool HasDynamicOffset,
    string? DebugName);
```

Rules:

- `Count == 0` is invalid.
- `HasDynamicOffset` is valid only for `ConstantBuffer`, `StructuredBuffer`, and `ByteAddressBuffer`.
- Dynamic offsets must obey backend-reported alignment:
  - constant buffer: `Limits.ConstantBufferOffsetAlignment`
  - structured/storage buffer: `Limits.StorageBufferOffsetAlignment`
- Descriptor arrays require explicit `Count > 1`; bindless arrays are represented as descriptor arrays in set `Global`.

### 3.5 Descriptor set

Final update type:

```csharp
public readonly record struct DescriptorWrite(
    uint Binding,
    uint ArrayElement,
    DescriptorValue Value);
```

Final value union shape:

```csharp
public readonly struct DescriptorValue
{
    public DescriptorType Type { get; }
    public BufferViewHandle BufferView { get; }
    public TextureViewHandle TextureView { get; }
    public SamplerHandle Sampler { get; }
}
```

Final device methods:

```csharp
DescriptorSetLayoutHandle CreateDescriptorSetLayout(in DescriptorSetLayoutDesc desc);
void DestroyDescriptorSetLayout(DescriptorSetLayoutHandle layout);
DescriptorSetHandle CreateDescriptorSet(DescriptorSetLayoutHandle layout, string? debugName);
void DestroyDescriptorSet(DescriptorSetHandle set);
void UpdateDescriptorSet(DescriptorSetHandle set, ReadOnlySpan<DescriptorWrite> writes);
```

Rules:

- Updating a descriptor set currently in use by the GPU is invalid unless it was created with `DescriptorSetFlags.AllowUpdateAfterBind`.
- `AllowUpdateAfterBind` is not supported in the contract. Use frame-local descriptor sets or create a new persistent descriptor set.
- Null descriptors are backend-created and used only when the layout explicitly allows missing bindings. default is fail-fast.

### 3.6 Pipeline layout

Final type:

```csharp
public readonly record struct PipelineLayoutDesc(
    string? DebugName,
    ReadOnlyMemory<DescriptorSetLayoutHandle> Sets,
    PushConstantRange PushConstants);

public readonly record struct PushConstantRange(
    ShaderStageFlags Stages,
    ushort SizeInBytes);
```

Rules:

- `PushConstants.SizeInBytes <= 64`.
- Push constant size must be a multiple of 4 bytes.
- Set indices must be contiguous from 0 to the highest used set.
- A pipeline layout cannot reference more than four descriptor set layouts in the contract.

Rationale:

- 64 bytes follows The Forge's `MAX_PUSH_CONSTANTS_32BIT_COUNT = 16` and maps cleanly to DX12 root constants.
- Four set indices match SomeEngine's current update-frequency model.

---

## 4. Resource Model

### 4.1 Memory classes

Final enum:

```csharp
public enum MemoryUsage : byte
{
    GpuOnly,
    CpuToGpu,
    GpuToCpu
}
```

Rules:

- `GpuOnly` maps to DX12 default heap.
- `CpuToGpu` maps to DX12 upload heap and is persistently mapped.
- `GpuToCpu` maps to DX12 readback heap and is persistently mapped.
- There is no `CpuOnly` in the contract.

### 4.2 Resource placement

Final types:

```csharp
public enum ResourcePlacementKind : byte
{
    Committed,
    Placed
}

public readonly record struct ResourcePlacement(
    ResourcePlacementKind Kind,
    MemoryUsage MemoryUsage,
    ResourceHeapHandle Heap,
    ulong HeapOffset);
```

Rules:

- `Committed` requires `Heap == default` and `HeapOffset == 0`.
- `Placed` requires a valid `ResourceHeapHandle`.
- Placed offsets must satisfy `GetTextureMemoryRequirements` or `GetBufferMemoryRequirements`.
- RenderGraph owns placed resource scheduling. General application code should use committed resources unless it is importing an external heap.

### 4.3 Resource heap

Final type:

```csharp
public readonly record struct ResourceHeapDesc(
    string? DebugName,
    MemoryUsage MemoryUsage,
    ulong SizeInBytes,
    ulong Alignment);
```

Final device methods:

```csharp
ResourceHeapHandle CreateResourceHeap(in ResourceHeapDesc desc);
void DestroyResourceHeap(ResourceHeapHandle heap);
```

Rules:

- contract `ResourceHeap` supports only one `MemoryUsage`.
- Mixed buffer/texture heaps are allowed only if `DeviceLimits.AllowBufferTextureInSameHeap` is true.
- RG must split heaps by memory compatibility class when the backend reports incompatibility.

### 4.4 Buffer

Final type:

```csharp
public readonly record struct BufferDesc(
    string? DebugName,
    ulong SizeInBytes,
    BufferUsageFlags Usage,
    ResourcePlacement Placement);
```

Final methods:

```csharp
ResourceMemoryRequirements GetBufferMemoryRequirements(in BufferDesc desc);
BufferHandle CreateBuffer(in BufferDesc desc);
BufferDesc GetBufferDesc(BufferHandle buffer);
void DestroyBuffer(BufferHandle buffer);
```

Final usage flags:

```csharp
[Flags]
public enum BufferUsageFlags : uint
{
    None = 0,
    Vertex = 1u << 0,
    Index = 1u << 1,
    Constant = 1u << 2,
    Structured = 1u << 3,
    ByteAddress = 1u << 4,
    ReadWrite = 1u << 5,
    IndirectArgument = 1u << 6,
    CopySource = 1u << 7,
    CopyDestination = 1u << 8,
    AccelerationStructure = 1u << 9
}
```

### 4.5 Texture

Final type:

```csharp
public readonly record struct TextureDesc(
    string? DebugName,
    TextureDimension Dimension,
    Format Format,
    uint Width,
    uint Height,
    ushort DepthOrArrayLayers,
    ushort MipLevels,
    ushort SampleCount,
    TextureUsageFlags Usage,
    ClearValue ClearValue,
    ResourcePlacement Placement);
```

Final methods:

```csharp
ResourceMemoryRequirements GetTextureMemoryRequirements(in TextureDesc desc);
TextureHandle CreateTexture(in TextureDesc desc);
TextureDesc GetTextureDesc(TextureHandle texture);
void DestroyTexture(TextureHandle texture);
```

Final usage flags:

```csharp
[Flags]
public enum TextureUsageFlags : uint
{
    None = 0,
    ShaderResource = 1u << 0,
    ReadWrite = 1u << 1,
    RenderTarget = 1u << 2,
    DepthStencil = 1u << 3,
    CopySource = 1u << 4,
    CopyDestination = 1u << 5,
    Present = 1u << 6
}
```

### 4.6 Views

Final view methods:

```csharp
BufferViewHandle CreateBufferView(BufferHandle buffer, in BufferViewDesc desc);
TextureViewHandle CreateTextureView(TextureHandle texture, in TextureViewDesc desc);
BufferViewDesc GetBufferViewDesc(BufferViewHandle view);
TextureViewDesc GetTextureViewDesc(TextureViewHandle view);
BufferViewHandle GetDefaultBufferView(BufferHandle buffer, BufferViewKind kind);
TextureViewHandle GetDefaultTextureView(TextureHandle texture, TextureViewKind kind);
void DestroyBufferView(BufferViewHandle view);
void DestroyTextureView(TextureViewHandle view);
```

Rules:

- Views are explicit handles because descriptor identity must be cacheable.
- `BufferViewDesc.Kind` is `ConstantBuffer`, `ShaderResource`, or `UnorderedAccess`.
- `TextureViewDesc.Kind` is `ShaderResource`, `UnorderedAccess`, `RenderTarget`, or `DepthStencil`.
- RenderGraph may cache views by `(resource, view desc)` for frame-owned resources.
- Default views are explicit API because the Diligent path depends on default RTV/DSV/SRV semantics.
- Default view creation is still backend-owned and must be cacheable by `(resource, kind)`.

### 4.7 Sampler

Final methods:

```csharp
SamplerHandle CreateSampler(in SamplerDesc desc);
void DestroySampler(SamplerHandle sampler);
```

Rules:

- Sampler identity is a handle, not a descriptor name.
- Immutable/static samplers may be compiled into `PipelineLayout`; material/runtime samplers use `SamplerHandle`.
- DX12 backend maps sampler handles to the sampler descriptor heap and validates filter/address/compare combinations.

---

## 5. Command Model

### 5.1 Presentation, fences, and query pools

Final device methods:

```csharp
SwapChainHandle CreateSwapChain(Queue queue, in SwapChainDesc desc);
SwapChainDesc GetSwapChainDesc(SwapChainHandle swapChain);
void ResizeSwapChain(SwapChainHandle swapChain, uint width, uint height);
uint GetCurrentBackBufferIndex(SwapChainHandle swapChain);
TextureHandle GetSwapChainBackBuffer(SwapChainHandle swapChain, uint index);
TextureViewHandle GetSwapChainBackBufferView(SwapChainHandle swapChain, uint index);
TextureHandle GetCurrentBackBuffer(SwapChainHandle swapChain);
TextureViewHandle GetCurrentBackBufferView(SwapChainHandle swapChain);
void Present(SwapChainHandle swapChain, in PresentOptions options);
void DestroySwapChain(SwapChainHandle swapChain);

FenceHandle CreateFence(in FenceDesc desc);
ulong GetFenceCompletedValue(FenceHandle fence);
void WaitForFence(FenceHandle fence, ulong value, TimeSpan? timeout = null);
void DestroyFence(FenceHandle fence);
void SignalFence(Queue queue, FenceHandle fence, ulong value);
void WaitIdle(Queue queue);
void WaitIdle();

QueryPoolHandle CreateQueryPool(in QueryPoolDesc desc);
void DestroyQueryPool(QueryPoolHandle queryPool);
ulong GetTimestampFrequency(Queue queue);
```

Rules:

- Swapchain resources are exposed as texture/view handles so RenderGraph can import the back buffer without special Diligent objects.
- Fence values are caller-visible and monotonic per fence.
- Query pools are explicit to match DX12/Vulkan and avoid one-object-per-query allocation in frame code.
- `PresentOptions` carries sync interval, tearing permission, and test-only present mode.
- `GetCurrentBackBuffer*` is a convenience over `GetCurrentBackBufferIndex` plus indexed backbuffer access.

### 5.2 Command list lifecycle

Final methods:

```csharp
Queue GetQueue(QueueKind kind);
CommandList BeginCommandList(Queue queue, string? debugName);
void EndCommandList(CommandList commandList);
void Submit(Queue queue, CommandList commandList, FenceHandle signalFence, ulong signalValue);
```

Rules:

- A command list is single-use in the contract.
- Reuse requires explicit reset through the owning queue allocator and is backend internal.
- Recording after `EndCommandList` is invalid.
- `signalValue` is explicit; the API never hides fence value allocation inside `Submit`.

### 5.3 Pipeline and descriptor binding

Final command methods:

```csharp
void SetComputePipeline(ComputePipelineHandle pipeline);
void SetGraphicsPipeline(GraphicsPipelineHandle pipeline);
void SetDescriptorSet(uint setIndex, DescriptorSetHandle descriptorSet, ReadOnlySpan<uint> dynamicOffsets);
void SetPushConstants(ShaderStageFlags stages, ushort offsetInBytes, ReadOnlySpan<uint> values);
void SetViewport(in Viewport viewport);
void SetScissorRect(in ScissorRect rect);
void SetViewports(ReadOnlySpan<Viewport> viewports);
void SetScissorRects(ReadOnlySpan<ScissorRect> rects);
void SetBlendConstants(float r, float g, float b, float a);
void SetStencilReference(uint reference);
void PushDebugGroup(string name);
void PopDebugGroup();
void InsertDebugMarker(string name);
```

Rules:

- `SetDescriptorSet` validates the set layout against the current pipeline layout in debug builds.
- `dynamicOffsets.Length` must match the number of dynamic bindings in that descriptor set layout.
- Push constants must be set after pipeline binding and before dispatch/draw that consumes them.

### 5.4 Dispatch and draw

Final command methods:

```csharp
void Dispatch(uint groupCountX, uint groupCountY, uint groupCountZ);
void DispatchIndirect(BufferHandle argumentBuffer, ulong byteOffset);

void SetVertexBuffer(uint slot, BufferHandle buffer, ulong offset, uint stride);
void SetVertexBuffers(uint firstSlot, ReadOnlySpan<VertexBufferBinding> bindings);
void SetIndexBuffer(BufferHandle buffer, ulong offset, IndexFormat format);
void Draw(uint vertexCount, uint instanceCount, uint firstVertex, uint firstInstance);
void DrawIndexed(uint indexCount, uint instanceCount, uint firstIndex, int vertexOffset, uint firstInstance);
void DrawIndirect(BufferHandle argumentBuffer, ulong byteOffset);
void DrawIndexedIndirect(BufferHandle argumentBuffer, ulong byteOffset);
```

### 5.5 Copy, clear, and query

Final command methods:

```csharp
void UpdateBuffer(BufferHandle buffer, ulong offset, ReadOnlySpan<byte> data);
void CopyBuffer(in BufferCopyRegion region);
void CopyTexture(in TextureCopyRegion region);
void CopyBufferToTexture(in BufferTextureCopyRegion region);
void CopyTextureToBuffer(in BufferTextureCopyRegion region);
void ClearRenderTarget(TextureViewHandle view, float r, float g, float b, float a);
void ClearDepthStencil(TextureViewHandle view, bool clearDepth, float depth, bool clearStencil, byte stencil);
void BeginQuery(QueryPoolHandle queryPool, uint queryIndex);
void EndQuery(QueryPoolHandle queryPool, uint queryIndex);
void ResolveQueryData(QueryPoolHandle queryPool, uint firstQuery, uint queryCount, BufferHandle destination, ulong destinationOffset);
```

Rules:

- Copy methods are command-list operations, not immediate device operations.
- Query data is resolved into an explicit destination buffer; no hidden managed allocation is allowed in the hot path.
- Clear methods require render-target/depth-stencil texture views, not raw texture handles.

### 5.6 Render pass

Final types:

```csharp
public readonly record struct RenderPassDesc(
    ReadOnlyMemory<ColorAttachmentDesc> ColorAttachments,
    DepthStencilAttachmentDesc DepthStencil,
    uint Width,
    uint Height);
```

Final command methods:

```csharp
void BeginRenderPass(in RenderPassDesc desc);
void EndRenderPass();
```

Rules:

- Compute dispatch is invalid inside a render pass in the contract.
- Graphics draw is invalid outside a render pass in the contract.
- RenderGraph is responsible for choosing attachment load/store ops.

### 5.7 Barriers

Final command method:

```csharp
void ResourceBarrier(ReadOnlySpan<ResourceBarrier> barriers);
```

Final state enum:

```csharp
[Flags]
public enum ResourceState : uint
{
    Unknown = 0,
    Undefined = 1u << 0,
    ConstantBuffer = 1u << 1,
    VertexBuffer = 1u << 2,
    IndexBuffer = 1u << 3,
    RenderTarget = 1u << 4,
    DepthWrite = 1u << 5,
    DepthRead = 1u << 6,
    ShaderResource = 1u << 7,
    UnorderedAccess = 1u << 8,
    IndirectArgument = 1u << 9,
    CopySource = 1u << 10,
    CopyDestination = 1u << 11,
    Present = 1u << 12,
    AccelerationStructureRead = 1u << 13,
    AccelerationStructureWrite = 1u << 14
}
```

Rules:

- RenderGraph emits barriers; pipeline passes do not hand-roll barriers.
- `Unknown` is allowed only for imported resources.
- Texture transitions carry a `SubresourceRange`; whole-resource transitions use `SubresourceRange.All`.
- `BarrierFlags.UpdateState` exists for imported/external state correction where the backend state tracker must update without emitting a hardware barrier.
- UAV-to-UAV ordering uses `ResourceState.UnorderedAccess -> ResourceState.UnorderedAccess`.
- Aliasing barriers are represented explicitly by `ResourceBarrierKind.Aliasing` and carry before/after buffer or texture handles.

---

## 6. Upload and Readback

### 6.1 Upload ring

Final API:

```csharp
public readonly record struct UploadSlice(
    BufferHandle Buffer,
    ulong Offset,
    ulong Size,
    IntPtr CpuPointer);

UploadSlice AllocateUpload(ulong size, ulong alignment);
UploadSlice AllocateUpload<T>(uint count = 1) where T : unmanaged;
```

Rules:

- Upload ring memory is persistently mapped.
- The returned slice is valid until the frame fence associated with the allocation retires.
- Per-dispatch uniform data must use upload slices or push constants, not `MapBuffer(Discard)`.
- `MapBuffer` exists only for CPU-visible resource compatibility and tools; it is not the primary per-pass uniform path.

### 6.2 Direct buffer map

Final API:

```csharp
public readonly record struct MappedBuffer(
    BufferHandle Buffer,
    MapMode Mode,
    IntPtr CpuPointer,
    ulong SizeInBytes);

MappedBuffer MapBuffer(BufferHandle buffer, MapMode mode, MapFlags flags);
void UnmapBuffer(BufferHandle buffer);

public readonly record struct MappedTexture(
    TextureHandle Texture,
    uint Subresource,
    MapMode Mode,
    IntPtr CpuPointer,
    ulong RowPitch,
    ulong SlicePitch);

public readonly record struct TextureCopyLayout(
    ulong Offset,
    ulong RowPitch,
    ulong SlicePitch,
    uint RowCount);

MappedTexture MapTexture(TextureHandle texture, uint subresource, MapMode mode, MapFlags flags);
void UnmapTexture(TextureHandle texture, uint subresource);
TextureCopyLayout GetTextureCopyLayout(TextureHandle texture, uint subresource);
```

Rules:

- `GpuOnly` buffers cannot be mapped.
- `MapFlags.Discard` is valid only for write maps on CPU-to-GPU resources.
- `MapFlags.DoNotWait` must fail fast if data is not ready; it must not block silently.
- Texture maps expose explicit row and slice pitch. Callers must not assume tightly packed rows.
- Per-pass and per-dispatch data must prefer `UploadRing`; direct mapping is for compatibility, staging, debug tooling, and explicit persistent CPU resources.

### 6.3 Readback ring

Final API:

```csharp
public readonly record struct ReadbackSlice(
    BufferHandle Buffer,
    ulong Offset,
    ulong Size,
    ulong FenceValue);

ReadbackSlice AllocateReadback(ulong size, ulong alignment);
ReadOnlySpan<byte> MapReadback(ReadbackSlice slice);
```

Rules:

- Mapping before `FenceValue` completes is invalid.
- `MapReadback` returns an empty span only if the caller uses the explicit non-blocking overload added after contract. No silent failure in the contract.

---

## 7. Shader and Pipeline

### 7.1 Shader module

Final type:

```csharp
public readonly record struct ShaderModuleDesc(
    string? DebugName,
    ShaderStage Stage,
    string EntryPoint,
    ReadOnlyMemory<byte> Bytecode,
    ShaderBytecodeFormat Format);
```

Final methods:

```csharp
ShaderModuleHandle CreateShaderModule(in ShaderModuleDesc desc);
void DestroyShaderModule(ShaderModuleHandle shader);
```

Rules:

- DX12 accepts DXIL only.
- SPIR-V and MSL are valid enum values for future backends but rejected by DX12.

### 7.2 Pipeline creation

Final methods:

```csharp
PipelineLayoutHandle CreatePipelineLayout(in PipelineLayoutDesc desc);
void DestroyPipelineLayout(PipelineLayoutHandle layout);
ComputePipelineHandle CreateComputePipeline(in ComputePipelineDesc desc);
void DestroyComputePipeline(ComputePipelineHandle pipeline);
GraphicsPipelineHandle CreateGraphicsPipeline(in GraphicsPipelineDesc desc);
void DestroyGraphicsPipeline(GraphicsPipelineHandle pipeline);
```

Rules:

- Pipeline descriptors contain shader module handles, not raw bytecode.
- Pipeline layout is explicit and immutable.
- Reflection-derived descriptor set layouts must be validated before pipeline creation.
- PSO cache key uses descriptor content, not object identity.
- `GraphicsPipelineDesc` includes input layout, primitive topology, rasterizer, depth-stencil, blend state, color/depth formats, sample count, and optional graphics shader stage handles.
- `GeometryShader`, `HullShader`, `DomainShader`, `AmplificationShader`, and `MeshShader` are invalid handles when unused.

---

## 8. RenderGraph Integration

### 8.1 Ownership boundary

RenderGraph owns:

- transient resource lifetime
- placed heap packing
- pass resource access validation
- barrier generation
- view caching
- extraction/import semantics

RHI owns:

- physical resource creation
- descriptor creation and update
- command recording
- queue submission
- fence tracking

### 8.2 RenderGraph to RHI compile output

RenderGraph compile must produce:

```text
ResourceAllocationPlan[]
ResourceBarrierPlan[]
ViewCreationPlan[]
PassExecutionPlan[]
```

Rules:

- Pass code receives handles and pre-created view handles, not Diligent objects.
- A pass may request a descriptor set from the pass descriptor allocator by giving a `DescriptorSetLayoutHandle` plus `DescriptorWrite[]`.
- RenderGraph may reuse a pass descriptor set only when all descriptor writes are identical and the set lifetime is valid.

### 8.3 Standard descriptor set usage in Cluster pipeline

Cluster pipeline must use:

| Set | Contents |
|---:|---|
| 0 `Global` | bindless material tables once implemented; default samplers/textures before bindless |
| 1 `Frame` | camera, jitter, frame constants, scene globals |
| 2 `Pass` | VisBuffer, PageHeap, Instances, BinOffsets, BinCounts, output UAVs, indirect args |
| 3 `Material` | material textures, material parameter buffer/view, material scalar region view if persistent |

Per-bin values:

- `ShadingBin` uses push constants if it fits the 64-byte push constant range.
- Larger per-bin payload uses upload ring plus dynamic offset.

---

## 9. Capabilities and Limits

Final types:

```csharp
public readonly record struct DeviceLimits(
    uint ConstantBufferOffsetAlignment,
    uint StorageBufferOffsetAlignment,
    uint MaxDescriptorSets,
    uint MaxDescriptorsPerSet,
    uint MaxPushConstantBytes,
    bool SupportsPlacedResources,
    bool SupportsDescriptorIndexing,
    bool SupportsRayTracing,
    bool SupportsTimestampQueries,
    bool AllowBufferTextureInSameHeap);
```

Rules:

- `MaxDescriptorSets` must be at least 4 for SomeEngine Cluster pipeline.
- `MaxPushConstantBytes` must be at least 64 for backend acceptance.
- If `SupportsPlacedResources == false`, RenderGraph must fail unless the caller explicitly enables committed-resource fallback.

---

## 10. Integration Order

The migration order is final:

1. Introduce handle and descriptor layout types plus isolated Silk DX12 package binding without changing Diligent execution.
2. Implement DX12 `Device` with Silk and a compute-only smoke path.
3. Implement `UploadRing`, `ReadbackRing`, and command submission.
4. Implement resource heaps and placed buffer/texture creation.
5. Connect RenderGraph resource allocation and barriers to RHI for one isolated compute pass.
6. Migrate ShadeBin Count/Reserve/Scatter.
7. Migrate HiZ Build.
8. Migrate MaterialShade descriptor sets and push constants/dynamic offsets.
9. Migrate SW Raster compute path.
10. Migrate HW Draw graphics path.
11. Migrate Debug UI, temporal validation, capture/readback utilities.

MaterialShade is intentionally not first because it mixes every hard problem at once.

---

## 11. Rejected Public API Names

Do not add these public names:

| Rejected name | Use instead | Reason |
|---|---|---|
| `BindingTable` | `DescriptorSet` | Descriptor set is the cross-API term used by Vulkan/The Forge and maps cleanly to DX12 tables. |
| `BindingSet` | `DescriptorSet` | Avoid parallel vocabulary with descriptor heap/table. |
| `ResourceSet` | `DescriptorSet` | Veldrid term, but less precise for descriptor-backed binding. |
| `GpuResource` | `BufferHandle` / `TextureHandle` | Avoid untyped resources in high-level code. |
| `PipelineHandle` | `ComputePipelineHandle` / `GraphicsPipelineHandle` | Avoid illegal draw/dispatch combinations. |
| `CommandEncoder` | `CommandList` | DX12-first backend maps directly to command lists; RenderGraph already encodes passes. |
| `UploadBufferAllocator` | `UploadRing` | Ring behavior is required and part of the contract. |
| `DescriptorTable` | `DescriptorSet` | Table is a DX12 implementation detail. |

---

## 12. Out Of Scope

These names and features are not part of the contract:

- `MeshPipelineHandle`
- `RayTracingPipelineHandle`
- `WorkGraphHandle`
- `DescriptorSetFlags.AllowUpdateAfterBind`
- sparse/tiled resources
- multi-queue ownership transfers beyond graphics queue
- shader hot reload API
- bindless material system migration
- WebGPU backend
- Vulkan backend
- Metal backend

They may be added only through a new spec revision.
