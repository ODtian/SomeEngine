# Native C# RHI 痛点与替换边界

> 目标：收集当前项目使用 Diligent 的实际痛点，明确为什么需要独立 C# RHI，以及 DX12 第一阶段应优先解决什么。
>
> 本文不是完整 RHI 设计文档；它是替换 Diligent 前的证据清单和第一阶段范围约束。

---

## 1. 当前结论

SomeEngine 现在已经不是“薄封装 Diligent”的状态，而是：

- RenderGraph 已经建立了自己的 handle、lifetime、barrier、placed/aliased resource 模型。
- 材质系统已经走向 Slang reflection + explicit binding metadata，而不是依赖资源名作为长期协议。
- Cluster pipeline 的执行模型是 GPU-driven、per-bin/per-material dispatch，绑定开销在热路径上非常敏感。
- placed resource 和 binding/register 绑定已经依赖项目 fork 分支扩展，而不是 Diligent 上游原始边界。
- 现有 Diligent 使用方式在热路径上仍然收敛到全 Dynamic SRB + repeated Set/Commit。

这意味着问题不是“Diligent 没有 placed 或 binding 功能”。相反，正因为这些关键能力已经靠 fork 加进去了，项目才已经偏离 Diligent 原始抽象。继续维护 fork、SharpGen mapping 和 SRB/variable 对象模型，收益会越来越小；真正需要的是一个以 SomeEngine 现有 RenderGraph、binding layout、descriptor allocator 为中心的 C# RHI。

---

## 2. 项目内痛点

### 2.1 Diligent 类型泄漏到高层

现状：

- `RenderContext` 直接暴露 `IEngineFactory`、`IRenderDevice`、`IDeviceContext`、`ISwapChain`。
- `RenderGraph` 的物理资源和 extraction API 直接使用 `ITexture`、`IBuffer`、`ITextureView`、`IBufferView`。
- `Material` / `ShaderParamBag` / `MaterialAssetLoader` 直接存 Diligent view、buffer、sampler。
- Runtime、Debug UI、Temporal Validation 直接缓存或传递 `ITexture`。

影响：

- RHI 不是一个可替换边界，而是穿透到 Runtime、Graph、Materials、Pipelines、Tests。
- 单测为了绕过 Diligent 对象，出现 `UninitializedDiligentObject<T>()` 这类测试技巧。
- 任何新后端都必须先模拟 Diligent 对象模型，而不是实现 SomeEngine 自己需要的模型。

证据入口：

- `src/SomeEngine.Render/RHI/RenderContext.cs`
- `src/SomeEngine.Render/Graph/RenderGraph.cs`
- `src/SomeEngine.Render/Graph/RenderGraph.Context.cs`
- `src/SomeEngine.Render/Materials/ShaderParamBag.cs`
- `src/SomeEngine.Runtime/Program.cs`

### 2.2 Fork 功能证明项目已经偏离 Diligent 上游

placed resource 和按 register/space/binding 的绑定能力已经是项目 fork 分支扩展出来的能力。它们不是要指责 Diligent “做不到”，而是说明 SomeEngine 需要的 RHI 语义已经超出上游 Diligent C# mapping 的原始设计边界。

当前实际状态：

- RenderGraph 的 placed/aliased resource 能力来自项目当前分支已有实现。
- binding/register 查询能力来自项目对 Diligent 绑定路径的扩展。
- 上层仍然要通过 Diligent `ITexture` / `IBuffer` / `IShaderResourceBinding` / `IShaderResourceVariable` 对象完成执行。
- 热路径仍然是每次 dispatch 前 `Set()` 相关资源，再 `CommitShaderResources()`。

影响：

- 自研能力已经在 fork 里增长，但 API 形状仍然被 Diligent SRB/COM-style 对象模型约束。
- 每次扩展 RHI 语义都要同时维护 native fork、C# mapping、上层绕行代码和测试技巧。
- 新 RHI 设计不能只问“Diligent 能不能支持”，还要问“继续把这些能力塞回 Diligent 抽象是否划算”。
- placed allocation、binding layout、descriptor allocation、RenderGraph lifetime 仍然没有形成一套 SomeEngine 自己的一等模型。

证据入口：

- `docs/rhi/srb_binding_strategy.md`
- `src/SomeEngine.Render/Pipelines/ClusterRender/RasterPSOBuilder.cs`
- `src/SomeEngine.Render/Pipelines/ClusterRender/Stages/ClusterShade.cs`
- `src/SomeEngine.Render/Pipelines/ClusterRender/ClusterMaterialShadePass.cs`

### 2.3 绑定已经是位置协议，但运行时仍绕 SRB variable 对象

项目现在已经有 Slang reflection binding metadata：resource type、binding、space、stage。fork 分支也已经补了按 binding/register 找变量的能力。`ShaderExtensions.GetVariableByReflectedBinding()` 会用这些元数据，在 Diligent SRB 上按变量列表查找匹配项。

这已经不是传统 name binding。真正剩下的问题是：binding 虽然变成了位置协议，执行模型仍然是 SRB variable 对象协议。

- 最终还是依赖 Diligent SRB 暴露的 variable 对象。
- 每个绑定点仍然要拿 `IShaderResourceVariable` 再 `Set()`。
- binding layout 不是 SomeEngine 自己的不可变结构，无法直接生成 root signature / descriptor table 写入计划。
- name 仍然参与上层 `ShaderParamBag` API 和错误信息，容易把 debug 名称误用为协议。

独立 RHI 应把 binding 变成一等协议：

```text
BindingKey = (stageMask, resourceKind, register, space)
```

名字只用于 authoring、diagnostics、debug labels，不作为 runtime bind 的主键。

证据入口：

- `src/SomeEngine.Render/RHI/ShaderExtensions.cs`
- `src/SomeEngine.Render/Materials/ShaderParamBag.cs`

### 2.4 热路径重复 Set / Commit / Map

`ClusterMaterialShadePass` 的 per-bin loop 当前执行：

1. 写 `ShadeUniforms`：`MapBuffer(Discard)` + `UnmapBuffer`
2. 对同一个 SRB 绑定 per-pass resources
3. 写 `MaterialScalarRegion`：`MapBuffer(Discard)` + clear + material scalar write
4. `ShaderParamBag.ApplyTo()` 绑定材质资源
5. `CommitShaderResources()`
6. `DispatchComputeIndirect()`

`ClusterDrawPass` 也有类似模式：写 dispatch uniforms、租 SRB 或使用 group SRB、绑定管线资源、绑定材质资源、commit、draw indirect。

影响：

- CPU 工作量随 material bin 数线性增长。
- 很多 per-pass resource 在同一个 group 内没有变化，但仍在每个 bin 重复绑定。
- uniform 更新用 Map/Unmap 表达，无法自然升级为大 ring buffer + dynamic offset。
- 现有 `DRAW_FLAG_DYNAMIC_RESOURCE_BUFFERS_INTACT` 这类优化无法稳定使用，因为 hot loop 会反复 discard/map。

独立 RHI 应提供：

- frame-local upload ring buffer，返回 `(buffer, offset, size)`。
- descriptor table ring allocator，按 pass/material 两层写入。
- dynamic CBV/SRV/UAV offset 或 root constants/root CBV 快路径。
- command encoder 级别的 `BindLayout + BindTable + DynamicOffsets`，避免每次重新解析变量。

证据入口：

- `src/SomeEngine.Render/Pipelines/ClusterRender/ClusterMaterialShadePass.cs`
- `src/SomeEngine.Render/Pipelines/ClusterRender/ClusterDrawPass.cs`
- `src/SomeEngine.Render/Graph/RenderGraphUniforms.cs`

### 2.5 SRB 必须包含完整资源集，导致层次不清

当前 `MaterialPSOGroup` 持有一个 group SRB。执行时 SRB 同时承载：

- per-pass / per-frame resources：VisBuffer、Instances、PageHeap、Output UAV、Bin buffers
- per-material resources：textures、material buffers、samplers
- per-dispatch uniforms：bin index、args offset、scalar region

痛点：

- 管线资源与材质资源变化频率不同，却在同一个 SRB 上重复 Set。
- 多 SRB / 分层 SRB 可以缓解，但仍受 Diligent SRB 完整性和变量模型限制。
- 真正需要的是 layout 分组，而不是 SRB 对象分组：
  - set 0: frame/pass graph resources
  - set 1: material persistent resources
  - set 2: dispatch transient constants / offsets

证据入口：

- `src/SomeEngine.Render/Pipelines/ClusterRender/MaterialPSOGroup.cs`
- `src/SomeEngine.Render/Pipelines/ClusterRender/ClusterMaterialShadePass.cs`
- `src/SomeEngine.Render/Pipelines/ClusterRender/ClusterDrawPass.cs`

### 2.6 Diligent 对象模型太重，不适合 C# hot path

Diligent 的 C# API 主要是 C++ COM-style 对象映射：

- `IPipelineState`
- `IShaderResourceBinding`
- `IShaderResourceVariable`
- `ITexture` / `IBuffer` / `ITextureView`
- `ISampler`

痛点：

- 资源、view、variable 都是引用对象，热路径容易产生虚调用和跨边界调用。
- C# 层难以表达 value-type handles、generation、packed descriptor index 等轻量模型。
- 生命周期靠 `Dispose()` 分散管理，不如 RenderGraph/frame allocator 统一。
- `SRBPool` 只能复用对象，不能改变 SRB 变量模型本身。

独立 RHI 应优先暴露轻量 handle：

```csharp
public readonly record struct GpuBufferHandle(uint Index, uint Generation);
public readonly record struct GpuTextureHandle(uint Index, uint Generation);
public readonly record struct GpuViewHandle(uint Index, uint Generation);
public readonly record struct PipelineHandle(uint Index, uint Generation);
public readonly record struct BindingLayoutHandle(uint Index, uint Generation);
```

后端内部可以持有 DX12 COM 对象，但不泄漏到 RenderGraph / Materials / Pipeline hot path。

### 2.7 RenderGraph 已经拥有 RHI 应负责的关键语义

RenderGraph 当前已经做了：

- pass resource declaration validation
- compile-time barriers
- DCE
- extraction
- transient placed/aliased resource planning
- per-mip/per-view access

其中 placed/aliased resource 已经在项目 fork 能力范围内，但这些能力最后仍要落到 Diligent resource state 和 Diligent object 上。

痛点：

- Diligent 对象层不知道 RenderGraph 的完整 lifetime interval，只看到当下的 resource/view/context 操作。
- placed resource allocation 虽然已有，但 descriptor/state binding 还没有和 RenderGraph compile plan 合成一套直接可提交的 RHI plan。
- resource state tracking 已经在 Graph 内存在，再映射到 Diligent 状态会有额外语义翻译。

独立 RHI 的第一原则应是：RenderGraph 的编译结果直接生成 RHI command/resource plan，而不是先降级成 Diligent-style 对象操作。

### 2.8 当前后端边界并不是真正跨平台

虽然 Diligent 支持多后端，但当前项目实际边界已经偏 DX12：

- `RenderContext.Initialize()` 只接受 Win32 window。
- 初始化只走 D3D12。
- shader backend 选择是 `D3D12 -> dxil`，否则 `spirv`。
- swapchain、present、capture、debug validation 都直接围绕 Diligent 当前对象写。

这对“先 DX12，再全平台”不是坏事；真正的问题是高层代码以为自己在用跨平台 Diligent，实际却没有一个明确的 SomeEngine RHI capability contract。

独立 RHI 应明确：

- 第一阶段只保证 DX12。
- API 设计必须保留 Vulkan/Metal/WebGPU 可映射性。
- capability 必须显式查询，非法组合 fail-fast。
- 不支持的 feature 不能静默降级到性能很差的路径。

### 2.9 构建与绑定维护成本

当前 Diligent 带来两类维护成本：

- native C++ Diligent 编译和本地包切换成本高。
- SharpGen / C# mapping 年久失修，项目需要绕现有 API 形状继续演进。

SomeEngine 当前需要的是少量明确的底层能力：

- DX12 device / queues / command lists / fences / swapchain
- committed 和 placed buffer/texture
- descriptor heap 与 descriptor copy/write
- root signature / pipeline state
- upload/readback heaps
- barriers
- timestamp/query/debug labels

相比继续维护完整 Diligent mapping，先实现 DX12 后端的窄面 RHI 更符合当前项目需求。

---

## 3. 新 RHI 的第一阶段目标

### 3.1 非目标

第一阶段不做：

- Vulkan / Metal / WebGPU 后端
- 完整 Diligent API 对等层
- 通用图形引擎抽象大全
- 自动 shader 编译系统重写
- 材质系统大重构
- 编辑器可视化工具

### 3.2 必须解决

第一阶段必须让以下事情变简单：

1. RenderGraph 创建 transient placed resources，不暴露后端对象。
2. Shader reflection 产出稳定 binding layout，不依赖 runtime name lookup。
3. Pass 执行只写 descriptor tables / dynamic offsets，不枚举 SRB variables。
4. Per-dispatch uniform 走 upload ring buffer，不反复 Map/Unmap 同一个 Diligent buffer。
5. Material resources 可做 persistent descriptor table，pass resources 可做 frame descriptor table。
6. Debug 信息仍保留 resource/pipeline/pass 名称，错误信息能指出 shader、stage、binding、resource kind。

### 3.3 建议 API 形状

核心对象：

```text
Device
Queue
CommandList
SwapChain
ResourceAllocator
DescriptorAllocator
PipelineCache
```

高层只看 handles：

```text
BufferHandle
TextureHandle
BufferViewHandle / TextureViewHandle
SamplerHandle
ComputePipelineHandle / GraphicsPipelineHandle
DescriptorSetLayoutHandle
DescriptorSetHandle
```

绑定模型：

```text
BindingLayout
  -> BindingSetLayout[]       // set/space level
  -> BindingSlot[]            // register/binding/type/stage

BindingTable
  -> descriptor range(s)
  -> stable for persistent material resources
  -> frame-local for transient pass resources

CommandList.BindPipeline(pipeline)
CommandList.BindTable(set, table)
CommandList.SetDynamicOffset(slot, buffer, offset)
CommandList.DispatchIndirect(args, offset)
```

DX12 映射：

- `BindingLayout` -> root signature + descriptor range plan
- `BindingTable` -> CBV/SRV/UAV/Sampler descriptor heap range
- dynamic offset -> root CBV/SRV/UAV 或 descriptor with offset policy
- transient descriptors -> shader-visible descriptor heap ring
- persistent material descriptors -> stable descriptor heap slots with generation checks

---

## 4. 替换路线

### Phase 0: Inventory and boundary freeze

- 列出所有 `using Diligent` 的生产代码位置。
- 给每个位置归类：device/swapchain、graph resource、pipeline creation、binding、debug/capture、tests。
- 暂停新增直接 Diligent 依赖；新增代码只能依赖现有 `RenderContext` 或新 RHI facade。

### Phase 1: 新建最小 RHI facade

- 在 `SomeEngine.Render.RHI` 内新增后端无关 value-type handles 和 descriptors。
- 先不删除 Diligent，提供 Diligent adapter 或并行 DX12 backend。
- RenderGraph 新增可选的 RHI-facing resource descriptors，不立刻替换所有调用。

### Phase 2: DX12 device/resource/command MVP

最小可运行目标：

- 创建 DX12 device、queue、swapchain。
- 创建 buffer/texture/view/sampler。
- 创建 compute pipeline。
- 录制 dispatch、barrier、copy、present。
- 支持 upload/readback ring。

验证目标：

- 选一个 compute-only pass，不经过 Diligent 执行。
- 输出可 readback 或可 copy 到 swapchain。

### Phase 3: RenderGraph 接入 placed resources

- RenderGraph compile 结果直接调用 RHI resource allocator。
- transient resource 使用 placed heap。
- imported/extracted resource 使用 handle + generation。
- barrier plan 直接转 RHI barrier，不再通过 Diligent object。

验证目标：

- 现有 RenderGraph resource lifetime / DCE / barrier 单测不依赖 Diligent fake object。
- placed aliasing 有最小 GPU 验证。

### Phase 4: Binding layout and descriptor allocator

- 从 Slang reflection 生成 `BindingLayout`。
- 建 descriptor heap ring。
- 替换 `GetVariableByReflectedBinding()` 热路径。
- 实现 pass table + material table + dispatch dynamic data 三层绑定。

验证目标：

- `ClusterMaterialShadePass` 不再 per-binding 枚举 SRB variable。
- per-material scalar/uniform 更新走 upload ring offset。

### Phase 5: Cluster pipeline migration

建议迁移顺序：

1. ShadeBin Count/Reserve/Scatter：固定 compute pass，资源绑定简单。
2. HiZ Build：mip view 和 UAV/SRV view 压力适中。
3. MaterialShade：验证材质 descriptor table 和 dynamic offsets。
4. SW Raster compute path。
5. HW Draw graphics path。
6. Debug UI / Temporal validation / capture。

---

## 5. 设计约束

### 5.1 Fail-fast

必须尽早报错：

- shader reflection 中 binding 冲突
- layout 与 pipeline root signature 不匹配
- resource state 与 pass declaration 不一致
- descriptor table 缺少 required binding
- handle generation 失效
- backend 不支持 requested feature
- placed heap alignment/size 不合法

不要静默 fallback 到 name binding、全 Dynamic、committed resource 或 CPU copy，除非调用方显式请求 degrade path。

### 5.2 KISS

DX12 第一阶段只暴露当前项目真实需要的能力。不要为了未来 Vulkan/Metal 把 API 做成完整超集。跨平台考虑体现在：

- handle/descriptors 不泄漏 DX12 类型
- explicit capabilities
- binding layout 可映射到 descriptor set / argument buffer
- barriers 保留足够语义

### 5.3 让非法状态不可表达

建议用类型区分：

- buffer view vs texture view
- SRV/UAV/CBV/RTV/DSV
- shader-visible descriptor table vs CPU-only descriptor
- frame-local handle vs persistent handle
- imported resource vs graph-owned transient resource

---

## 6. 第一批待办

1. 生成 Diligent 使用矩阵。
   - 输入：`rg "using Diligent|Diligent\\.|ITexture|IBuffer|IPipelineState|IShaderResourceBinding"`
   - 输出：模块、用途、替换难度、是否 hot path。

2. 定义 RHI handle 与 descriptor 基础类型。
   - 不接 DX12 实现。
   - 先让 RenderGraph/Materials 能引用中立类型。

3. 定义 binding layout 数据结构。
   - 输入来自现有 `ShaderAsset.Metadata.MaterialBindings` 和 Slang reflection。
   - 主键使用 register/space/type/stage。
   - name 只作为 debug label。

4. 设计 descriptor allocator。
   - frame ring for transient pass resources。
   - persistent table for material resources。
   - sampler table 独立处理。

5. 写 DX12 MVP spike。
   - 独立小路径，不先碰整个 Cluster pipeline。
   - 能 clear/copy/dispatch/readback 即可。

6. 选第一个迁移 pass。
   - 优先 ShadeBin 或 HiZ，不从 MaterialShade 开始。
   - 目标是验证 RHI command/resource/binding 基础，不混入材质系统复杂度。
