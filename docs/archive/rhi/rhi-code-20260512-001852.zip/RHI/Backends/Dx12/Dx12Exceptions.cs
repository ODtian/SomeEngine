using System;
using Silk.NET.Core.Native;

namespace SomeEngine.RHI.Backends.Dx12;

internal static class Dx12Exceptions
{
    public static void ThrowIfFailed(int hr, string operation)
    {
        var result = (HResult)hr;
        if (!result.IsFailure)
            return;

        try
        {
            result.Throw();
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"{operation} failed with HRESULT 0x{unchecked((uint)hr):X8}.",
                ex);
        }
    }
}
