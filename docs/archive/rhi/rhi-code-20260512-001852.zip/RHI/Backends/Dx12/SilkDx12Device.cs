using System;
using System.Runtime.InteropServices;
using System.Threading;
using SomeEngine.RHI;
using Silk.NET.Core.Native;
using Silk.NET.Direct3D12;
using Silk.NET.DXGI;
using Silk.NET.Core.Contexts;
using D3D12CommandQueue = Silk.NET.Direct3D12.ID3D12CommandQueue;
using D3D12Device = Silk.NET.Direct3D12.ID3D12Device;
using D3D12Fence = Silk.NET.Direct3D12.ID3D12Fence;
using D3D12Resource = Silk.NET.Direct3D12.ID3D12Resource;
using DxgiAdapter1 = Silk.NET.DXGI.IDXGIAdapter1;
using DxgiFactory1 = Silk.NET.DXGI.IDXGIFactory1;
using DxgiFormat = Silk.NET.DXGI.Format;
using DxgiSampleDesc = Silk.NET.DXGI.SampleDesc;
using SilkD3D12 = Silk.NET.Direct3D12.D3D12;
using SilkDXGI = Silk.NET.DXGI.DXGI;
using ApiClearValue = SomeEngine.RHI.ClearValue;
using ApiFormat = SomeEngine.RHI.Format;
using ApiSamplerDesc = SomeEngine.RHI.SamplerDesc;
using ApiSwapChainDesc = SomeEngine.RHI.SwapChainDesc;
using Dx12ClearValue = Silk.NET.Direct3D12.ClearValue;
using Dx12Range = Silk.NET.Direct3D12.Range;

namespace SomeEngine.RHI.Backends.Dx12;

public sealed class SilkDx12Device : Device
{
    private readonly SilkD3D12 _d3d12;
    private readonly SilkDXGI _dxgi;
    private ComPtr<DxgiFactory1> _factory;
    private ComPtr<DxgiAdapter1> _adapter;
    private ComPtr<D3D12Device> _nativeDevice;
    private readonly Dx12QueueState _graphicsQueue;
    private readonly Dx12QueueState _computeQueue;
    private readonly Dx12QueueState _copyQueue;
    private readonly Dx12CpuDescriptorAllocator _cbvSrvUavDescriptors;
    private readonly Dx12CpuDescriptorAllocator _samplerDescriptors;
    private readonly Dx12CpuDescriptorAllocator _rtvDescriptors;
    private readonly Dx12CpuDescriptorAllocator _dsvDescriptors;
    private readonly Dx12HandleStore<FenceHandle, Dx12FenceState> _fences;
    private readonly Dx12HandleStore<ResourceHeapHandle, Dx12ResourceHeapState> _resourceHeaps;
    private readonly Dx12HandleStore<BufferHandle, Dx12BufferState> _buffers;
    private readonly Dx12HandleStore<TextureHandle, Dx12TextureState> _textures;
    private readonly Dx12HandleStore<BufferViewHandle, Dx12BufferViewState> _bufferViews;
    private readonly Dx12HandleStore<TextureViewHandle, Dx12TextureViewState> _textureViews;
    private readonly Dx12HandleStore<SamplerHandle, Dx12SamplerState> _samplers;
    private readonly Dx12HandleStore<DescriptorSetLayoutHandle, Dx12DescriptorSetLayoutState> _descriptorSetLayouts;
    private readonly Dx12HandleStore<DescriptorSetHandle, Dx12DescriptorSetState> _descriptorSets;
    private bool _disposed;

    private SilkDx12Device(
        SilkD3D12 d3d12,
        SilkDXGI dxgi,
        ComPtr<DxgiFactory1> factory,
        ComPtr<DxgiAdapter1> adapter,
        ComPtr<D3D12Device> nativeDevice)
    {
        _d3d12 = d3d12 ?? throw new ArgumentNullException(nameof(d3d12));
        _dxgi = dxgi ?? throw new ArgumentNullException(nameof(dxgi));
        _factory = factory;
        _adapter = adapter;
        _nativeDevice = nativeDevice;
        _graphicsQueue = CreateQueue(QueueKind.Graphics, new QueueHandle(1, 1), "GraphicsQueue");
        _computeQueue = CreateQueue(QueueKind.Compute, new QueueHandle(2, 1), "ComputeQueue");
        _copyQueue = CreateQueue(QueueKind.Copy, new QueueHandle(3, 1), "CopyQueue");
        _cbvSrvUavDescriptors = new Dx12CpuDescriptorAllocator(_nativeDevice, DescriptorHeapType.CbvSrvUav, 65_536, "CPU CBV/SRV/UAV Descriptors");
        _samplerDescriptors = new Dx12CpuDescriptorAllocator(_nativeDevice, DescriptorHeapType.Sampler, 2_048, "CPU Sampler Descriptors");
        _rtvDescriptors = new Dx12CpuDescriptorAllocator(_nativeDevice, DescriptorHeapType.Rtv, 8_192, "CPU RTV Descriptors");
        _dsvDescriptors = new Dx12CpuDescriptorAllocator(_nativeDevice, DescriptorHeapType.Dsv, 4_096, "CPU DSV Descriptors");
        _fences = new Dx12HandleStore<FenceHandle, Dx12FenceState>(
            static (index, generation) => new FenceHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static fence => fence.Dispose());
        _resourceHeaps = new Dx12HandleStore<ResourceHeapHandle, Dx12ResourceHeapState>(
            static (index, generation) => new ResourceHeapHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static heap => heap.Dispose());
        _buffers = new Dx12HandleStore<BufferHandle, Dx12BufferState>(
            static (index, generation) => new BufferHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static buffer => buffer.Dispose());
        _textures = new Dx12HandleStore<TextureHandle, Dx12TextureState>(
            static (index, generation) => new TextureHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static texture => texture.Dispose());
        _bufferViews = new Dx12HandleStore<BufferViewHandle, Dx12BufferViewState>(
            static (index, generation) => new BufferViewHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static view => view.Dispose());
        _textureViews = new Dx12HandleStore<TextureViewHandle, Dx12TextureViewState>(
            static (index, generation) => new TextureViewHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static view => view.Dispose());
        _samplers = new Dx12HandleStore<SamplerHandle, Dx12SamplerState>(
            static (index, generation) => new SamplerHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation,
            static sampler => sampler.Dispose());
        _descriptorSetLayouts = new Dx12HandleStore<DescriptorSetLayoutHandle, Dx12DescriptorSetLayoutState>(
            static (index, generation) => new DescriptorSetLayoutHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation);
        _descriptorSets = new Dx12HandleStore<DescriptorSetHandle, Dx12DescriptorSetState>(
            static (index, generation) => new DescriptorSetHandle(index, generation),
            static handle => handle.Index,
            static handle => handle.Generation);
    }

    public static SilkDx12Device Create()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("The Silk DX12 RHI backend requires Windows.");

        var d3d12 = SilkD3D12.GetApi();
#pragma warning disable CS0618
        var dxgi = SilkDXGI.GetApi();
#pragma warning restore CS0618
        return Create(d3d12, dxgi);
    }

    public static SilkDx12Device Create(INativeWindowSource window)
    {
        ArgumentNullException.ThrowIfNull(window);

        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("The Silk DX12 RHI backend requires Windows.");

        return Create(SilkD3D12.GetApi(), SilkDXGI.GetApi(window));
    }

    public override BackendInfo BackendInfo { get; } = new(
        BackendKind.Dx12,
        "DX12",
        "Silk.NET.Direct3D12 + Silk.NET.DXGI");

    public override DeviceLimits Limits { get; } = new(
        ConstantBufferOffsetAlignment: 256,
        StorageBufferOffsetAlignment: 256,
        MaxDescriptorSets: 4,
        MaxDescriptorsPerSet: 1_000_000,
        MaxPushConstantBytes: 64,
        SupportsPlacedResources: true,
        SupportsDescriptorIndexing: true,
        SupportsRayTracing: false,
        SupportsTimestampQueries: true,
        AllowBufferTextureInSameHeap: true);

    internal SilkD3D12 D3D12 => _d3d12;
    internal SilkDXGI DXGI => _dxgi;
    internal ComPtr<D3D12Device> NativeDevice => _nativeDevice;

    public override Queue GetQueue(QueueKind kind)
    {
        ThrowIfDisposed();

        return kind switch
        {
            QueueKind.Graphics => _graphicsQueue.PublicQueue,
            QueueKind.Compute => _computeQueue.PublicQueue,
            QueueKind.Copy => _copyQueue.PublicQueue,
            _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported queue kind."),
        };
    }

    public override SwapChainHandle CreateSwapChain(Queue queue, in ApiSwapChainDesc desc) =>
        throw UnsupportedFeature(nameof(CreateSwapChain));

    public override ApiSwapChainDesc GetSwapChainDesc(SwapChainHandle swapChain) =>
        throw UnsupportedFeature(nameof(GetSwapChainDesc));

    public override void ResizeSwapChain(SwapChainHandle swapChain, uint width, uint height) =>
        throw UnsupportedFeature(nameof(ResizeSwapChain));

    public override uint GetCurrentBackBufferIndex(SwapChainHandle swapChain) =>
        throw UnsupportedFeature(nameof(GetCurrentBackBufferIndex));

    public override TextureHandle GetSwapChainBackBuffer(SwapChainHandle swapChain, uint index) =>
        throw UnsupportedFeature(nameof(GetSwapChainBackBuffer));

    public override TextureViewHandle GetSwapChainBackBufferView(SwapChainHandle swapChain, uint index) =>
        throw UnsupportedFeature(nameof(GetSwapChainBackBufferView));

    public override void Present(SwapChainHandle swapChain, in PresentOptions options) =>
        throw UnsupportedFeature(nameof(Present));

    public override void DestroySwapChain(SwapChainHandle swapChain) =>
        throw UnsupportedFeature(nameof(DestroySwapChain));

    public override DescriptorSetLayoutHandle CreateDescriptorSetLayout(in DescriptorSetLayoutDesc desc)
    {
        ThrowIfDisposed();
        if (desc.Bindings.Length == 0)
            throw new ArgumentException("Descriptor set layout must contain at least one binding.", nameof(desc));

        var bindings = desc.Bindings.ToArray();
        var seen = new HashSet<uint>();
        foreach (var binding in bindings)
        {
            if (binding.Count == 0)
                throw new ArgumentException($"Descriptor binding {binding.Binding} must have a non-zero descriptor count.", nameof(desc));
            if (binding.Count > int.MaxValue)
                throw new ArgumentOutOfRangeException(nameof(desc), binding.Count, $"Descriptor binding {binding.Binding} is too large for a managed descriptor array.");
            if (!seen.Add(binding.Binding))
                throw new ArgumentException($"Descriptor binding {binding.Binding} is declared more than once.", nameof(desc));
        }

        var normalized = desc with { Bindings = bindings };
        return _descriptorSetLayouts.Add(new Dx12DescriptorSetLayoutState(normalized, bindings));
    }

    public override void DestroyDescriptorSetLayout(DescriptorSetLayoutHandle layout)
    {
        ThrowIfDisposed();
        if (!_descriptorSetLayouts.TryRemove(layout))
            throw new ArgumentException("Descriptor set layout handle is invalid or already destroyed.", nameof(layout));
    }

    public override DescriptorSetHandle CreateDescriptorSet(DescriptorSetLayoutHandle layout, string? debugName)
    {
        ThrowIfDisposed();

        var layoutState = _descriptorSetLayouts.Get(layout);
        var values = new DescriptorValue[layoutState.Bindings.Length][];
        for (int i = 0; i < layoutState.Bindings.Length; i++)
        {
            var binding = layoutState.Bindings[i];
            values[i] = new DescriptorValue[checked((int)binding.Count)];
            Array.Fill(values[i], DescriptorValue.Null(binding.Type));
        }

        return _descriptorSets.Add(new Dx12DescriptorSetState(layout, debugName, values));
    }

    public override void DestroyDescriptorSet(DescriptorSetHandle set)
    {
        ThrowIfDisposed();
        if (!_descriptorSets.TryRemove(set))
            throw new ArgumentException("Descriptor set handle is invalid or already destroyed.", nameof(set));
    }

    public override void UpdateDescriptorSet(DescriptorSetHandle set, ReadOnlySpan<DescriptorWrite> writes)
    {
        ThrowIfDisposed();

        var setState = _descriptorSets.Get(set);
        var layoutState = _descriptorSetLayouts.Get(setState.Layout);
        foreach (var write in writes)
        {
            if (!layoutState.BindingIndex.TryGetValue(write.Binding, out var bindingIndex))
                throw new ArgumentException($"Descriptor binding {write.Binding} is not declared by the set layout.", nameof(writes));

            var binding = layoutState.Bindings[bindingIndex];
            if (write.ArrayElement >= binding.Count)
                throw new ArgumentOutOfRangeException(nameof(writes), write.ArrayElement, $"Descriptor write for binding {write.Binding} is outside the declared array length {binding.Count}.");
            if (write.Value.Type != binding.Type)
                throw new ArgumentException($"Descriptor write for binding {write.Binding} has type {write.Value.Type}, but layout expects {binding.Type}.", nameof(writes));

            ValidateDescriptorValue(write.Value);
            setState.Values[bindingIndex][checked((int)write.ArrayElement)] = write.Value;
        }
    }

    public override ResourceHeapHandle CreateResourceHeap(in ResourceHeapDesc desc)
    {
        ThrowIfDisposed();
        ValidateHeapDesc(desc);

        var heapProps = Dx12Conversions.ToHeapProperties(desc.MemoryUsage);
        var heapDesc = new HeapDesc
        {
            SizeInBytes = desc.SizeInBytes,
            Properties = heapProps,
            Alignment = NormalizeHeapAlignment(desc.Alignment),
            Flags = HeapFlags.None,
        };

        ComPtr<ID3D12Heap> nativeHeap = default;
        Dx12Exceptions.ThrowIfFailed(
            _nativeDevice.CreateHeap(in heapDesc, out nativeHeap),
            "ID3D12Device.CreateHeap");
        SetObjectName(nativeHeap, desc.DebugName, "ID3D12Heap");
        return _resourceHeaps.Add(new Dx12ResourceHeapState(nativeHeap, desc));
    }

    public override void DestroyResourceHeap(ResourceHeapHandle heap)
    {
        ThrowIfDisposed();
        if (!_resourceHeaps.TryRemove(heap))
            throw new ArgumentException("Resource heap handle is invalid or already destroyed.", nameof(heap));
    }

    public override ResourceMemoryRequirements GetBufferMemoryRequirements(in BufferDesc desc)
    {
        ThrowIfDisposed();
        var nativeDesc = ToBufferResourceDesc(desc);
        var info = _nativeDevice.GetResourceAllocationInfo(0, 1, in nativeDesc);
        return new ResourceMemoryRequirements(info.SizeInBytes, info.Alignment);
    }

    public override unsafe BufferHandle CreateBuffer(in BufferDesc desc)
    {
        ThrowIfDisposed();
        var nativeDesc = ToBufferResourceDesc(desc);
        var initialState = Dx12Conversions.InitialBufferState(desc);

        ComPtr<D3D12Resource> nativeResource = default;
        switch (desc.Placement.Kind)
        {
            case ResourcePlacementKind.Committed:
            {
                var heapProps = Dx12Conversions.ToHeapProperties(desc.Placement.MemoryUsage);
                Dx12Exceptions.ThrowIfFailed(
                    _nativeDevice.CreateCommittedResource(
                        in heapProps,
                        HeapFlags.None,
                        in nativeDesc,
                        initialState,
                        (Dx12ClearValue*)null,
                        out nativeResource),
                    "ID3D12Device.CreateCommittedResource(Buffer)");
                break;
            }
            case ResourcePlacementKind.Placed:
            {
                var heap = _resourceHeaps.Get(desc.Placement.Heap);
                var requirements = GetBufferMemoryRequirements(desc);
                ValidatePlacedResource(desc.Placement, heap.Desc, requirements, nameof(desc));
                Dx12Exceptions.ThrowIfFailed(
                    _nativeDevice.CreatePlacedResource(
                        heap.NativeHeap,
                        desc.Placement.HeapOffset,
                        in nativeDesc,
                        initialState,
                        (Dx12ClearValue*)null,
                        out nativeResource),
                    "ID3D12Device.CreatePlacedResource(Buffer)");
                break;
            }
            default:
                throw new ArgumentOutOfRangeException(nameof(desc), desc.Placement.Kind, "Unsupported resource placement kind.");
        }

        SetObjectName(nativeResource, desc.DebugName, "ID3D12Resource(Buffer)");
        var state = new Dx12BufferState(nativeResource, desc, initialState);
        var handle = _buffers.Add(state);
        state.Handle = handle;
        return handle;
    }

    public override BufferDesc GetBufferDesc(BufferHandle buffer)
    {
        ThrowIfDisposed();
        return _buffers.Get(buffer).Desc;
    }

    public override void DestroyBuffer(BufferHandle buffer)
    {
        ThrowIfDisposed();
        var state = _buffers.Get(buffer);
        if (state.ViewCount != 0)
            throw new InvalidOperationException($"Cannot destroy buffer while {state.ViewCount} buffer view(s) still reference it.");
        if (!_buffers.TryRemove(buffer))
            throw new ArgumentException("Buffer handle is invalid or already destroyed.", nameof(buffer));
    }

    public override ResourceMemoryRequirements GetTextureMemoryRequirements(in TextureDesc desc)
    {
        ThrowIfDisposed();
        var nativeDesc = ToTextureResourceDesc(desc);
        var info = _nativeDevice.GetResourceAllocationInfo(0, 1, in nativeDesc);
        return new ResourceMemoryRequirements(info.SizeInBytes, info.Alignment);
    }

    public override unsafe TextureHandle CreateTexture(in TextureDesc desc)
    {
        ThrowIfDisposed();
        var nativeDesc = ToTextureResourceDesc(desc);
        var initialState = Dx12Conversions.InitialTextureState(desc);
        Dx12ClearValue clearValue = default;
        Dx12ClearValue* clearValuePtr = TryCreateClearValue(desc.ClearValue, desc.Usage, out clearValue) ? &clearValue : null;

        ComPtr<D3D12Resource> nativeResource = default;
        switch (desc.Placement.Kind)
        {
            case ResourcePlacementKind.Committed:
            {
                var heapProps = Dx12Conversions.ToHeapProperties(desc.Placement.MemoryUsage);
                Dx12Exceptions.ThrowIfFailed(
                    _nativeDevice.CreateCommittedResource(
                        in heapProps,
                        HeapFlags.None,
                        in nativeDesc,
                        initialState,
                        clearValuePtr,
                        out nativeResource),
                    "ID3D12Device.CreateCommittedResource(Texture)");
                break;
            }
            case ResourcePlacementKind.Placed:
            {
                var heap = _resourceHeaps.Get(desc.Placement.Heap);
                var requirements = GetTextureMemoryRequirements(desc);
                ValidatePlacedResource(desc.Placement, heap.Desc, requirements, nameof(desc));
                Dx12Exceptions.ThrowIfFailed(
                    _nativeDevice.CreatePlacedResource(
                        heap.NativeHeap,
                        desc.Placement.HeapOffset,
                        in nativeDesc,
                        initialState,
                        clearValuePtr,
                        out nativeResource),
                    "ID3D12Device.CreatePlacedResource(Texture)");
                break;
            }
            default:
                throw new ArgumentOutOfRangeException(nameof(desc), desc.Placement.Kind, "Unsupported resource placement kind.");
        }

        SetObjectName(nativeResource, desc.DebugName, "ID3D12Resource(Texture)");
        var state = new Dx12TextureState(nativeResource, desc, initialState);
        var handle = _textures.Add(state);
        state.Handle = handle;
        return handle;
    }

    public override TextureDesc GetTextureDesc(TextureHandle texture)
    {
        ThrowIfDisposed();
        return _textures.Get(texture).Desc;
    }

    public override void DestroyTexture(TextureHandle texture)
    {
        ThrowIfDisposed();
        var state = _textures.Get(texture);
        if (state.ViewCount != 0)
            throw new InvalidOperationException($"Cannot destroy texture while {state.ViewCount} texture view(s) still reference it.");
        if (!_textures.TryRemove(texture))
            throw new ArgumentException("Texture handle is invalid or already destroyed.", nameof(texture));
    }

    public override BufferViewHandle CreateBufferView(BufferHandle buffer, in BufferViewDesc desc)
    {
        ThrowIfDisposed();

        var bufferState = _buffers.Get(buffer);
        var descriptor = CreateBufferDescriptor(bufferState, desc);
        var viewState = new Dx12BufferViewState(buffer, desc, descriptor);
        var view = _bufferViews.Add(viewState);
        bufferState.AddView();
        return view;
    }

    public override BufferViewDesc GetBufferViewDesc(BufferViewHandle view)
    {
        ThrowIfDisposed();
        return _bufferViews.Get(view).Desc;
    }

    public override BufferViewHandle GetDefaultBufferView(BufferHandle buffer, BufferViewKind kind)
    {
        ThrowIfDisposed();

        var bufferState = _buffers.Get(buffer);
        var existing = bufferState.GetDefaultView(kind);
        if (existing.IsValid)
            return existing;

        var desc = CreateDefaultBufferViewDesc(bufferState.Desc, kind);
        var view = CreateBufferView(buffer, desc);
        bufferState.SetDefaultView(kind, view);
        return view;
    }

    public override void DestroyBufferView(BufferViewHandle view)
    {
        ThrowIfDisposed();

        var viewState = _bufferViews.Get(view);
        var bufferState = _buffers.Get(viewState.Buffer);
        bufferState.ClearDefaultView(view);
        bufferState.RemoveView();
        if (!_bufferViews.TryRemove(view))
            throw new ArgumentException("Buffer view handle is invalid or already destroyed.", nameof(view));
    }

    public override TextureViewHandle CreateTextureView(TextureHandle texture, in TextureViewDesc desc)
    {
        ThrowIfDisposed();

        var textureState = _textures.Get(texture);
        var descriptor = CreateTextureDescriptor(textureState, desc);
        var viewState = new Dx12TextureViewState(texture, desc, descriptor);
        var view = _textureViews.Add(viewState);
        textureState.AddView();
        return view;
    }

    public override TextureViewDesc GetTextureViewDesc(TextureViewHandle view)
    {
        ThrowIfDisposed();
        return _textureViews.Get(view).Desc;
    }

    public override TextureViewHandle GetDefaultTextureView(TextureHandle texture, TextureViewKind kind)
    {
        ThrowIfDisposed();

        var textureState = _textures.Get(texture);
        var existing = textureState.GetDefaultView(kind);
        if (existing.IsValid)
            return existing;

        var desc = CreateDefaultTextureViewDesc(textureState.Desc, kind);
        var view = CreateTextureView(texture, desc);
        textureState.SetDefaultView(kind, view);
        return view;
    }

    public override void DestroyTextureView(TextureViewHandle view)
    {
        ThrowIfDisposed();

        var viewState = _textureViews.Get(view);
        var textureState = _textures.Get(viewState.Texture);
        textureState.ClearDefaultView(view);
        textureState.RemoveView();
        if (!_textureViews.TryRemove(view))
            throw new ArgumentException("Texture view handle is invalid or already destroyed.", nameof(view));
    }

    public override SamplerHandle CreateSampler(in ApiSamplerDesc desc)
    {
        ThrowIfDisposed();
        if (desc.MaxAnisotropy == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.MaxAnisotropy, "Sampler MaxAnisotropy must be at least one.");
        if (desc.MinLod > desc.MaxLod)
            throw new ArgumentException("Sampler MinLod must be less than or equal to MaxLod.", nameof(desc));

        var slot = _samplerDescriptors.Allocate();
        try
        {
            var nativeDesc = Dx12Conversions.ToSamplerDesc(desc);
            _nativeDevice.CreateSampler(in nativeDesc, slot.CpuHandle);
            return _samplers.Add(new Dx12SamplerState(desc, slot));
        }
        catch
        {
            slot.Dispose();
            throw;
        }
    }

    public override void DestroySampler(SamplerHandle sampler)
    {
        ThrowIfDisposed();
        if (!_samplers.TryRemove(sampler))
            throw new ArgumentException("Sampler handle is invalid or already destroyed.", nameof(sampler));
    }

    public override ShaderModuleHandle CreateShaderModule(in ShaderModuleDesc desc) =>
        throw UnsupportedFeature(nameof(CreateShaderModule));

    public override void DestroyShaderModule(ShaderModuleHandle shader) =>
        throw UnsupportedFeature(nameof(DestroyShaderModule));

    public override PipelineLayoutHandle CreatePipelineLayout(in PipelineLayoutDesc desc) =>
        throw UnsupportedFeature(nameof(CreatePipelineLayout));

    public override void DestroyPipelineLayout(PipelineLayoutHandle layout) =>
        throw UnsupportedFeature(nameof(DestroyPipelineLayout));

    public override ComputePipelineHandle CreateComputePipeline(in ComputePipelineDesc desc) =>
        throw UnsupportedFeature(nameof(CreateComputePipeline));

    public override void DestroyComputePipeline(ComputePipelineHandle pipeline) =>
        throw UnsupportedFeature(nameof(DestroyComputePipeline));

    public override GraphicsPipelineHandle CreateGraphicsPipeline(in GraphicsPipelineDesc desc) =>
        throw UnsupportedFeature(nameof(CreateGraphicsPipeline));

    public override void DestroyGraphicsPipeline(GraphicsPipelineHandle pipeline) =>
        throw UnsupportedFeature(nameof(DestroyGraphicsPipeline));

    public override FenceHandle CreateFence(in FenceDesc desc)
    {
        ThrowIfDisposed();

        ComPtr<D3D12Fence> nativeFence = default;
        Dx12Exceptions.ThrowIfFailed(
            _nativeDevice.CreateFence(desc.InitialValue, FenceFlags.None, out nativeFence),
            "ID3D12Device.CreateFence");
        if (!string.IsNullOrWhiteSpace(desc.DebugName))
        {
            Dx12Exceptions.ThrowIfFailed(
                nativeFence.SetName(desc.DebugName),
                $"ID3D12Fence.SetName({desc.DebugName})");
        }

        return _fences.Add(new Dx12FenceState(nativeFence, desc.DebugName));
    }

    public override ulong GetFenceCompletedValue(FenceHandle fence) =>
        GetCompletedFenceValue(_fences.Get(fence));

    public override unsafe void WaitForFence(FenceHandle fence, ulong value, TimeSpan? timeout = null)
    {
        ThrowIfDisposed();

        var state = _fences.Get(fence);
        if (GetCompletedFenceValue(state) >= value)
            return;

        using var waitHandle = new ManualResetEvent(false);
        Dx12Exceptions.ThrowIfFailed(
            state.NativeFence.SetEventOnCompletion(value, (void*)waitHandle.SafeWaitHandle.DangerousGetHandle()),
            $"ID3D12Fence.SetEventOnCompletion({value})");
        var waitTime = timeout ?? Timeout.InfiniteTimeSpan;
        if (!waitHandle.WaitOne(waitTime))
            throw new TimeoutException($"Timed out waiting for fence value {value}.");
    }

    public override void DestroyFence(FenceHandle fence)
    {
        if (!_fences.TryRemove(fence))
            throw new ArgumentException("Fence handle is invalid or already destroyed.", nameof(fence));
    }

    public override void SignalFence(Queue queue, FenceHandle fence, ulong value)
    {
        ThrowIfDisposed();
        Dx12Exceptions.ThrowIfFailed(
            GetQueueState(queue).NativeQueue.Signal(_fences.Get(fence).NativeFence, value),
            $"ID3D12CommandQueue.Signal({value})");
    }

    public override void WaitIdle(Queue queue)
    {
        ThrowIfDisposed();

        var fence = CreateFence(new FenceDesc("WaitIdle", 0));
        try
        {
            SignalFence(queue, fence, 1);
            WaitForFence(fence, 1);
        }
        finally
        {
            DestroyFence(fence);
        }
    }

    public override void WaitIdle()
    {
        WaitIdle(_graphicsQueue.PublicQueue);
        WaitIdle(_computeQueue.PublicQueue);
        WaitIdle(_copyQueue.PublicQueue);
    }

    public override QueryPoolHandle CreateQueryPool(in QueryPoolDesc desc) =>
        throw UnsupportedFeature(nameof(CreateQueryPool));

    public override void DestroyQueryPool(QueryPoolHandle queryPool) =>
        throw UnsupportedFeature(nameof(DestroyQueryPool));

    public override ulong GetTimestampFrequency(Queue queue)
    {
        ThrowIfDisposed();

        ulong frequency = 0;
        GetQueueState(queue).NativeQueue.GetTimestampFrequency(ref frequency);
        return frequency;
    }

    public override CommandList BeginCommandList(Queue queue, string? debugName) =>
        throw UnsupportedFeature(nameof(BeginCommandList));

    public override void EndCommandList(CommandList commandList) =>
        throw UnsupportedFeature(nameof(EndCommandList));

    public override void Submit(Queue queue, CommandList commandList, FenceHandle signalFence, ulong signalValue) =>
        throw UnsupportedFeature(nameof(Submit));

    public override unsafe MappedBuffer MapBuffer(BufferHandle buffer, MapMode mode, MapFlags flags)
    {
        ThrowIfDisposed();
        if (flags != MapFlags.None)
            throw new NotSupportedException("DX12 buffer mapping currently supports MapFlags.None only; discard/no-overwrite are handled by allocator policy, not ID3D12Resource.Map.");

        var state = _buffers.Get(buffer);
        ValidateBufferMapMode(state.Desc.Placement.MemoryUsage, mode);
        if (state.MappedPointer != IntPtr.Zero)
            throw new InvalidOperationException("Buffer is already mapped.");

        var readRange = mode == MapMode.Write
            ? new Dx12Range { Begin = UIntPtr.Zero, End = UIntPtr.Zero }
            : new Dx12Range { Begin = UIntPtr.Zero, End = new UIntPtr(state.Desc.SizeInBytes) };

        void* mapped = null;
        Dx12Exceptions.ThrowIfFailed(
            state.NativeResource.Map(0, &readRange, &mapped),
            "ID3D12Resource.Map(Buffer)");
        state.MappedPointer = (IntPtr)mapped;
        state.MappedMode = mode;
        return new MappedBuffer(buffer, mode, (IntPtr)mapped, state.Desc.SizeInBytes);
    }

    public override unsafe void UnmapBuffer(BufferHandle buffer)
    {
        ThrowIfDisposed();

        var state = _buffers.Get(buffer);
        if (state.MappedPointer == IntPtr.Zero || state.MappedMode is null)
            throw new InvalidOperationException("Buffer is not mapped.");

        var mode = state.MappedMode.Value;
        Dx12Range writtenRange = mode == MapMode.Read
            ? default
            : new Dx12Range { Begin = UIntPtr.Zero, End = new UIntPtr(state.Desc.SizeInBytes) };
        state.NativeResource.Unmap(0, mode == MapMode.Read ? null : &writtenRange);
        state.MappedPointer = IntPtr.Zero;
        state.MappedMode = null;
    }

    public override MappedTexture MapTexture(TextureHandle texture, uint subresource, MapMode mode, MapFlags flags) =>
        throw new NotSupportedException("DX12 texture mapping is intentionally not exposed for default/placed textures. Use buffer upload/readback slices and copy commands.");

    public override void UnmapTexture(TextureHandle texture, uint subresource) =>
        throw new NotSupportedException("DX12 texture mapping is intentionally not exposed for default/placed textures. Use buffer upload/readback slices and copy commands.");

    public override unsafe TextureCopyLayout GetTextureCopyLayout(TextureHandle texture, uint subresource)
    {
        ThrowIfDisposed();

        var state = _textures.Get(texture);
        var subresourceCount = GetSubresourceCount(state.Desc);
        if (subresource >= subresourceCount)
            throw new ArgumentOutOfRangeException(nameof(subresource), subresource, $"Texture has {subresourceCount} subresource(s).");

        var nativeDesc = ToTextureResourceDesc(state.Desc);
        PlacedSubresourceFootprint footprint = default;
        uint rowCount = 0;
        ulong rowSizeInBytes = 0;
        ulong totalBytes = 0;
        _nativeDevice.GetCopyableFootprints(
            &nativeDesc,
            subresource,
            1,
            0,
            &footprint,
            &rowCount,
            &rowSizeInBytes,
            &totalBytes);

        var slicePitch = (ulong)footprint.Footprint.RowPitch * rowCount;
        return new TextureCopyLayout(footprint.Offset, footprint.Footprint.RowPitch, slicePitch, rowCount);
    }

    public override UploadSlice AllocateUpload(ulong size, ulong alignment)
    {
        ThrowIfDisposed();
        ValidateAllocation(size, alignment);

        var alignedSize = Dx12Conversions.AlignUp(size, alignment);
        var buffer = CreateBuffer(new BufferDesc(
            DebugName: "UploadSlice",
            SizeInBytes: alignedSize,
            Usage: BufferUsageFlags.CopySource,
            Placement: ResourcePlacement.Committed(MemoryUsage.CpuToGpu)));
        var mapped = MapBuffer(buffer, MapMode.Write, MapFlags.None);
        return new UploadSlice(buffer, 0, size, mapped.CpuPointer);
    }

    public override ReadbackSlice AllocateReadback(ulong size, ulong alignment)
    {
        ThrowIfDisposed();
        ValidateAllocation(size, alignment);

        var alignedSize = Dx12Conversions.AlignUp(size, alignment);
        var buffer = CreateBuffer(new BufferDesc(
            DebugName: "ReadbackSlice",
            SizeInBytes: alignedSize,
            Usage: BufferUsageFlags.CopyDestination,
            Placement: ResourcePlacement.Committed(MemoryUsage.GpuToCpu)));
        return new ReadbackSlice(buffer, 0, size, 0);
    }

    public override unsafe ReadOnlySpan<byte> MapReadback(ReadbackSlice slice)
    {
        ThrowIfDisposed();
        if (!slice.Buffer.IsValid)
            throw new ArgumentException("Readback slice requires a valid buffer handle.", nameof(slice));
        if (slice.Size > int.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(slice), slice.Size, "Readback spans larger than int.MaxValue bytes are not supported by ReadOnlySpan<byte>.");

        var state = _buffers.Get(slice.Buffer);
        if (slice.Offset + slice.Size > state.Desc.SizeInBytes)
            throw new ArgumentOutOfRangeException(nameof(slice), slice.Size, "Readback slice is outside the backing buffer.");
        if (state.Desc.Placement.MemoryUsage != MemoryUsage.GpuToCpu)
            throw new ArgumentException("Readback slice buffer must use GpuToCpu memory.", nameof(slice));

        var pointer = state.MappedPointer;
        if (pointer == IntPtr.Zero)
            pointer = MapBuffer(slice.Buffer, MapMode.Read, MapFlags.None).CpuPointer;

        return new ReadOnlySpan<byte>((byte*)pointer + checked((nint)slice.Offset), checked((int)slice.Size));
    }

    public override void Dispose()
    {
        if (_disposed)
            return;

        _descriptorSets.DisposeAll();
        _descriptorSetLayouts.DisposeAll();
        _samplers.DisposeAll();
        _textureViews.DisposeAll();
        _bufferViews.DisposeAll();
        _textures.DisposeAll();
        _buffers.DisposeAll();
        _resourceHeaps.DisposeAll();
        _fences.DisposeAll();
        _dsvDescriptors.Dispose();
        _rtvDescriptors.Dispose();
        _samplerDescriptors.Dispose();
        _cbvSrvUavDescriptors.Dispose();
        _copyQueue.Dispose();
        _computeQueue.Dispose();
        _graphicsQueue.Dispose();
        _nativeDevice.Dispose();
        _adapter.Dispose();
        _factory.Dispose();
        (_dxgi as IDisposable)?.Dispose();
        (_d3d12 as IDisposable)?.Dispose();
        _disposed = true;
    }

    private static SilkDx12Device Create(SilkD3D12 d3d12, SilkDXGI dxgi)
    {
        ComPtr<DxgiFactory1> factory = default;
        Dx12Exceptions.ThrowIfFailed(
            dxgi.CreateDXGIFactory2(0, out factory),
            "CreateDXGIFactory2(IDXGIFactory1)");

        ComPtr<DxgiAdapter1> adapter = default;
        Dx12Exceptions.ThrowIfFailed(
            factory.EnumAdapters1(0, ref adapter),
            "IDXGIFactory1.EnumAdapters1(0)");

        ComPtr<D3D12Device> nativeDevice = default;
        Dx12Exceptions.ThrowIfFailed(
            d3d12.CreateDevice(adapter, D3DFeatureLevel.Level120, out nativeDevice),
            "D3D12.CreateDevice(Level120)");

        return new SilkDx12Device(d3d12, dxgi, factory, adapter, nativeDevice);
    }

    private Dx12QueueState CreateQueue(QueueKind kind, QueueHandle handle, string debugName)
    {
        var desc = new CommandQueueDesc
        {
            Type = ToCommandListType(kind),
            Priority = 0,
            Flags = CommandQueueFlags.None,
            NodeMask = 0,
        };

        ComPtr<D3D12CommandQueue> nativeQueue = default;
        Dx12Exceptions.ThrowIfFailed(
            _nativeDevice.CreateCommandQueue(in desc, out nativeQueue),
            $"ID3D12Device.CreateCommandQueue({kind})");

        Dx12Exceptions.ThrowIfFailed(
            nativeQueue.SetName(debugName),
            $"ID3D12CommandQueue.SetName({debugName})");
        return new Dx12QueueState(kind, handle, nativeQueue, debugName, this);
    }

    private Dx12QueueState GetQueueState(Queue queue)
    {
        ArgumentNullException.ThrowIfNull(queue);

        if (!ReferenceEquals(queue.Owner, this))
            throw new ArgumentException("Queue is invalid or not owned by this device.", nameof(queue));

        if (queue.Handle == _graphicsQueue.Handle)
            return _graphicsQueue;
        if (queue.Handle == _computeQueue.Handle)
            return _computeQueue;
        if (queue.Handle == _copyQueue.Handle)
            return _copyQueue;

        throw new ArgumentException("Queue is invalid or not owned by this device.", nameof(queue));
    }

    private static void ValidateHeapDesc(in ResourceHeapDesc desc)
    {
        if (desc.SizeInBytes == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.SizeInBytes, "Resource heap size must be greater than zero.");
        _ = Dx12Conversions.ToHeapProperties(desc.MemoryUsage);
        _ = NormalizeHeapAlignment(desc.Alignment);
    }

    private static ulong NormalizeHeapAlignment(ulong alignment)
    {
        if (alignment == 0)
            return 0;
        if (alignment is Dx12Conversions.ResourcePlacementAlignment or Dx12Conversions.MsaaResourcePlacementAlignment)
            return alignment;

        throw new ArgumentOutOfRangeException(
            nameof(alignment),
            alignment,
            "DX12 heap alignment must be 0, 64KB, or 4MB.");
    }

    private static void ValidatePlacedResource(
        ResourcePlacement placement,
        ResourceHeapDesc heapDesc,
        ResourceMemoryRequirements requirements,
        string paramName)
    {
        if (placement.MemoryUsage != heapDesc.MemoryUsage)
            throw new ArgumentException("Placed resource memory usage must match the target resource heap.", paramName);
        if (placement.HeapOffset % requirements.Alignment != 0)
            throw new ArgumentException($"Placed resource offset must be aligned to {requirements.Alignment} bytes.", paramName);

        checked
        {
            if (placement.HeapOffset + requirements.SizeInBytes > heapDesc.SizeInBytes)
                throw new ArgumentException("Placed resource allocation exceeds the target resource heap size.", paramName);
        }
    }

    private static ResourceDesc ToBufferResourceDesc(in BufferDesc desc)
    {
        ValidateBufferDesc(desc);

        return new ResourceDesc
        {
            Dimension = ResourceDimension.Buffer,
            Alignment = 0,
            Width = desc.SizeInBytes,
            Height = 1,
            DepthOrArraySize = 1,
            MipLevels = 1,
            Format = DxgiFormat.FormatUnknown,
            SampleDesc = new DxgiSampleDesc { Count = 1, Quality = 0 },
            Layout = TextureLayout.LayoutRowMajor,
            Flags = ToBufferResourceFlags(desc.Usage),
        };
    }

    private static void ValidateBufferDesc(in BufferDesc desc)
    {
        if (desc.SizeInBytes == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.SizeInBytes, "Buffer size must be greater than zero.");
        _ = Dx12Conversions.ToHeapProperties(desc.Placement.MemoryUsage);
        if (desc.Placement.Kind == ResourcePlacementKind.Placed && !desc.Placement.Heap.IsValid)
            throw new ArgumentException("Placed buffer requires a valid resource heap.", nameof(desc));
        if (desc.Placement.Kind is not ResourcePlacementKind.Committed and not ResourcePlacementKind.Placed)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.Placement.Kind, "Unsupported resource placement kind.");
        if (desc.Placement.MemoryUsage == MemoryUsage.GpuToCpu && !desc.Usage.HasFlag(BufferUsageFlags.CopyDestination))
            throw new ArgumentException("GpuToCpu buffers must include CopyDestination usage.", nameof(desc));
        if (desc.Placement.MemoryUsage == MemoryUsage.CpuToGpu && !desc.Usage.HasFlag(BufferUsageFlags.CopySource))
            throw new ArgumentException("CpuToGpu buffers must include CopySource usage.", nameof(desc));
    }

    private static ResourceFlags ToBufferResourceFlags(BufferUsageFlags usage)
    {
        var flags = ResourceFlags.None;
        if (usage.HasFlag(BufferUsageFlags.ReadWrite))
            flags |= ResourceFlags.AllowUnorderedAccess;
        if (usage.HasFlag(BufferUsageFlags.AccelerationStructure))
            flags |= ResourceFlags.RaytracingAccelerationStructure;
        return flags;
    }

    private static ResourceDesc ToTextureResourceDesc(in TextureDesc desc)
    {
        ValidateTextureDesc(desc);

        var sampleCount = desc.SampleCount == 0 ? 1u : desc.SampleCount;
        return new ResourceDesc
        {
            Dimension = desc.Dimension switch
            {
                TextureDimension.Texture1D => ResourceDimension.Texture1D,
                TextureDimension.Texture2D => ResourceDimension.Texture2D,
                TextureDimension.Texture3D => ResourceDimension.Texture3D,
                TextureDimension.Cube => ResourceDimension.Texture2D,
                _ => throw new ArgumentOutOfRangeException(nameof(desc), desc.Dimension, "Unsupported texture dimension."),
            },
            Alignment = 0,
            Width = desc.Width,
            Height = desc.Dimension == TextureDimension.Texture1D ? 1 : desc.Height,
            DepthOrArraySize = desc.DepthOrArrayLayers,
            MipLevels = desc.MipLevels,
            Format = Dx12Conversions.ToDxgiFormat(desc.Format),
            SampleDesc = new DxgiSampleDesc { Count = sampleCount, Quality = 0 },
            Layout = TextureLayout.LayoutUnknown,
            Flags = ToTextureResourceFlags(desc.Usage),
        };
    }

    private static void ValidateTextureDesc(in TextureDesc desc)
    {
        if (desc.Width == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.Width, "Texture width must be greater than zero.");
        if (desc.Dimension != TextureDimension.Texture1D && desc.Height == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.Height, "Texture height must be greater than zero.");
        if (desc.DepthOrArrayLayers == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.DepthOrArrayLayers, "Texture depth/array layer count must be greater than zero.");
        if (desc.MipLevels == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.MipLevels, "Texture mip level count must be greater than zero.");
        if (desc.SampleCount == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.SampleCount, "Texture sample count must be greater than zero.");
        if (desc.SampleCount > 1 && desc.Dimension != TextureDimension.Texture2D)
            throw new ArgumentException("Only 2D textures may use MSAA sample counts greater than one.", nameof(desc));
        if (desc.SampleCount > 1 && desc.MipLevels != 1)
            throw new ArgumentException("MSAA textures must have exactly one mip level.", nameof(desc));
        if (desc.Dimension == TextureDimension.Cube && desc.DepthOrArrayLayers % 6 != 0)
            throw new ArgumentException("Cube textures require DepthOrArrayLayers to be a multiple of six.", nameof(desc));
        if (desc.Placement.MemoryUsage != MemoryUsage.GpuOnly)
            throw new ArgumentException("DX12 textures in this backend must use GpuOnly memory; stage data through upload/readback buffers.", nameof(desc));
        if (desc.Placement.Kind == ResourcePlacementKind.Placed && !desc.Placement.Heap.IsValid)
            throw new ArgumentException("Placed texture requires a valid resource heap.", nameof(desc));
        if (desc.Placement.Kind is not ResourcePlacementKind.Committed and not ResourcePlacementKind.Placed)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.Placement.Kind, "Unsupported resource placement kind.");
        if (desc.Format == ApiFormat.Unknown)
            throw new ArgumentException("Texture format must be known.", nameof(desc));
    }

    private static ResourceFlags ToTextureResourceFlags(TextureUsageFlags usage)
    {
        var flags = ResourceFlags.None;
        if (usage.HasFlag(TextureUsageFlags.RenderTarget))
            flags |= ResourceFlags.AllowRenderTarget;
        if (usage.HasFlag(TextureUsageFlags.DepthStencil))
            flags |= ResourceFlags.AllowDepthStencil;
        if (usage.HasFlag(TextureUsageFlags.ReadWrite))
            flags |= ResourceFlags.AllowUnorderedAccess;
        return flags;
    }

    private static bool TryCreateClearValue(
        ApiClearValue clearValue,
        TextureUsageFlags usage,
        out Dx12ClearValue native)
    {
        native = default;
        switch (clearValue.Kind)
        {
            case ClearValueKind.None:
                return false;
            case ClearValueKind.Color:
                if (!usage.HasFlag(TextureUsageFlags.RenderTarget))
                    throw new ArgumentException("Color optimized clear values require RenderTarget usage.", nameof(clearValue));
                _ = Dx12Conversions.ToDxgiFormat(clearValue.Format);
                return false;
            case ClearValueKind.DepthStencil:
                if (!usage.HasFlag(TextureUsageFlags.DepthStencil))
                    throw new ArgumentException("Depth/stencil optimized clear values require DepthStencil usage.", nameof(clearValue));

                _ = Dx12Conversions.ToDxgiFormat(clearValue.Format);
                return false;
            default:
                throw new ArgumentOutOfRangeException(nameof(clearValue), clearValue.Kind, "Unsupported clear value kind.");
        }
    }

    private Dx12DescriptorSlot CreateBufferDescriptor(Dx12BufferState buffer, in BufferViewDesc desc)
    {
        ValidateBufferViewDesc(buffer.Desc, desc);

        var slot = _cbvSrvUavDescriptors.Allocate();
        try
        {
            switch (desc.Kind)
            {
                case BufferViewKind.ConstantBuffer:
                    CreateConstantBufferDescriptor(buffer, desc, slot);
                    break;
                case BufferViewKind.ShaderResource:
                    CreateShaderResourceBufferDescriptor(buffer, desc, slot);
                    break;
                case BufferViewKind.UnorderedAccess:
                    CreateUnorderedAccessBufferDescriptor(buffer, desc, slot);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(desc), desc.Kind, "Unsupported buffer view kind.");
            }

            return slot;
        }
        catch
        {
            slot.Dispose();
            throw;
        }
    }

    private static void ValidateBufferViewDesc(in BufferDesc buffer, in BufferViewDesc desc)
    {
        if (desc.SizeInBytes == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.SizeInBytes, "Buffer view size must be greater than zero.");
        checked
        {
            if (desc.Offset + desc.SizeInBytes > buffer.SizeInBytes)
                throw new ArgumentException("Buffer view range exceeds the backing buffer.", nameof(desc));
        }

        switch (desc.Kind)
        {
            case BufferViewKind.ConstantBuffer:
                if (!buffer.Usage.HasFlag(BufferUsageFlags.Constant))
                    throw new ArgumentException("Constant buffer views require Constant buffer usage.", nameof(desc));
                if (desc.Offset % Dx12Conversions.ConstantBufferAlignment != 0)
                    throw new ArgumentException("Constant buffer view offset must be 256-byte aligned.", nameof(desc));
                if (Dx12Conversions.AlignUp(desc.SizeInBytes, Dx12Conversions.ConstantBufferAlignment) > uint.MaxValue)
                    throw new ArgumentOutOfRangeException(nameof(desc), desc.SizeInBytes, "D3D12 constant buffer views cannot exceed uint.MaxValue bytes.");
                break;
            case BufferViewKind.ShaderResource:
                if (!buffer.Usage.HasFlag(BufferUsageFlags.Structured) && !buffer.Usage.HasFlag(BufferUsageFlags.ByteAddress))
                    throw new ArgumentException("Shader resource buffer views require Structured or ByteAddress buffer usage.", nameof(desc));
                ValidateBufferElementLayout(buffer.Usage, desc);
                break;
            case BufferViewKind.UnorderedAccess:
                if (!buffer.Usage.HasFlag(BufferUsageFlags.ReadWrite))
                    throw new ArgumentException("Unordered access buffer views require ReadWrite buffer usage.", nameof(desc));
                if (!buffer.Usage.HasFlag(BufferUsageFlags.Structured) && !buffer.Usage.HasFlag(BufferUsageFlags.ByteAddress))
                    throw new ArgumentException("Unordered access buffer views require Structured or ByteAddress buffer usage.", nameof(desc));
                ValidateBufferElementLayout(buffer.Usage, desc);
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(desc), desc.Kind, "Unsupported buffer view kind.");
        }
    }

    private static void ValidateBufferElementLayout(BufferUsageFlags usage, in BufferViewDesc desc)
    {
        if (desc.StrideInBytes == 0)
        {
            if (!usage.HasFlag(BufferUsageFlags.ByteAddress))
                throw new ArgumentException("Raw buffer views require ByteAddress usage.", nameof(desc));
            if (desc.Offset % 4 != 0 || desc.SizeInBytes % 4 != 0)
                throw new ArgumentException("Raw buffer view offset and size must be 4-byte aligned.", nameof(desc));
            return;
        }

        if (!usage.HasFlag(BufferUsageFlags.Structured))
            throw new ArgumentException("Structured buffer views require Structured usage.", nameof(desc));
        if (desc.Offset % desc.StrideInBytes != 0 || desc.SizeInBytes % desc.StrideInBytes != 0)
            throw new ArgumentException("Structured buffer view offset and size must be multiples of StrideInBytes.", nameof(desc));
    }

    private void CreateConstantBufferDescriptor(Dx12BufferState buffer, in BufferViewDesc desc, Dx12DescriptorSlot slot)
    {
        var alignedSize = Dx12Conversions.AlignUp(desc.SizeInBytes, Dx12Conversions.ConstantBufferAlignment);
        checked
        {
            if (desc.Offset + alignedSize > buffer.Desc.SizeInBytes)
                throw new ArgumentException("Aligned constant buffer view range exceeds the backing buffer.", nameof(desc));

            var nativeDesc = new ConstantBufferViewDesc
            {
                BufferLocation = buffer.NativeResource.GetGPUVirtualAddress() + desc.Offset,
                SizeInBytes = (uint)alignedSize,
            };
            _nativeDevice.CreateConstantBufferView(in nativeDesc, slot.CpuHandle);
        }
    }

    private void CreateShaderResourceBufferDescriptor(Dx12BufferState buffer, in BufferViewDesc desc, Dx12DescriptorSlot slot)
    {
        var nativeDesc = new ShaderResourceViewDesc
        {
            Format = desc.StrideInBytes == 0 ? DxgiFormat.FormatR32Typeless : DxgiFormat.FormatUnknown,
            ViewDimension = SrvDimension.Buffer,
            Shader4ComponentMapping = Dx12Conversions.DefaultShader4ComponentMapping,
            Anonymous =
            {
                Buffer = CreateBufferSrv(desc),
            },
        };
        _nativeDevice.CreateShaderResourceView(buffer.NativeResource, in nativeDesc, slot.CpuHandle);
    }

    private unsafe void CreateUnorderedAccessBufferDescriptor(Dx12BufferState buffer, in BufferViewDesc desc, Dx12DescriptorSlot slot)
    {
        var nativeDesc = new UnorderedAccessViewDesc
        {
            Format = desc.StrideInBytes == 0 ? DxgiFormat.FormatR32Typeless : DxgiFormat.FormatUnknown,
            ViewDimension = UavDimension.Buffer,
            Anonymous =
            {
                Buffer = CreateBufferUav(desc),
            },
        };
        _nativeDevice.CreateUnorderedAccessView(
            buffer.NativeResource,
            (D3D12Resource*)null,
            in nativeDesc,
            slot.CpuHandle);
    }

    private static BufferSrv CreateBufferSrv(in BufferViewDesc desc)
    {
        var raw = desc.StrideInBytes == 0;
        return new BufferSrv
        {
            FirstElement = raw ? desc.Offset / 4 : desc.Offset / desc.StrideInBytes,
            NumElements = checked((uint)(raw ? desc.SizeInBytes / 4 : desc.SizeInBytes / desc.StrideInBytes)),
            StructureByteStride = raw ? 0 : desc.StrideInBytes,
            Flags = raw ? BufferSrvFlags.Raw : BufferSrvFlags.None,
        };
    }

    private static BufferUav CreateBufferUav(in BufferViewDesc desc)
    {
        var raw = desc.StrideInBytes == 0;
        return new BufferUav
        {
            FirstElement = raw ? desc.Offset / 4 : desc.Offset / desc.StrideInBytes,
            NumElements = checked((uint)(raw ? desc.SizeInBytes / 4 : desc.SizeInBytes / desc.StrideInBytes)),
            StructureByteStride = raw ? 0 : desc.StrideInBytes,
            CounterOffsetInBytes = 0,
            Flags = raw ? BufferUavFlags.Raw : BufferUavFlags.None,
        };
    }

    private static BufferViewDesc CreateDefaultBufferViewDesc(in BufferDesc buffer, BufferViewKind kind)
    {
        var stride = 0u;
        if (kind != BufferViewKind.ConstantBuffer)
        {
            if (!buffer.Usage.HasFlag(BufferUsageFlags.ByteAddress))
                throw new InvalidOperationException("Default shader/UAV buffer views require ByteAddress usage; create an explicit view with StrideInBytes for structured buffers.");
            stride = 0;
        }

        return new BufferViewDesc(
            DebugName: buffer.DebugName is null ? null : $"{buffer.DebugName}.{kind}",
            Kind: kind,
            Offset: 0,
            SizeInBytes: buffer.SizeInBytes,
            StrideInBytes: stride);
    }

    private Dx12DescriptorSlot CreateTextureDescriptor(Dx12TextureState texture, in TextureViewDesc desc)
    {
        ValidateTextureViewDesc(texture.Desc, desc);

        var allocator = desc.Kind switch
        {
            TextureViewKind.ShaderResource or TextureViewKind.UnorderedAccess => _cbvSrvUavDescriptors,
            TextureViewKind.RenderTarget => _rtvDescriptors,
            TextureViewKind.DepthStencil => _dsvDescriptors,
            _ => throw new ArgumentOutOfRangeException(nameof(desc), desc.Kind, "Unsupported texture view kind."),
        };
        var slot = allocator.Allocate();
        try
        {
            switch (desc.Kind)
            {
                case TextureViewKind.ShaderResource:
                    CreateShaderResourceTextureDescriptor(texture, desc, slot);
                    break;
                case TextureViewKind.UnorderedAccess:
                    CreateUnorderedAccessTextureDescriptor(texture, desc, slot);
                    break;
                case TextureViewKind.RenderTarget:
                    CreateRenderTargetDescriptor(texture, desc, slot);
                    break;
                case TextureViewKind.DepthStencil:
                    CreateDepthStencilDescriptor(texture, desc, slot);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(desc), desc.Kind, "Unsupported texture view kind.");
            }

            return slot;
        }
        catch
        {
            slot.Dispose();
            throw;
        }
    }

    private static void ValidateTextureViewDesc(in TextureDesc texture, in TextureViewDesc desc)
    {
        if (desc.MipLevelCount == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.MipLevelCount, "Texture view mip level count must be greater than zero.");
        if (desc.ArrayLayerCount == 0)
            throw new ArgumentOutOfRangeException(nameof(desc), desc.ArrayLayerCount, "Texture view array layer count must be greater than zero.");
        checked
        {
            if (desc.BaseMipLevel + desc.MipLevelCount > texture.MipLevels)
                throw new ArgumentException("Texture view mip range exceeds the texture.", nameof(desc));
            if (desc.BaseArrayLayer + desc.ArrayLayerCount > texture.DepthOrArrayLayers)
                throw new ArgumentException("Texture view array/depth range exceeds the texture.", nameof(desc));
        }

        if (desc.Format == ApiFormat.Unknown && texture.Format == ApiFormat.Unknown)
            throw new ArgumentException("Texture view format must be known.", nameof(desc));

        switch (desc.Kind)
        {
            case TextureViewKind.ShaderResource:
                if (!texture.Usage.HasFlag(TextureUsageFlags.ShaderResource))
                    throw new ArgumentException("Shader resource texture views require ShaderResource texture usage.", nameof(desc));
                if (texture.Dimension == TextureDimension.Texture3D && (desc.BaseArrayLayer != 0 || desc.ArrayLayerCount != 1))
                    throw new ArgumentException("3D texture SRVs cover depth through the texture resource, not array-layer ranges.", nameof(desc));
                break;
            case TextureViewKind.UnorderedAccess:
                if (!texture.Usage.HasFlag(TextureUsageFlags.ReadWrite))
                    throw new ArgumentException("Unordered access texture views require ReadWrite texture usage.", nameof(desc));
                if (desc.MipLevelCount != 1)
                    throw new ArgumentException("D3D12 unordered access texture views target exactly one mip level.", nameof(desc));
                if (texture.SampleCount > 1)
                    throw new ArgumentException("MSAA textures cannot be exposed as unordered access views.", nameof(desc));
                break;
            case TextureViewKind.RenderTarget:
                if (!texture.Usage.HasFlag(TextureUsageFlags.RenderTarget))
                    throw new ArgumentException("Render target views require RenderTarget texture usage.", nameof(desc));
                if (desc.MipLevelCount != 1)
                    throw new ArgumentException("D3D12 render target views target exactly one mip level.", nameof(desc));
                break;
            case TextureViewKind.DepthStencil:
                if (!texture.Usage.HasFlag(TextureUsageFlags.DepthStencil))
                    throw new ArgumentException("Depth/stencil views require DepthStencil texture usage.", nameof(desc));
                if (texture.Dimension == TextureDimension.Texture3D)
                    throw new ArgumentException("D3D12 depth/stencil views do not support 3D textures.", nameof(desc));
                if (desc.MipLevelCount != 1)
                    throw new ArgumentException("D3D12 depth/stencil views target exactly one mip level.", nameof(desc));
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(desc), desc.Kind, "Unsupported texture view kind.");
        }

        if (texture.Dimension == TextureDimension.Cube && desc.Kind == TextureViewKind.ShaderResource && desc.ArrayLayerCount % 6 != 0)
            throw new ArgumentException("Cube texture SRV array layer count must be a multiple of six.", nameof(desc));
    }

    private void CreateShaderResourceTextureDescriptor(Dx12TextureState texture, in TextureViewDesc desc, Dx12DescriptorSlot slot)
    {
        var nativeDesc = new ShaderResourceViewDesc
        {
            Format = ResolveTextureViewFormat(texture.Desc, desc),
            Shader4ComponentMapping = Dx12Conversions.DefaultShader4ComponentMapping,
        };

        FillTextureSrv(texture.Desc, desc, ref nativeDesc);
        _nativeDevice.CreateShaderResourceView(texture.NativeResource, in nativeDesc, slot.CpuHandle);
    }

    private unsafe void CreateUnorderedAccessTextureDescriptor(Dx12TextureState texture, in TextureViewDesc desc, Dx12DescriptorSlot slot)
    {
        var nativeDesc = new UnorderedAccessViewDesc
        {
            Format = ResolveTextureViewFormat(texture.Desc, desc),
        };

        FillTextureUav(texture.Desc, desc, ref nativeDesc);
        _nativeDevice.CreateUnorderedAccessView(texture.NativeResource, (D3D12Resource*)null, in nativeDesc, slot.CpuHandle);
    }

    private void CreateRenderTargetDescriptor(Dx12TextureState texture, in TextureViewDesc desc, Dx12DescriptorSlot slot)
    {
        var nativeDesc = new RenderTargetViewDesc
        {
            Format = ResolveTextureViewFormat(texture.Desc, desc),
        };

        FillTextureRtv(texture.Desc, desc, ref nativeDesc);
        _nativeDevice.CreateRenderTargetView(texture.NativeResource, in nativeDesc, slot.CpuHandle);
    }

    private void CreateDepthStencilDescriptor(Dx12TextureState texture, in TextureViewDesc desc, Dx12DescriptorSlot slot)
    {
        var nativeDesc = new DepthStencilViewDesc
        {
            Format = ResolveTextureViewFormat(texture.Desc, desc),
            Flags = DsvFlags.None,
        };

        FillTextureDsv(texture.Desc, desc, ref nativeDesc);
        _nativeDevice.CreateDepthStencilView(texture.NativeResource, in nativeDesc, slot.CpuHandle);
    }

    private static DxgiFormat ResolveTextureViewFormat(in TextureDesc texture, in TextureViewDesc view) =>
        Dx12Conversions.ToDxgiFormat(view.Format == ApiFormat.Unknown ? texture.Format : view.Format);

    private static void FillTextureSrv(in TextureDesc texture, in TextureViewDesc view, ref ShaderResourceViewDesc native)
    {
        switch (texture.Dimension)
        {
            case TextureDimension.Texture1D when view.ArrayLayerCount == 1:
                native.ViewDimension = SrvDimension.Texture1D;
                native.Anonymous.Texture1D = new Tex1DSrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    ResourceMinLODClamp = 0,
                };
                break;
            case TextureDimension.Texture1D:
                native.ViewDimension = SrvDimension.Texture1Darray;
                native.Anonymous.Texture1DArray = new Tex1DArraySrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                    ResourceMinLODClamp = 0,
                };
                break;
            case TextureDimension.Texture2D when texture.SampleCount > 1 && view.ArrayLayerCount == 1:
                native.ViewDimension = SrvDimension.Texture2Dms;
                native.Anonymous.Texture2DMS = new Tex2DmsSrv();
                break;
            case TextureDimension.Texture2D when texture.SampleCount > 1:
                native.ViewDimension = SrvDimension.Texture2Dmsarray;
                native.Anonymous.Texture2DMSArray = new Tex2DmsArraySrv
                {
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            case TextureDimension.Texture2D when view.ArrayLayerCount == 1:
                native.ViewDimension = SrvDimension.Texture2D;
                native.Anonymous.Texture2D = new Tex2DSrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    PlaneSlice = 0,
                    ResourceMinLODClamp = 0,
                };
                break;
            case TextureDimension.Texture2D:
                native.ViewDimension = SrvDimension.Texture2Darray;
                native.Anonymous.Texture2DArray = new Tex2DArraySrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                    PlaneSlice = 0,
                    ResourceMinLODClamp = 0,
                };
                break;
            case TextureDimension.Cube when view.ArrayLayerCount == 6:
                native.ViewDimension = SrvDimension.Texturecube;
                native.Anonymous.TextureCube = new TexcubeSrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    ResourceMinLODClamp = 0,
                };
                break;
            case TextureDimension.Cube:
                native.ViewDimension = SrvDimension.Texturecubearray;
                native.Anonymous.TextureCubeArray = new TexcubeArraySrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    First2DArrayFace = view.BaseArrayLayer,
                    NumCubes = view.ArrayLayerCount / 6,
                    ResourceMinLODClamp = 0,
                };
                break;
            case TextureDimension.Texture3D:
                native.ViewDimension = SrvDimension.Texture3D;
                native.Anonymous.Texture3D = new Tex3DSrv
                {
                    MostDetailedMip = view.BaseMipLevel,
                    MipLevels = view.MipLevelCount,
                    ResourceMinLODClamp = 0,
                };
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(texture), texture.Dimension, "Unsupported texture dimension.");
        }
    }

    private static void FillTextureUav(in TextureDesc texture, in TextureViewDesc view, ref UnorderedAccessViewDesc native)
    {
        switch (texture.Dimension)
        {
            case TextureDimension.Texture1D when view.ArrayLayerCount == 1:
                native.ViewDimension = UavDimension.Texture1D;
                native.Anonymous.Texture1D = new Tex1DUav { MipSlice = view.BaseMipLevel };
                break;
            case TextureDimension.Texture1D:
                native.ViewDimension = UavDimension.Texture1Darray;
                native.Anonymous.Texture1DArray = new Tex1DArrayUav
                {
                    MipSlice = view.BaseMipLevel,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when view.ArrayLayerCount == 1:
                native.ViewDimension = UavDimension.Texture2D;
                native.Anonymous.Texture2D = new Tex2DUav { MipSlice = view.BaseMipLevel, PlaneSlice = 0 };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube:
                native.ViewDimension = UavDimension.Texture2Darray;
                native.Anonymous.Texture2DArray = new Tex2DArrayUav
                {
                    MipSlice = view.BaseMipLevel,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                    PlaneSlice = 0,
                };
                break;
            case TextureDimension.Texture3D:
                native.ViewDimension = UavDimension.Texture3D;
                native.Anonymous.Texture3D = new Tex3DUav
                {
                    MipSlice = view.BaseMipLevel,
                    FirstWSlice = view.BaseArrayLayer,
                    WSize = view.ArrayLayerCount,
                };
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(texture), texture.Dimension, "Unsupported texture dimension.");
        }
    }

    private static void FillTextureRtv(in TextureDesc texture, in TextureViewDesc view, ref RenderTargetViewDesc native)
    {
        switch (texture.Dimension)
        {
            case TextureDimension.Texture1D when view.ArrayLayerCount == 1:
                native.ViewDimension = RtvDimension.Texture1D;
                native.Anonymous.Texture1D = new Tex1DRtv { MipSlice = view.BaseMipLevel };
                break;
            case TextureDimension.Texture1D:
                native.ViewDimension = RtvDimension.Texture1Darray;
                native.Anonymous.Texture1DArray = new Tex1DArrayRtv
                {
                    MipSlice = view.BaseMipLevel,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when texture.SampleCount > 1 && view.ArrayLayerCount == 1:
                native.ViewDimension = RtvDimension.Texture2Dms;
                native.Anonymous.Texture2DMS = new Tex2DmsRtv();
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when texture.SampleCount > 1:
                native.ViewDimension = RtvDimension.Texture2Dmsarray;
                native.Anonymous.Texture2DMSArray = new Tex2DmsArrayRtv
                {
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when view.ArrayLayerCount == 1:
                native.ViewDimension = RtvDimension.Texture2D;
                native.Anonymous.Texture2D = new Tex2DRtv { MipSlice = view.BaseMipLevel, PlaneSlice = 0 };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube:
                native.ViewDimension = RtvDimension.Texture2Darray;
                native.Anonymous.Texture2DArray = new Tex2DArrayRtv
                {
                    MipSlice = view.BaseMipLevel,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                    PlaneSlice = 0,
                };
                break;
            case TextureDimension.Texture3D:
                native.ViewDimension = RtvDimension.Texture3D;
                native.Anonymous.Texture3D = new Tex3DRtv
                {
                    MipSlice = view.BaseMipLevel,
                    FirstWSlice = view.BaseArrayLayer,
                    WSize = view.ArrayLayerCount,
                };
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(texture), texture.Dimension, "Unsupported texture dimension.");
        }
    }

    private static void FillTextureDsv(in TextureDesc texture, in TextureViewDesc view, ref DepthStencilViewDesc native)
    {
        switch (texture.Dimension)
        {
            case TextureDimension.Texture1D when view.ArrayLayerCount == 1:
                native.ViewDimension = DsvDimension.Texture1D;
                native.Anonymous.Texture1D = new Tex1DDsv { MipSlice = view.BaseMipLevel };
                break;
            case TextureDimension.Texture1D:
                native.ViewDimension = DsvDimension.Texture1Darray;
                native.Anonymous.Texture1DArray = new Tex1DArrayDsv
                {
                    MipSlice = view.BaseMipLevel,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when texture.SampleCount > 1 && view.ArrayLayerCount == 1:
                native.ViewDimension = DsvDimension.Texture2Dms;
                native.Anonymous.Texture2DMS = new Tex2DmsDsv();
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when texture.SampleCount > 1:
                native.ViewDimension = DsvDimension.Texture2Dmsarray;
                native.Anonymous.Texture2DMSArray = new Tex2DmsArrayDsv
                {
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube when view.ArrayLayerCount == 1:
                native.ViewDimension = DsvDimension.Texture2D;
                native.Anonymous.Texture2D = new Tex2DDsv { MipSlice = view.BaseMipLevel };
                break;
            case TextureDimension.Texture2D or TextureDimension.Cube:
                native.ViewDimension = DsvDimension.Texture2Darray;
                native.Anonymous.Texture2DArray = new Tex2DArrayDsv
                {
                    MipSlice = view.BaseMipLevel,
                    FirstArraySlice = view.BaseArrayLayer,
                    ArraySize = view.ArrayLayerCount,
                };
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(texture), texture.Dimension, "Unsupported depth/stencil texture dimension.");
        }
    }

    private static TextureViewDesc CreateDefaultTextureViewDesc(in TextureDesc texture, TextureViewKind kind)
    {
        var arrayLayerCount = texture.Dimension == TextureDimension.Texture3D && kind == TextureViewKind.ShaderResource
            ? 1u
            : texture.DepthOrArrayLayers;

        return new TextureViewDesc(
            DebugName: texture.DebugName is null ? null : $"{texture.DebugName}.{kind}",
            Kind: kind,
            Format: texture.Format,
            BaseMipLevel: 0,
            MipLevelCount: kind == TextureViewKind.ShaderResource ? texture.MipLevels : 1u,
            BaseArrayLayer: 0,
            ArrayLayerCount: arrayLayerCount);
    }

    private static uint GetSubresourceCount(in TextureDesc desc) =>
        checked((uint)desc.MipLevels * desc.DepthOrArrayLayers);

    private static void ValidateBufferMapMode(MemoryUsage usage, MapMode mode)
    {
        switch (mode)
        {
            case MapMode.Write when usage == MemoryUsage.CpuToGpu:
            case MapMode.ReadWrite when usage == MemoryUsage.CpuToGpu:
            case MapMode.Read when usage == MemoryUsage.GpuToCpu:
                return;
            case MapMode.Read:
            case MapMode.Write:
            case MapMode.ReadWrite:
                throw new InvalidOperationException($"Cannot map a {usage} buffer with {mode} mode.");
            default:
                throw new ArgumentOutOfRangeException(nameof(mode), mode, "Unsupported map mode.");
        }
    }

    private static void ValidateAllocation(ulong size, ulong alignment)
    {
        if (size == 0)
            throw new ArgumentOutOfRangeException(nameof(size), size, "Allocation size must be greater than zero.");
        _ = Dx12Conversions.AlignUp(size, alignment);
    }

    private void ValidateDescriptorValue(DescriptorValue value)
    {
        if (value.IsNull)
            return;

        switch (value.Type)
        {
            case DescriptorType.ConstantBuffer:
                ValidateBufferDescriptorValue(value.BufferView, BufferViewKind.ConstantBuffer);
                break;
            case DescriptorType.StructuredBuffer:
            case DescriptorType.ByteAddressBuffer:
                ValidateBufferDescriptorValue(value.BufferView, BufferViewKind.ShaderResource);
                break;
            case DescriptorType.ReadWriteStructuredBuffer:
            case DescriptorType.ReadWriteByteAddressBuffer:
                ValidateBufferDescriptorValue(value.BufferView, BufferViewKind.UnorderedAccess);
                break;
            case DescriptorType.Texture:
                ValidateTextureDescriptorValue(value.TextureView, TextureViewKind.ShaderResource);
                break;
            case DescriptorType.ReadWriteTexture:
                ValidateTextureDescriptorValue(value.TextureView, TextureViewKind.UnorderedAccess);
                break;
            case DescriptorType.Sampler:
                if (!value.Sampler.IsValid || !_samplers.TryGet(value.Sampler, out _))
                    throw new ArgumentException("Sampler descriptor value references an invalid sampler.");
                break;
            case DescriptorType.AccelerationStructure:
                throw new NotSupportedException("Acceleration structure descriptors are not supported by the DX12 backend yet.");
            default:
                throw new ArgumentOutOfRangeException(nameof(value), value.Type, "Unsupported descriptor value type.");
        }
    }

    private void ValidateBufferDescriptorValue(BufferViewHandle view, BufferViewKind expectedKind)
    {
        if (!view.IsValid || !_bufferViews.TryGet(view, out var state) || state is null)
            throw new ArgumentException("Buffer descriptor value references an invalid buffer view.");
        if (state.Desc.Kind != expectedKind)
            throw new ArgumentException($"Buffer descriptor value references a {state.Desc.Kind} view, but {expectedKind} is required.");
    }

    private void ValidateTextureDescriptorValue(TextureViewHandle view, TextureViewKind expectedKind)
    {
        if (!view.IsValid || !_textureViews.TryGet(view, out var state) || state is null)
            throw new ArgumentException("Texture descriptor value references an invalid texture view.");
        if (state.Desc.Kind != expectedKind)
            throw new ArgumentException($"Texture descriptor value references a {state.Desc.Kind} view, but {expectedKind} is required.");
    }

    private static void SetObjectName(ComPtr<D3D12Resource> nativeObject, string? debugName, string objectName)
    {
        if (string.IsNullOrWhiteSpace(debugName))
            return;

        Dx12Exceptions.ThrowIfFailed(
            nativeObject.SetName(debugName),
            $"{objectName}.SetName({debugName})");
    }

    private static void SetObjectName(ComPtr<ID3D12Heap> nativeObject, string? debugName, string objectName)
    {
        if (string.IsNullOrWhiteSpace(debugName))
            return;

        Dx12Exceptions.ThrowIfFailed(
            nativeObject.SetName(debugName),
            $"{objectName}.SetName({debugName})");
    }

    private static CommandListType ToCommandListType(QueueKind kind) =>
        kind switch
        {
            QueueKind.Graphics => CommandListType.Direct,
            QueueKind.Compute => CommandListType.Compute,
            QueueKind.Copy => CommandListType.Copy,
            _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported queue kind."),
        };

    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(SilkDx12Device));
    }

    private static ulong GetCompletedFenceValue(Dx12FenceState state)
    {
        var completedValue = state.NativeFence.GetCompletedValue();
        if (completedValue == ulong.MaxValue)
            throw new InvalidOperationException("ID3D12Fence.GetCompletedValue returned UINT64_MAX; the device may be removed.");

        return completedValue;
    }

    private static NotSupportedException UnsupportedFeature(string memberName) =>
        new($"{memberName} is not supported by the DX12 backend yet.");
}
