using System;
using SomeEngine.RHI;
using Silk.NET.Direct3D12;
using DxgiFormat = Silk.NET.DXGI.Format;
using Dx12AddressMode = Silk.NET.Direct3D12.TextureAddressMode;
using Dx12Filter = Silk.NET.Direct3D12.Filter;
using Dx12SamplerDesc = Silk.NET.Direct3D12.SamplerDesc;
using ApiAddressMode = SomeEngine.RHI.TextureAddressMode;
using ApiFormat = SomeEngine.RHI.Format;
using ApiSamplerDesc = SomeEngine.RHI.SamplerDesc;

namespace SomeEngine.RHI.Backends.Dx12;

internal static class Dx12Conversions
{
    public const uint DefaultShader4ComponentMapping = 5768;
    public const ulong ConstantBufferAlignment = 256;
    public const ulong ResourcePlacementAlignment = 64 * 1024;
    public const ulong MsaaResourcePlacementAlignment = 4 * 1024 * 1024;

    public static DxgiFormat ToDxgiFormat(ApiFormat format) =>
        format switch
        {
            ApiFormat.Unknown => DxgiFormat.FormatUnknown,
            ApiFormat.R8G8B8A8UNorm => DxgiFormat.FormatR8G8B8A8Unorm,
            ApiFormat.R8G8B8A8UNormSrgb => DxgiFormat.FormatR8G8B8A8UnormSrgb,
            ApiFormat.B8G8R8A8UNorm => DxgiFormat.FormatB8G8R8A8Unorm,
            ApiFormat.R16G16Float => DxgiFormat.FormatR16G16Float,
            ApiFormat.R16G16B16A16Float => DxgiFormat.FormatR16G16B16A16Float,
            ApiFormat.R32UInt => DxgiFormat.FormatR32Uint,
            ApiFormat.R32Float => DxgiFormat.FormatR32Float,
            ApiFormat.R32G32Float => DxgiFormat.FormatR32G32Float,
            ApiFormat.R32G32B32Float => DxgiFormat.FormatR32G32B32Float,
            ApiFormat.R32G32B32A32Float => DxgiFormat.FormatR32G32B32A32Float,
            ApiFormat.D16UNorm => DxgiFormat.FormatD16Unorm,
            ApiFormat.D24UNormS8UInt => DxgiFormat.FormatD24UnormS8Uint,
            ApiFormat.D32Float => DxgiFormat.FormatD32Float,
            ApiFormat.D32FloatS8UInt => DxgiFormat.FormatD32FloatS8X24Uint,
            _ => throw new ArgumentOutOfRangeException(nameof(format), format, "Unsupported format."),
        };

    public static HeapProperties ToHeapProperties(MemoryUsage usage) =>
        new()
        {
            Type = usage switch
            {
                MemoryUsage.GpuOnly => HeapType.Default,
                MemoryUsage.CpuToGpu => HeapType.Upload,
                MemoryUsage.GpuToCpu => HeapType.Readback,
                _ => throw new ArgumentOutOfRangeException(nameof(usage), usage, "Unsupported memory usage."),
            },
            CPUPageProperty = CpuPageProperty.Unknown,
            MemoryPoolPreference = MemoryPool.Unknown,
            CreationNodeMask = 1,
            VisibleNodeMask = 1,
        };

    public static ResourceStates InitialBufferState(BufferDesc desc) =>
        desc.Placement.MemoryUsage switch
        {
            MemoryUsage.CpuToGpu => ResourceStates.GenericRead,
            MemoryUsage.GpuToCpu => ResourceStates.CopyDest,
            MemoryUsage.GpuOnly when desc.Usage.HasFlag(BufferUsageFlags.AccelerationStructure) =>
                ResourceStates.RaytracingAccelerationStructure,
            MemoryUsage.GpuOnly => ResourceStates.Common,
            _ => throw new ArgumentOutOfRangeException(nameof(desc), desc.Placement.MemoryUsage, "Unsupported memory usage."),
        };

    public static ResourceStates InitialTextureState(TextureDesc desc) =>
        desc.Usage.HasFlag(TextureUsageFlags.Present) ? ResourceStates.Present : ResourceStates.Common;

    public static ResourceStates ToDx12States(ResourceState state)
    {
        if (state is ResourceState.Unknown or ResourceState.Undefined)
            return ResourceStates.Common;

        ResourceStates result = 0;
        if (state.HasFlag(ResourceState.ConstantBuffer) || state.HasFlag(ResourceState.VertexBuffer))
            result |= ResourceStates.VertexAndConstantBuffer;
        if (state.HasFlag(ResourceState.IndexBuffer))
            result |= ResourceStates.IndexBuffer;
        if (state.HasFlag(ResourceState.RenderTarget))
            result |= ResourceStates.RenderTarget;
        if (state.HasFlag(ResourceState.DepthWrite))
            result |= ResourceStates.DepthWrite;
        if (state.HasFlag(ResourceState.DepthRead))
            result |= ResourceStates.DepthRead;
        if (state.HasFlag(ResourceState.ShaderResource))
            result |= ResourceStates.PixelShaderResource | ResourceStates.NonPixelShaderResource;
        if (state.HasFlag(ResourceState.UnorderedAccess))
            result |= ResourceStates.UnorderedAccess;
        if (state.HasFlag(ResourceState.IndirectArgument))
            result |= ResourceStates.IndirectArgument;
        if (state.HasFlag(ResourceState.CopySource))
            result |= ResourceStates.CopySource;
        if (state.HasFlag(ResourceState.CopyDestination))
            result |= ResourceStates.CopyDest;
        if (state.HasFlag(ResourceState.Present))
            result |= ResourceStates.Present;
        if (state.HasFlag(ResourceState.AccelerationStructureRead) || state.HasFlag(ResourceState.AccelerationStructureWrite))
            result |= ResourceStates.RaytracingAccelerationStructure;

        return result == 0 ? ResourceStates.Common : result;
    }

    public static Dx12SamplerDesc ToSamplerDesc(in ApiSamplerDesc desc)
    {
        var comparison = desc.CompareOp != CompareOp.Always;
        if ((desc.AddressU == ApiAddressMode.ClampToBorder
                || desc.AddressV == ApiAddressMode.ClampToBorder
                || desc.AddressW == ApiAddressMode.ClampToBorder)
            && desc.BorderColor != BorderColor.TransparentBlack)
        {
            throw new NotSupportedException("Silk DX12 sampler border color writes are disabled until the generated fixed-buffer binding is wrapped safely; only TransparentBlack border color is supported for border addressing.");
        }

        return new Dx12SamplerDesc
        {
            Filter = ToFilter(desc.MinFilter, desc.MagFilter, desc.MipFilter, comparison, desc.MaxAnisotropy),
            AddressU = ToAddressMode(desc.AddressU),
            AddressV = ToAddressMode(desc.AddressV),
            AddressW = ToAddressMode(desc.AddressW),
            MipLODBias = desc.MipLodBias,
            MaxAnisotropy = Math.Max(1u, desc.MaxAnisotropy),
            ComparisonFunc = comparison ? ToComparisonFunc(desc.CompareOp) : ComparisonFunc.Never,
            MinLOD = desc.MinLod,
            MaxLOD = desc.MaxLod,
        };
    }

    public static ComparisonFunc ToComparisonFunc(CompareOp op) =>
        op switch
        {
            CompareOp.Never => ComparisonFunc.Never,
            CompareOp.Less => ComparisonFunc.Less,
            CompareOp.Equal => ComparisonFunc.Equal,
            CompareOp.LessOrEqual => ComparisonFunc.LessEqual,
            CompareOp.Greater => ComparisonFunc.Greater,
            CompareOp.NotEqual => ComparisonFunc.NotEqual,
            CompareOp.GreaterOrEqual => ComparisonFunc.GreaterEqual,
            CompareOp.Always => ComparisonFunc.Always,
            _ => throw new ArgumentOutOfRangeException(nameof(op), op, "Unsupported compare op."),
        };

    public static Dx12AddressMode ToAddressMode(ApiAddressMode mode) =>
        mode switch
        {
            ApiAddressMode.Repeat => Dx12AddressMode.Wrap,
            ApiAddressMode.MirroredRepeat => Dx12AddressMode.Mirror,
            ApiAddressMode.ClampToEdge => Dx12AddressMode.Clamp,
            ApiAddressMode.ClampToBorder => Dx12AddressMode.Border,
            _ => throw new ArgumentOutOfRangeException(nameof(mode), mode, "Unsupported texture address mode."),
        };

    public static Dx12Filter ToFilter(
        FilterMode min,
        FilterMode mag,
        FilterMode mip,
        bool comparison,
        ushort maxAnisotropy)
    {
        if (maxAnisotropy > 1)
            return comparison ? Dx12Filter.ComparisonAnisotropic : Dx12Filter.Anisotropic;

        return (min, mag, mip, comparison) switch
        {
            (FilterMode.Nearest, FilterMode.Nearest, FilterMode.Nearest, false) => Dx12Filter.MinMagMipPoint,
            (FilterMode.Nearest, FilterMode.Nearest, FilterMode.Linear, false) => Dx12Filter.MinMagPointMipLinear,
            (FilterMode.Nearest, FilterMode.Linear, FilterMode.Nearest, false) => Dx12Filter.MinPointMagLinearMipPoint,
            (FilterMode.Nearest, FilterMode.Linear, FilterMode.Linear, false) => Dx12Filter.MinPointMagMipLinear,
            (FilterMode.Linear, FilterMode.Nearest, FilterMode.Nearest, false) => Dx12Filter.MinLinearMagMipPoint,
            (FilterMode.Linear, FilterMode.Nearest, FilterMode.Linear, false) => Dx12Filter.MinLinearMagPointMipLinear,
            (FilterMode.Linear, FilterMode.Linear, FilterMode.Nearest, false) => Dx12Filter.MinMagLinearMipPoint,
            (FilterMode.Linear, FilterMode.Linear, FilterMode.Linear, false) => Dx12Filter.MinMagMipLinear,
            (FilterMode.Nearest, FilterMode.Nearest, FilterMode.Nearest, true) => Dx12Filter.ComparisonMinMagMipPoint,
            (FilterMode.Nearest, FilterMode.Nearest, FilterMode.Linear, true) => Dx12Filter.ComparisonMinMagPointMipLinear,
            (FilterMode.Nearest, FilterMode.Linear, FilterMode.Nearest, true) => Dx12Filter.ComparisonMinPointMagLinearMipPoint,
            (FilterMode.Nearest, FilterMode.Linear, FilterMode.Linear, true) => Dx12Filter.ComparisonMinPointMagMipLinear,
            (FilterMode.Linear, FilterMode.Nearest, FilterMode.Nearest, true) => Dx12Filter.ComparisonMinLinearMagMipPoint,
            (FilterMode.Linear, FilterMode.Nearest, FilterMode.Linear, true) => Dx12Filter.ComparisonMinLinearMagPointMipLinear,
            (FilterMode.Linear, FilterMode.Linear, FilterMode.Nearest, true) => Dx12Filter.ComparisonMinMagLinearMipPoint,
            (FilterMode.Linear, FilterMode.Linear, FilterMode.Linear, true) => Dx12Filter.ComparisonMinMagMipLinear,
            _ => throw new ArgumentOutOfRangeException(nameof(min), "Unsupported sampler filter combination."),
        };
    }

    public static ulong AlignUp(ulong value, ulong alignment)
    {
        if (alignment == 0)
            throw new ArgumentOutOfRangeException(nameof(alignment), "Alignment must be greater than zero.");
        if ((alignment & (alignment - 1)) != 0)
            throw new ArgumentException("Alignment must be a power of two.", nameof(alignment));

        checked
        {
            return (value + alignment - 1) & ~(alignment - 1);
        }
    }

}
