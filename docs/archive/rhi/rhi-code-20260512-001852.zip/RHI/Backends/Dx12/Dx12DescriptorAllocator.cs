using System;
using SomeEngine.RHI;
using Silk.NET.Core.Native;
using Silk.NET.Direct3D12;

namespace SomeEngine.RHI.Backends.Dx12;

internal readonly struct Dx12DescriptorSlot : IDisposable
{
    private readonly Dx12CpuDescriptorAllocator? _allocator;

    public Dx12DescriptorSlot(
        Dx12CpuDescriptorAllocator allocator,
        DescriptorHeapType type,
        uint index,
        CpuDescriptorHandle cpuHandle)
    {
        _allocator = allocator;
        Type = type;
        Index = index;
        CpuHandle = cpuHandle;
    }

    public DescriptorHeapType Type { get; }
    public uint Index { get; }
    public CpuDescriptorHandle CpuHandle { get; }
    public bool IsValid => _allocator is not null;

    public void Dispose() => _allocator?.Free(Index);
}

internal sealed class Dx12CpuDescriptorAllocator : IDisposable
{
    private readonly DescriptorHeapType _type;
    private readonly uint _capacity;
    private readonly uint _stride;
    private readonly Stack<uint> _freeList = new();
    private ComPtr<ID3D12DescriptorHeap> _heap;
    private uint _next;
    private bool _disposed;

    public Dx12CpuDescriptorAllocator(
        ComPtr<ID3D12Device> device,
        DescriptorHeapType type,
        uint capacity,
        string debugName)
    {
        if (capacity == 0)
            throw new ArgumentOutOfRangeException(nameof(capacity), "Descriptor heap capacity must be greater than zero.");

        _type = type;
        _capacity = capacity;
        _stride = device.GetDescriptorHandleIncrementSize(type);
        if (_stride == 0)
            throw new InvalidOperationException($"ID3D12Device.GetDescriptorHandleIncrementSize({type}) returned zero.");

        var desc = new DescriptorHeapDesc
        {
            Type = type,
            NumDescriptors = capacity,
            Flags = DescriptorHeapFlags.None,
            NodeMask = 0,
        };

        Dx12Exceptions.ThrowIfFailed(
            device.CreateDescriptorHeap(in desc, out _heap),
            $"ID3D12Device.CreateDescriptorHeap({type})");

        Dx12Exceptions.ThrowIfFailed(
            _heap.SetName(debugName),
            $"ID3D12DescriptorHeap.SetName({debugName})");
    }

    public Dx12DescriptorSlot Allocate()
    {
        ThrowIfDisposed();

        uint index;
        if (_freeList.Count > 0)
        {
            index = _freeList.Pop();
        }
        else
        {
            if (_next >= _capacity)
                throw new InvalidOperationException($"DX12 {_type} CPU descriptor heap is exhausted ({_capacity} descriptors).");

            index = _next++;
        }

        var start = _heap.GetCPUDescriptorHandleForHeapStart();
        var address = checked(start.Ptr.ToUInt64() + (ulong)index * _stride);
        var handle = new CpuDescriptorHandle { Ptr = new UIntPtr(address) };
        return new Dx12DescriptorSlot(this, _type, index, handle);
    }

    public void Free(uint index)
    {
        if (_disposed)
            return;
        if (index >= _capacity)
            throw new ArgumentOutOfRangeException(nameof(index), index, $"Descriptor index is outside the {_type} heap.");

        _freeList.Push(index);
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        _heap.Dispose();
        _heap = default;
        _freeList.Clear();
        _disposed = true;
    }

    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(Dx12CpuDescriptorAllocator));
    }
}
