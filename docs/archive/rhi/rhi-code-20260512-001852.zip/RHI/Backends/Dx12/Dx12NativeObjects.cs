using System;
using SomeEngine.RHI;
using Silk.NET.Core.Native;
using Silk.NET.Direct3D12;
using Dx12Range = Silk.NET.Direct3D12.Range;
using ApiSamplerDesc = SomeEngine.RHI.SamplerDesc;

namespace SomeEngine.RHI.Backends.Dx12;

internal sealed class Dx12QueueState : IDisposable
{
    public Dx12QueueState(
        QueueKind kind,
        QueueHandle handle,
        ComPtr<ID3D12CommandQueue> nativeQueue,
        string? debugName,
        object owner)
    {
        Kind = kind;
        Handle = handle;
        NativeQueue = nativeQueue;
        PublicQueue = new Queue(handle, debugName, owner);
    }

    public QueueKind Kind { get; }
    public QueueHandle Handle { get; }
    public ComPtr<ID3D12CommandQueue> NativeQueue { get; private set; }
    public Queue PublicQueue { get; }

    public void Dispose()
    {
        NativeQueue.Dispose();
        NativeQueue = default;
    }
}

internal sealed class Dx12FenceState : IDisposable
{
    public Dx12FenceState(ComPtr<ID3D12Fence> nativeFence, string? debugName)
    {
        NativeFence = nativeFence;
        DebugName = debugName;
    }

    public ComPtr<ID3D12Fence> NativeFence { get; private set; }
    public string? DebugName { get; }

    public void Dispose()
    {
        NativeFence.Dispose();
        NativeFence = default;
    }
}

internal sealed class Dx12ResourceHeapState : IDisposable
{
    public Dx12ResourceHeapState(ComPtr<ID3D12Heap> nativeHeap, ResourceHeapDesc desc)
    {
        NativeHeap = nativeHeap;
        Desc = desc;
    }

    public ComPtr<ID3D12Heap> NativeHeap { get; private set; }
    public ResourceHeapDesc Desc { get; }

    public void Dispose()
    {
        NativeHeap.Dispose();
        NativeHeap = default;
    }
}

internal sealed class Dx12BufferState : IDisposable
{
    public Dx12BufferState(ComPtr<ID3D12Resource> nativeResource, BufferDesc desc, ResourceStates initialState)
    {
        NativeResource = nativeResource;
        Desc = desc;
        CurrentState = initialState;
    }

    public BufferHandle Handle { get; set; }
    public ComPtr<ID3D12Resource> NativeResource { get; private set; }
    public BufferDesc Desc { get; }
    public ResourceStates CurrentState { get; set; }
    public IntPtr MappedPointer { get; set; }
    public MapMode? MappedMode { get; set; }
    public uint ViewCount { get; private set; }
    public BufferViewHandle DefaultConstantBufferView { get; private set; }
    public BufferViewHandle DefaultShaderResourceView { get; private set; }
    public BufferViewHandle DefaultUnorderedAccessView { get; private set; }

    public BufferViewHandle GetDefaultView(BufferViewKind kind) =>
        kind switch
        {
            BufferViewKind.ConstantBuffer => DefaultConstantBufferView,
            BufferViewKind.ShaderResource => DefaultShaderResourceView,
            BufferViewKind.UnorderedAccess => DefaultUnorderedAccessView,
            _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported buffer view kind."),
        };

    public void SetDefaultView(BufferViewKind kind, BufferViewHandle view)
    {
        switch (kind)
        {
            case BufferViewKind.ConstantBuffer:
                DefaultConstantBufferView = view;
                break;
            case BufferViewKind.ShaderResource:
                DefaultShaderResourceView = view;
                break;
            case BufferViewKind.UnorderedAccess:
                DefaultUnorderedAccessView = view;
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported buffer view kind.");
        }
    }

    public void ClearDefaultView(BufferViewHandle view)
    {
        if (DefaultConstantBufferView == view)
            DefaultConstantBufferView = default;
        if (DefaultShaderResourceView == view)
            DefaultShaderResourceView = default;
        if (DefaultUnorderedAccessView == view)
            DefaultUnorderedAccessView = default;
    }

    public void AddView() => ViewCount++;

    public void RemoveView()
    {
        if (ViewCount == 0)
            throw new InvalidOperationException("DX12 buffer view reference count underflow.");

        ViewCount--;
    }

    public unsafe void Dispose()
    {
        if (MappedPointer != IntPtr.Zero)
        {
            NativeResource.Unmap(0, (Dx12Range*)null);
            MappedPointer = IntPtr.Zero;
            MappedMode = null;
        }

        NativeResource.Dispose();
        NativeResource = default;
    }
}

internal sealed class Dx12TextureState : IDisposable
{
    public Dx12TextureState(ComPtr<ID3D12Resource> nativeResource, TextureDesc desc, ResourceStates initialState)
    {
        NativeResource = nativeResource;
        Desc = desc;
        CurrentState = initialState;
    }

    public TextureHandle Handle { get; set; }
    public ComPtr<ID3D12Resource> NativeResource { get; private set; }
    public TextureDesc Desc { get; }
    public ResourceStates CurrentState { get; set; }
    public uint ViewCount { get; private set; }
    public TextureViewHandle DefaultShaderResourceView { get; private set; }
    public TextureViewHandle DefaultUnorderedAccessView { get; private set; }
    public TextureViewHandle DefaultRenderTargetView { get; private set; }
    public TextureViewHandle DefaultDepthStencilView { get; private set; }

    public TextureViewHandle GetDefaultView(TextureViewKind kind) =>
        kind switch
        {
            TextureViewKind.ShaderResource => DefaultShaderResourceView,
            TextureViewKind.UnorderedAccess => DefaultUnorderedAccessView,
            TextureViewKind.RenderTarget => DefaultRenderTargetView,
            TextureViewKind.DepthStencil => DefaultDepthStencilView,
            _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported texture view kind."),
        };

    public void SetDefaultView(TextureViewKind kind, TextureViewHandle view)
    {
        switch (kind)
        {
            case TextureViewKind.ShaderResource:
                DefaultShaderResourceView = view;
                break;
            case TextureViewKind.UnorderedAccess:
                DefaultUnorderedAccessView = view;
                break;
            case TextureViewKind.RenderTarget:
                DefaultRenderTargetView = view;
                break;
            case TextureViewKind.DepthStencil:
                DefaultDepthStencilView = view;
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unsupported texture view kind.");
        }
    }

    public void ClearDefaultView(TextureViewHandle view)
    {
        if (DefaultShaderResourceView == view)
            DefaultShaderResourceView = default;
        if (DefaultUnorderedAccessView == view)
            DefaultUnorderedAccessView = default;
        if (DefaultRenderTargetView == view)
            DefaultRenderTargetView = default;
        if (DefaultDepthStencilView == view)
            DefaultDepthStencilView = default;
    }

    public void AddView() => ViewCount++;

    public void RemoveView()
    {
        if (ViewCount == 0)
            throw new InvalidOperationException("DX12 texture view reference count underflow.");

        ViewCount--;
    }

    public void Dispose()
    {
        NativeResource.Dispose();
        NativeResource = default;
    }
}

internal sealed class Dx12BufferViewState : IDisposable
{
    public Dx12BufferViewState(BufferHandle buffer, BufferViewDesc desc, Dx12DescriptorSlot descriptor)
    {
        Buffer = buffer;
        Desc = desc;
        Descriptor = descriptor;
    }

    public BufferHandle Buffer { get; }
    public BufferViewDesc Desc { get; }
    public Dx12DescriptorSlot Descriptor { get; private set; }

    public void Dispose()
    {
        Descriptor.Dispose();
        Descriptor = default;
    }
}

internal sealed class Dx12TextureViewState : IDisposable
{
    public Dx12TextureViewState(TextureHandle texture, TextureViewDesc desc, Dx12DescriptorSlot descriptor)
    {
        Texture = texture;
        Desc = desc;
        Descriptor = descriptor;
    }

    public TextureHandle Texture { get; }
    public TextureViewDesc Desc { get; }
    public Dx12DescriptorSlot Descriptor { get; private set; }

    public void Dispose()
    {
        Descriptor.Dispose();
        Descriptor = default;
    }
}

internal sealed class Dx12SamplerState : IDisposable
{
    public Dx12SamplerState(ApiSamplerDesc desc, Dx12DescriptorSlot descriptor)
    {
        Desc = desc;
        Descriptor = descriptor;
    }

    public ApiSamplerDesc Desc { get; }
    public Dx12DescriptorSlot Descriptor { get; private set; }

    public void Dispose()
    {
        Descriptor.Dispose();
        Descriptor = default;
    }
}

internal sealed class Dx12DescriptorSetLayoutState
{
    public Dx12DescriptorSetLayoutState(DescriptorSetLayoutDesc desc, DescriptorBindingDesc[] bindings)
    {
        Desc = desc;
        Bindings = bindings;
        BindingIndex = new Dictionary<uint, int>(bindings.Length);
        for (int i = 0; i < bindings.Length; i++)
            BindingIndex.Add(bindings[i].Binding, i);
    }

    public DescriptorSetLayoutDesc Desc { get; }
    public DescriptorBindingDesc[] Bindings { get; }
    public Dictionary<uint, int> BindingIndex { get; }
}

internal sealed class Dx12DescriptorSetState
{
    public Dx12DescriptorSetState(DescriptorSetLayoutHandle layout, string? debugName, DescriptorValue[][] values)
    {
        Layout = layout;
        DebugName = debugName;
        Values = values;
    }

    public DescriptorSetLayoutHandle Layout { get; }
    public string? DebugName { get; }
    public DescriptorValue[][] Values { get; }
}
