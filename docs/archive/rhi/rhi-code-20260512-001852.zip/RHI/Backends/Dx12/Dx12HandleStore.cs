using System;

namespace SomeEngine.RHI.Backends.Dx12;

internal sealed class Dx12HandleStore<THandle, TValue>
    where TValue : class
{
    private readonly Func<uint, uint, THandle> _createHandle;
    private readonly Func<THandle, uint> _getIndex;
    private readonly Func<THandle, uint> _getGeneration;
    private readonly Action<TValue>? _destroyValue;
    private readonly List<Entry> _entries = new() { default };
    private readonly Stack<uint> _freeList = new();

    public Dx12HandleStore(
        Func<uint, uint, THandle> createHandle,
        Func<THandle, uint> getIndex,
        Func<THandle, uint> getGeneration,
        Action<TValue>? destroyValue = null)
    {
        _createHandle = createHandle;
        _getIndex = getIndex;
        _getGeneration = getGeneration;
        _destroyValue = destroyValue;
    }

    public THandle Add(TValue value)
    {
        ArgumentNullException.ThrowIfNull(value);

        uint index;
        uint generation;
        if (_freeList.Count > 0)
        {
            index = _freeList.Pop();
            var entry = _entries[(int)index];
            generation = entry.Generation == uint.MaxValue ? 1 : entry.Generation + 1;
            _entries[(int)index] = new Entry(generation, value);
        }
        else
        {
            index = checked((uint)_entries.Count);
            generation = 1;
            _entries.Add(new Entry(generation, value));
        }

        return _createHandle(index, generation);
    }

    public TValue Get(THandle handle)
    {
        var index = _getIndex(handle);
        if (index == 0 || index >= _entries.Count)
            throw new ArgumentException("Handle index is invalid or no longer owned by this device.", nameof(handle));

        var entry = _entries[(int)index];
        if (entry.Value is null || entry.Generation != _getGeneration(handle))
            throw new ArgumentException("Handle generation is invalid or the object has been destroyed.", nameof(handle));

        return entry.Value;
    }

    public bool TryGet(THandle handle, out TValue? value)
    {
        var index = _getIndex(handle);
        if (index == 0 || index >= _entries.Count)
        {
            value = null;
            return false;
        }

        var entry = _entries[(int)index];
        if (entry.Value is null || entry.Generation != _getGeneration(handle))
        {
            value = null;
            return false;
        }

        value = entry.Value;
        return true;
    }

    public bool TryRemove(THandle handle)
    {
        var index = _getIndex(handle);
        if (index == 0 || index >= _entries.Count)
            return false;

        var entry = _entries[(int)index];
        if (entry.Value is null || entry.Generation != _getGeneration(handle))
            return false;

        _destroyValue?.Invoke(entry.Value);
        _entries[(int)index] = new Entry(entry.Generation, null);
        _freeList.Push(index);
        return true;
    }

    public void DisposeAll()
    {
        for (int i = 1; i < _entries.Count; i++)
        {
            var entry = _entries[i];
            if (entry.Value is not null)
            {
                _destroyValue?.Invoke(entry.Value);
                _entries[i] = new Entry(entry.Generation, null);
            }
        }

        _freeList.Clear();
    }

    private readonly record struct Entry(uint Generation, TValue? Value);
}
