using System;

namespace SomeEngine.RHI;

public sealed class CommandList
{
    internal CommandList(string? debugName)
    {
        DebugName = debugName;
    }

    public string? DebugName { get; }

    public void SetComputePipeline(ComputePipelineHandle pipeline) => ThrowCommandRecordingNotConnected();
    public void SetGraphicsPipeline(GraphicsPipelineHandle pipeline) => ThrowCommandRecordingNotConnected();

    public void SetDescriptorSet(
        uint setIndex,
        DescriptorSetHandle descriptorSet,
        ReadOnlySpan<uint> dynamicOffsets) => ThrowCommandRecordingNotConnected();

    public void SetPushConstants(
        ShaderStageFlags stages,
        ushort offsetInBytes,
        ReadOnlySpan<uint> values) => ThrowCommandRecordingNotConnected();

    public void Dispatch(uint groupCountX, uint groupCountY, uint groupCountZ) =>
        ThrowCommandRecordingNotConnected();

    public void DispatchIndirect(BufferHandle argumentBuffer, ulong byteOffset) =>
        ThrowCommandRecordingNotConnected();

    public void SetVertexBuffer(uint slot, BufferHandle buffer, ulong offset, uint stride) =>
        ThrowCommandRecordingNotConnected();

    public void SetVertexBuffers(uint firstSlot, ReadOnlySpan<VertexBufferBinding> bindings) =>
        ThrowCommandRecordingNotConnected();

    public void SetIndexBuffer(BufferHandle buffer, ulong offset, IndexFormat format) =>
        ThrowCommandRecordingNotConnected();

    public void SetViewport(in Viewport viewport) => ThrowCommandRecordingNotConnected();
    public void SetScissorRect(in ScissorRect rect) => ThrowCommandRecordingNotConnected();
    public void SetViewports(ReadOnlySpan<Viewport> viewports) => ThrowCommandRecordingNotConnected();
    public void SetScissorRects(ReadOnlySpan<ScissorRect> rects) => ThrowCommandRecordingNotConnected();
    public void SetBlendConstants(float r, float g, float b, float a) => ThrowCommandRecordingNotConnected();
    public void SetStencilReference(uint reference) => ThrowCommandRecordingNotConnected();

    public void PushDebugGroup(string name) => ThrowCommandRecordingNotConnected();
    public void PopDebugGroup() => ThrowCommandRecordingNotConnected();
    public void InsertDebugMarker(string name) => ThrowCommandRecordingNotConnected();

    public void Draw(uint vertexCount, uint instanceCount, uint firstVertex, uint firstInstance) =>
        ThrowCommandRecordingNotConnected();

    public void DrawIndexed(
        uint indexCount,
        uint instanceCount,
        uint firstIndex,
        int vertexOffset,
        uint firstInstance) => ThrowCommandRecordingNotConnected();

    public void DrawIndirect(BufferHandle argumentBuffer, ulong byteOffset) =>
        ThrowCommandRecordingNotConnected();

    public void DrawIndexedIndirect(BufferHandle argumentBuffer, ulong byteOffset) =>
        ThrowCommandRecordingNotConnected();

    public void UpdateBuffer(BufferHandle buffer, ulong offset, ReadOnlySpan<byte> data) =>
        ThrowCommandRecordingNotConnected();

    public void CopyBuffer(in BufferCopyRegion region) => ThrowCommandRecordingNotConnected();
    public void CopyTexture(in TextureCopyRegion region) => ThrowCommandRecordingNotConnected();
    public void CopyBufferToTexture(in BufferTextureCopyRegion region) => ThrowCommandRecordingNotConnected();
    public void CopyTextureToBuffer(in BufferTextureCopyRegion region) => ThrowCommandRecordingNotConnected();

    public void ClearRenderTarget(TextureViewHandle view, float r, float g, float b, float a) =>
        ThrowCommandRecordingNotConnected();

    public void ClearDepthStencil(TextureViewHandle view, bool clearDepth, float depth, bool clearStencil, byte stencil) =>
        ThrowCommandRecordingNotConnected();

    public void BeginRenderPass(in RenderPassDesc desc) => ThrowCommandRecordingNotConnected();
    public void EndRenderPass() => ThrowCommandRecordingNotConnected();
    public void ResourceBarrier(ReadOnlySpan<ResourceBarrier> barriers) => ThrowCommandRecordingNotConnected();

    public void BeginQuery(QueryPoolHandle queryPool, uint queryIndex) => ThrowCommandRecordingNotConnected();
    public void EndQuery(QueryPoolHandle queryPool, uint queryIndex) => ThrowCommandRecordingNotConnected();

    public void ResolveQueryData(
        QueryPoolHandle queryPool,
        uint firstQuery,
        uint queryCount,
        BufferHandle destination,
        ulong destinationOffset) => ThrowCommandRecordingNotConnected();

    private static void ThrowCommandRecordingNotConnected() =>
        throw new NotSupportedException(
            "Command recording is not supported by this device configuration.");
}
