using System;

namespace SomeEngine.RHI;

public readonly record struct VertexAttributeDesc(
    uint Location,
    uint Slot,
    Format Format,
    uint Offset,
    uint Stride,
    bool PerInstance,
    uint InstanceStepRate);

public readonly record struct InputLayoutDesc(
    ReadOnlyMemory<VertexAttributeDesc> Attributes);

public readonly record struct RasterizerDesc(
    FillMode FillMode,
    CullMode CullMode,
    FrontFace FrontFace,
    int DepthBias,
    float DepthBiasClamp,
    float SlopeScaledDepthBias,
    bool DepthClipEnable,
    bool ScissorEnable);

public readonly record struct StencilFaceDesc(
    StencilOp FailOp,
    StencilOp DepthFailOp,
    StencilOp PassOp,
    CompareOp CompareOp);

public readonly record struct DepthStencilDesc(
    bool DepthEnable,
    bool DepthWriteEnable,
    CompareOp DepthCompare,
    bool StencilEnable,
    byte StencilReadMask,
    byte StencilWriteMask,
    StencilFaceDesc FrontFace,
    StencilFaceDesc BackFace);

public readonly record struct ColorTargetBlendDesc(
    bool BlendEnable,
    BlendFactor SourceColor,
    BlendFactor DestinationColor,
    BlendOp ColorOp,
    BlendFactor SourceAlpha,
    BlendFactor DestinationAlpha,
    BlendOp AlphaOp,
    ColorWriteMask WriteMask);

public readonly record struct BlendDesc(
    bool AlphaToCoverageEnable,
    bool IndependentBlendEnable,
    ReadOnlyMemory<ColorTargetBlendDesc> ColorTargets);
