using System;
using System.Runtime.InteropServices;
using SomeEngine.RHI;
using SomeEngine.RHI.Backends.Dx12;

namespace SomeEngine.Tests.RHI;

[Trait("Category", "RHI.Dx12Hardware")]
public sealed class SilkDx12DeviceTests
{
    [Fact]
    public void HeadlessDeviceExposesQueuesFencesAndRejectsForeignQueues()
    {
        if (!OperatingSystem.IsWindows())
            return;

        using var device = SilkDx12Device.Create();

        Assert.Equal(BackendKind.Dx12, device.BackendInfo.Kind);
        Assert.Equal(256u, device.Limits.ConstantBufferOffsetAlignment);
        Assert.True(device.Limits.SupportsPlacedResources);
        Assert.True(device.Limits.SupportsDescriptorIndexing);

        var graphics = device.GetQueue(QueueKind.Graphics);
        var compute = device.GetQueue(QueueKind.Compute);
        var copy = device.GetQueue(QueueKind.Copy);
        Assert.True(graphics.Handle.IsValid);
        Assert.True(compute.Handle.IsValid);
        Assert.True(copy.Handle.IsValid);
        Assert.NotEqual(graphics.Handle, compute.Handle);
        Assert.NotEqual(graphics.Handle, copy.Handle);

        var fence = device.CreateFence(new FenceDesc("FenceSmoke", 7));
        try
        {
            Assert.Equal(7ul, device.GetFenceCompletedValue(fence));
            device.WaitForFence(fence, 7, TimeSpan.Zero);

            device.SignalFence(graphics, fence, 8);
            device.WaitForFence(fence, 8, TimeSpan.FromSeconds(5));
            Assert.True(device.GetFenceCompletedValue(fence) >= 8);

            Assert.True(device.GetTimestampFrequency(compute) > 0);
        }
        finally
        {
            device.DestroyFence(fence);
        }

        using var otherDevice = SilkDx12Device.Create();
        Assert.Throws<ArgumentException>(() => device.GetTimestampFrequency(otherDevice.GetQueue(QueueKind.Graphics)));
    }

    [Fact]
    public void CommittedUploadBufferCanMapAndCreateConstantBufferView()
    {
        if (!OperatingSystem.IsWindows())
            return;

        using var device = SilkDx12Device.Create();
        var buffer = device.CreateBuffer(new BufferDesc(
            "UploadConstantBuffer",
            SizeInBytes: 1024,
            Usage: BufferUsageFlags.Constant | BufferUsageFlags.CopySource,
            Placement: ResourcePlacement.Committed(MemoryUsage.CpuToGpu)));

        var view = default(BufferViewHandle);
        try
        {
            Assert.Equal(1024ul, device.GetBufferDesc(buffer).SizeInBytes);

            view = device.GetDefaultBufferView(buffer, BufferViewKind.ConstantBuffer);
            Assert.True(view.IsValid);
            Assert.Equal(BufferViewKind.ConstantBuffer, device.GetBufferViewDesc(view).Kind);

            var mapped = device.MapBuffer(buffer, MapMode.Write, MapFlags.None);
            Assert.NotEqual(IntPtr.Zero, mapped.CpuPointer);
            Assert.Equal(1024ul, mapped.SizeInBytes);
            Marshal.WriteInt32(mapped.CpuPointer, unchecked((int)0x12345678));
            device.UnmapBuffer(buffer);
        }
        finally
        {
            if (view.IsValid)
                device.DestroyBufferView(view);
            device.DestroyBuffer(buffer);
        }
    }

    [Fact]
    public void PlacedGpuBufferCanCreateRawShaderView()
    {
        if (!OperatingSystem.IsWindows())
            return;

        using var device = SilkDx12Device.Create();
        var committedDesc = new BufferDesc(
            "PlacedRawBuffer",
            SizeInBytes: 4096,
            Usage: BufferUsageFlags.ByteAddress | BufferUsageFlags.CopySource | BufferUsageFlags.CopyDestination,
            Placement: ResourcePlacement.Committed(MemoryUsage.GpuOnly));
        var requirements = device.GetBufferMemoryRequirements(committedDesc);

        var heap = device.CreateResourceHeap(new ResourceHeapDesc(
            "PlacedRawBufferHeap",
            MemoryUsage.GpuOnly,
            requirements.SizeInBytes,
            requirements.Alignment));

        var buffer = default(BufferHandle);
        var view = default(BufferViewHandle);
        try
        {
            var placedDesc = committedDesc with
            {
                Placement = ResourcePlacement.Placed(MemoryUsage.GpuOnly, heap, 0),
            };
            buffer = device.CreateBuffer(placedDesc);
            view = device.GetDefaultBufferView(buffer, BufferViewKind.ShaderResource);

            Assert.True(buffer.IsValid);
            Assert.True(view.IsValid);
            Assert.Equal(BufferViewKind.ShaderResource, device.GetBufferViewDesc(view).Kind);
        }
        finally
        {
            if (view.IsValid)
                device.DestroyBufferView(view);
            if (buffer.IsValid)
                device.DestroyBuffer(buffer);
            device.DestroyResourceHeap(heap);
        }
    }

    [Fact]
    public void TextureCanCreateSrvRtvAndCopyLayout()
    {
        if (!OperatingSystem.IsWindows())
            return;

        using var device = SilkDx12Device.Create();
        var texture = device.CreateTexture(new TextureDesc(
            "ColorTexture",
            TextureDimension.Texture2D,
            Format.R8G8B8A8UNorm,
            Width: 64,
            Height: 64,
            DepthOrArrayLayers: 1,
            MipLevels: 1,
            SampleCount: 1,
            Usage: TextureUsageFlags.ShaderResource | TextureUsageFlags.RenderTarget | TextureUsageFlags.CopyDestination,
            ClearValue: ClearValue.Color(Format.R8G8B8A8UNorm, 0, 0, 0, 1),
            Placement: ResourcePlacement.Committed(MemoryUsage.GpuOnly)));

        var srv = default(TextureViewHandle);
        var rtv = default(TextureViewHandle);
        try
        {
            srv = device.GetDefaultTextureView(texture, TextureViewKind.ShaderResource);
            rtv = device.GetDefaultTextureView(texture, TextureViewKind.RenderTarget);
            var layout = device.GetTextureCopyLayout(texture, 0);

            Assert.True(srv.IsValid);
            Assert.True(rtv.IsValid);
            Assert.Equal(TextureViewKind.ShaderResource, device.GetTextureViewDesc(srv).Kind);
            Assert.Equal(TextureViewKind.RenderTarget, device.GetTextureViewDesc(rtv).Kind);
            Assert.True(layout.RowPitch >= 64u * 4u);
            Assert.Equal(64u, layout.RowCount);
        }
        finally
        {
            if (srv.IsValid)
                device.DestroyTextureView(srv);
            if (rtv.IsValid)
                device.DestroyTextureView(rtv);
            device.DestroyTexture(texture);
        }
    }

    [Fact]
    public void DescriptorSetStoresValidatedBufferAndSamplerBindings()
    {
        if (!OperatingSystem.IsWindows())
            return;

        using var device = SilkDx12Device.Create();
        var buffer = device.CreateBuffer(new BufferDesc(
            "DescriptorConstantBuffer",
            SizeInBytes: 256,
            Usage: BufferUsageFlags.Constant | BufferUsageFlags.CopySource,
            Placement: ResourcePlacement.Committed(MemoryUsage.CpuToGpu)));
        var bufferView = device.GetDefaultBufferView(buffer, BufferViewKind.ConstantBuffer);
        var sampler = device.CreateSampler(new SamplerDesc(
            "LinearClamp",
            FilterMode.Linear,
            FilterMode.Linear,
            FilterMode.Linear,
            TextureAddressMode.ClampToEdge,
            TextureAddressMode.ClampToEdge,
            TextureAddressMode.ClampToEdge,
            MipLodBias: 0,
            MaxAnisotropy: 1,
            CompareOp.Always,
            BorderColor.TransparentBlack,
            MinLod: 0,
            MaxLod: float.MaxValue));

        var layout = default(DescriptorSetLayoutHandle);
        var set = default(DescriptorSetHandle);
        try
        {
            var bindings = new[]
            {
                new DescriptorBindingDesc(0, DescriptorType.ConstantBuffer, ShaderStageFlags.Vertex, Count: 1, HasDynamicOffset: false, DebugName: null),
                new DescriptorBindingDesc(1, DescriptorType.Sampler, ShaderStageFlags.Pixel, Count: 1, HasDynamicOffset: false, DebugName: null),
            };
            layout = device.CreateDescriptorSetLayout(new DescriptorSetLayoutDesc("DescriptorLayout", Set: 0, Bindings: bindings));
            set = device.CreateDescriptorSet(layout, "DescriptorSet");

            var writes = new[]
            {
                new DescriptorWrite(0, 0, DescriptorValue.ConstantBuffer(bufferView)),
                new DescriptorWrite(1, 0, DescriptorValue.FromSampler(sampler)),
            };
            device.UpdateDescriptorSet(set, writes);
        }
        finally
        {
            if (set.IsValid)
                device.DestroyDescriptorSet(set);
            if (layout.IsValid)
                device.DestroyDescriptorSetLayout(layout);
            device.DestroySampler(sampler);
            device.DestroyBufferView(bufferView);
            device.DestroyBuffer(buffer);
        }
    }

    [Fact]
    public void UploadAndReadbackSlicesExposeCpuMemory()
    {
        if (!OperatingSystem.IsWindows())
            return;

        using var device = SilkDx12Device.Create();
        var upload = device.AllocateUpload(64, 16);
        var readback = device.AllocateReadback(64, 16);
        var readbackMapped = false;

        try
        {
            Assert.True(upload.Buffer.IsValid);
            Assert.NotEqual(IntPtr.Zero, upload.CpuPointer);
            Marshal.WriteInt32(upload.CpuPointer, 42);

            var span = device.MapReadback(readback);
            readbackMapped = true;
            Assert.Equal(64, span.Length);
        }
        finally
        {
            device.UnmapBuffer(upload.Buffer);
            device.DestroyBuffer(upload.Buffer);
            if (readbackMapped)
                device.UnmapBuffer(readback.Buffer);
            device.DestroyBuffer(readback.Buffer);
        }
    }
}
