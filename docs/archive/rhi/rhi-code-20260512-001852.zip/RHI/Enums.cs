namespace SomeEngine.RHI;

[Flags]
public enum ShaderStageFlags : ushort
{
    None = 0,
    Vertex = 1 << 0,
    Pixel = 1 << 1,
    Compute = 1 << 2,
    Hull = 1 << 3,
    Domain = 1 << 4,
    Geometry = 1 << 5,
    Amplification = 1 << 6,
    Mesh = 1 << 7,
    RayTracing = 1 << 8,
    AllGraphics = Vertex | Pixel | Hull | Domain | Geometry | Amplification | Mesh,
    All = AllGraphics | Compute | RayTracing,
}

public enum DescriptorType : byte
{
    ConstantBuffer,
    StructuredBuffer,
    ByteAddressBuffer,
    Texture,
    Sampler,
    ReadWriteStructuredBuffer,
    ReadWriteByteAddressBuffer,
    ReadWriteTexture,
    AccelerationStructure,
}

public enum BufferViewKind : byte
{
    ConstantBuffer,
    ShaderResource,
    UnorderedAccess,
}

public enum TextureViewKind : byte
{
    ShaderResource,
    UnorderedAccess,
    RenderTarget,
    DepthStencil,
}

public enum MemoryUsage : byte
{
    GpuOnly,
    CpuToGpu,
    GpuToCpu,
}

public enum ResourcePlacementKind : byte
{
    Committed,
    Placed,
}

[Flags]
public enum BufferUsageFlags : uint
{
    None = 0,
    Vertex = 1u << 0,
    Index = 1u << 1,
    Constant = 1u << 2,
    Structured = 1u << 3,
    ByteAddress = 1u << 4,
    ReadWrite = 1u << 5,
    IndirectArgument = 1u << 6,
    CopySource = 1u << 7,
    CopyDestination = 1u << 8,
    AccelerationStructure = 1u << 9,
}

[Flags]
public enum TextureUsageFlags : uint
{
    None = 0,
    ShaderResource = 1u << 0,
    ReadWrite = 1u << 1,
    RenderTarget = 1u << 2,
    DepthStencil = 1u << 3,
    CopySource = 1u << 4,
    CopyDestination = 1u << 5,
    Present = 1u << 6,
}

[Flags]
public enum ResourceState : uint
{
    Unknown = 0,
    Undefined = 1u << 0,
    ConstantBuffer = 1u << 1,
    VertexBuffer = 1u << 2,
    IndexBuffer = 1u << 3,
    RenderTarget = 1u << 4,
    DepthWrite = 1u << 5,
    DepthRead = 1u << 6,
    ShaderResource = 1u << 7,
    UnorderedAccess = 1u << 8,
    IndirectArgument = 1u << 9,
    CopySource = 1u << 10,
    CopyDestination = 1u << 11,
    Present = 1u << 12,
    AccelerationStructureRead = 1u << 13,
    AccelerationStructureWrite = 1u << 14,
}

public enum ResourceBarrierKind : byte
{
    Transition,
    UnorderedAccess,
    Aliasing,
}

[Flags]
public enum BarrierFlags : byte
{
    None = 0,
    UpdateState = 1 << 0,
}

public enum TextureDimension : byte
{
    Texture1D,
    Texture2D,
    Texture3D,
    Cube,
}

public enum Format : ushort
{
    Unknown,
    R8G8B8A8UNorm,
    R8G8B8A8UNormSrgb,
    B8G8R8A8UNorm,
    R16G16Float,
    R16G16B16A16Float,
    R32UInt,
    R32Float,
    R32G32Float,
    R32G32B32Float,
    R32G32B32A32Float,
    D16UNorm,
    D24UNormS8UInt,
    D32Float,
    D32FloatS8UInt,
}

public enum IndexFormat : byte
{
    UInt16,
    UInt32,
}

public enum ShaderStage : byte
{
    Vertex,
    Pixel,
    Compute,
    Hull,
    Domain,
    Geometry,
    Amplification,
    Mesh,
    RayGeneration,
    RayMiss,
    RayClosestHit,
    RayAnyHit,
    RayIntersection,
    Callable,
}

public enum ShaderBytecodeFormat : byte
{
    Dxil,
    SpirV,
    Msl,
}

public enum AttachmentLoadOp : byte
{
    Load,
    Clear,
    DontCare,
}

public enum AttachmentStoreOp : byte
{
    Store,
    DontCare,
}

public enum BackendKind : byte
{
    Dx12,
    Vulkan,
    Metal,
    WebGpu,
}

public enum QueueKind : byte
{
    Graphics,
    Compute,
    Copy,
}

public enum PresentMode : byte
{
    Immediate,
    Mailbox,
    Fifo,
}

public enum MapMode : byte
{
    Read,
    Write,
    ReadWrite,
}

[Flags]
public enum MapFlags : byte
{
    None = 0,
    Discard = 1 << 0,
    NoOverwrite = 1 << 1,
    DoNotWait = 1 << 2,
}

public enum QueryType : byte
{
    Timestamp,
    Duration,
    Occlusion,
    PipelineStatistics,
}

public enum FilterMode : byte
{
    Nearest,
    Linear,
}

public enum TextureAddressMode : byte
{
    Repeat,
    MirroredRepeat,
    ClampToEdge,
    ClampToBorder,
}

public enum BorderColor : byte
{
    TransparentBlack,
    OpaqueBlack,
    OpaqueWhite,
}

public enum FillMode : byte
{
    Solid,
    Wireframe,
}

public enum CullMode : byte
{
    None,
    Front,
    Back,
}

public enum FrontFace : byte
{
    Clockwise,
    CounterClockwise,
}

public enum PrimitiveTopology : byte
{
    PointList,
    LineList,
    LineStrip,
    TriangleList,
    TriangleStrip,
    PatchList,
}

public enum CompareOp : byte
{
    Never,
    Less,
    Equal,
    LessOrEqual,
    Greater,
    NotEqual,
    GreaterOrEqual,
    Always,
}

public enum StencilOp : byte
{
    Keep,
    Zero,
    Replace,
    IncrementAndClamp,
    DecrementAndClamp,
    Invert,
    IncrementAndWrap,
    DecrementAndWrap,
}

public enum BlendFactor : byte
{
    Zero,
    One,
    SourceColor,
    OneMinusSourceColor,
    DestinationColor,
    OneMinusDestinationColor,
    SourceAlpha,
    OneMinusSourceAlpha,
    DestinationAlpha,
    OneMinusDestinationAlpha,
    ConstantColor,
    OneMinusConstantColor,
    ConstantAlpha,
    OneMinusConstantAlpha,
    SourceAlphaSaturate,
}

public enum BlendOp : byte
{
    Add,
    Subtract,
    ReverseSubtract,
    Min,
    Max,
}

[Flags]
public enum ColorWriteMask : byte
{
    None = 0,
    Red = 1 << 0,
    Green = 1 << 1,
    Blue = 1 << 2,
    Alpha = 1 << 3,
    All = Red | Green | Blue | Alpha,
}
