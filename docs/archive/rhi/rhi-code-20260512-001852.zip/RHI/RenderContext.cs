using System;
using System.Runtime.InteropServices;
using Diligent;
using Silk.NET.Windowing;

namespace SomeEngine.Render.RHI;

public unsafe class RenderContext : IDisposable
{
    public IEngineFactory? Factory { get; private set; }
    public IRenderDevice? Device { get; private set; }
    public IDeviceContext? ImmediateContext { get; private set; }
    public ISwapChain? SwapChain { get; private set; }
    public TextureDesc DepthBufferDesc { get; private set; }

    private readonly bool _waitForIdleBeforePresent = ReadBooleanEnvironmentVariable(
        "SOMEENGINE_PRESENT_WAIT_FOR_IDLE"
    );
    private readonly uint _presentSyncInterval = ResolvePresentSyncInterval();

    public void Initialize(IWindow window)
    {
        if (window?.Native?.Win32 == null)
            throw new NotSupportedException("Only Win32 windows are supported for now.");
        var (Hwnd, _, _) = window.Native.Win32.Value;

        var scDesc = new SwapChainDesc
        {
            ColorBufferFormat = TextureFormat.RGBA8_UNorm,
            DepthBufferFormat = TextureFormat.Unknown, // We manage depth buffer via RG
            BufferCount = 2,
            Width = (uint)window.Size.X,
            Height = (uint)window.Size.Y,
            Usage = SwapChainUsageFlags.RenderTarget | SwapChainUsageFlags.CopySource,
        };

        // Try D3D12 first
        try
        {
            InitializeD3D12(Hwnd, scDesc);
        }
        catch
        {
            // Fallback or just fail for now
            throw new Exception("Failed to initialize D3D12 backend.");
        }
    }

    private void InitializeD3D12(nint windowHandle, SwapChainDesc scDesc)
    {
        var factory = Native.CreateEngineFactory<IEngineFactoryD3D12>();
        Factory = factory;
        var engineCI = new EngineD3D12CreateInfo
        {
            EnableValidation = false,
        };
        factory.CreateDeviceAndContextsD3D12(engineCI, out var device, out var contexts);
        Device = device;

        ImmediateContext = contexts[0];
        var fsDesc = new FullScreenModeDesc();
        var win32Window = new Win32NativeWindow { Wnd = windowHandle };

        SwapChain = factory.CreateSwapChainD3D12(device, contexts[0], scDesc, fsDesc, win32Window);
        UpdateDepthBufferDesc(scDesc.Width, scDesc.Height);
    }

    private void UpdateDepthBufferDesc(uint width, uint height)
    {
        if (width == 0 || height == 0)
            return;

        DepthBufferDesc = new TextureDesc
        {
            Name = "DepthBuffer",
            Type = ResourceDimension.Tex2d,
            Width = width,
            Height = height,
            Format = TextureFormat.D32_Float,
            BindFlags = BindFlags.DepthStencil | BindFlags.ShaderResource,
            ClearValue = new OptimizedClearValue
            {
                Format = TextureFormat.D32_Float,
                DepthStencil = new DepthStencilClearValue { Depth = 1.0f, Stencil = 0 },
            },
        };
    }

    public void Resize(uint width, uint height)
    {
        SwapChain?.Resize(width, height, SurfaceTransform.Optimal);
        UpdateDepthBufferDesc(width, height);
    }

    public void Present()
    {
        if (_waitForIdleBeforePresent)
            ImmediateContext?.WaitForIdle();

        SwapChain?.Present(_presentSyncInterval);
    }

    public void Dispose()
    {
        ImmediateContext?.Flush();
        ImmediateContext?.WaitForIdle();
        SwapChain?.Dispose();
        ImmediateContext?.Dispose();
        Device?.Dispose();
        Factory?.Dispose();
    }

    private static uint ResolvePresentSyncInterval()
    {
        string? intervalValue = Environment.GetEnvironmentVariable("SOMEENGINE_PRESENT_INTERVAL");
        if (
            int.TryParse(intervalValue, out int interval)
            && interval >= 0
            && interval <= 4
        )
        {
            return (uint)interval;
        }

        string? vsyncValue = Environment.GetEnvironmentVariable("SOMEENGINE_VSYNC");
        if (
            !string.IsNullOrWhiteSpace(vsyncValue)
            && (
                vsyncValue.Equals("0", StringComparison.OrdinalIgnoreCase)
                || vsyncValue.Equals("false", StringComparison.OrdinalIgnoreCase)
                || vsyncValue.Equals("off", StringComparison.OrdinalIgnoreCase)
                || vsyncValue.Equals("no", StringComparison.OrdinalIgnoreCase)
            )
        )
        {
            return 0;
        }

        return 1;
    }

    private static bool ReadBooleanEnvironmentVariable(string name)
    {
        string? value = Environment.GetEnvironmentVariable(name);
        if (string.IsNullOrWhiteSpace(value))
            return false;

        return value.Equals("1", StringComparison.OrdinalIgnoreCase)
            || value.Equals("true", StringComparison.OrdinalIgnoreCase)
            || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
            || value.Equals("on", StringComparison.OrdinalIgnoreCase);
    }
}
