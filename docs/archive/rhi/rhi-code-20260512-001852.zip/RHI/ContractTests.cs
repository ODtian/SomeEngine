using System;
using System.Linq;
using System.Reflection;
using SomeEngine.RHI;

namespace SomeEngine.Tests.RHI;

public class ContractTests
{
    [Fact]
    public void DefaultHandlesAreInvalid()
    {
        Assert.False(default(BufferHandle).IsValid);
        Assert.False(default(TextureHandle).IsValid);
        Assert.False(default(DescriptorSetHandle).IsValid);
        Assert.False(default(ComputePipelineHandle).IsValid);
    }

    [Fact]
    public void NonZeroHandlesAreValid()
    {
        Assert.True(new BufferHandle(1, 1).IsValid);
        Assert.True(new TextureHandle(42, 7).IsValid);
        Assert.True(new DescriptorSetHandle(uint.MaxValue, 1).IsValid);
    }

    [Fact]
    public void ResourcePlacementFactoriesEncodeCommittedAndPlaced()
    {
        var committed = ResourcePlacement.Committed(MemoryUsage.GpuOnly);
        Assert.Equal(ResourcePlacementKind.Committed, committed.Kind);
        Assert.Equal(default, committed.Heap);
        Assert.Equal(0ul, committed.HeapOffset);

        var heap = new ResourceHeapHandle(3, 5);
        var placed = ResourcePlacement.Placed(MemoryUsage.GpuOnly, heap, 65536);
        Assert.Equal(ResourcePlacementKind.Placed, placed.Kind);
        Assert.Equal(heap, placed.Heap);
        Assert.Equal(65536ul, placed.HeapOffset);
    }

    [Fact]
    public void ResourcePlacementRejectsInvalidPlacedHeap()
    {
        Assert.Throws<ArgumentException>(() =>
            ResourcePlacement.Placed(MemoryUsage.GpuOnly, default, 0));
    }

    [Fact]
    public void DescriptorValueFactoriesPreserveHandleKind()
    {
        var bufferView = new BufferViewHandle(1, 2);
        var cbv = DescriptorValue.ConstantBuffer(bufferView);
        Assert.Equal(DescriptorType.ConstantBuffer, cbv.Type);
        Assert.Equal(bufferView, cbv.BufferView);
        Assert.False(cbv.TextureView.IsValid);
        Assert.False(cbv.Sampler.IsValid);

        var textureView = new TextureViewHandle(3, 4);
        var srv = DescriptorValue.Texture(textureView);
        Assert.Equal(DescriptorType.Texture, srv.Type);
        Assert.Equal(textureView, srv.TextureView);
        Assert.False(srv.BufferView.IsValid);

        var sampler = new SamplerHandle(5, 6);
        var samplerValue = DescriptorValue.FromSampler(sampler);
        Assert.Equal(DescriptorType.Sampler, samplerValue.Type);
        Assert.Equal(sampler, samplerValue.Sampler);
    }

    [Fact]
    public void TextureBarrierCanTargetSubresourceRange()
    {
        var texture = new TextureHandle(7, 1);
        var range = new SubresourceRange(BaseMipLevel: 2, MipLevelCount: 1, BaseArrayLayer: 0, ArrayLayerCount: 1);

        var barrier = ResourceBarrier.TextureTransition(
            texture,
            ResourceState.ShaderResource,
            ResourceState.UnorderedAccess,
            range,
            BarrierFlags.UpdateState);

        Assert.Equal(ResourceBarrierKind.Transition, barrier.Kind);
        Assert.Equal(texture, barrier.Texture);
        Assert.Equal(range, barrier.Subresources);
        Assert.Equal(BarrierFlags.UpdateState, barrier.Flags);
    }

    [Fact]
    public void AliasingBarrierPreservesBeforeAndAfterResources()
    {
        var before = new BufferHandle(1, 1);
        var after = new TextureHandle(2, 1);

        var barrier = ResourceBarrier.BufferToTextureAliasing(before, after);

        Assert.Equal(ResourceBarrierKind.Aliasing, barrier.Kind);
        Assert.Equal(before, barrier.AliasingBeforeBuffer);
        Assert.Equal(after, barrier.AliasingAfterTexture);
        Assert.False(barrier.AliasingBeforeTexture.IsValid);
        Assert.False(barrier.AliasingAfterBuffer.IsValid);
    }

    [Fact]
    public void PublicTypesDoNotUseLegacyPrefix()
    {
        var legacyPrefix = string.Concat('R', "hi");

        var offenders = GetLoadableTypes(typeof(Device).Assembly)
            .Where(static type => type.IsPublic)
            .Where(static type => type.Namespace == "SomeEngine.RHI")
            .Select(static type => type.Name)
            .Where(name => name.StartsWith(legacyPrefix, StringComparison.Ordinal))
            .OrderBy(static name => name, StringComparer.Ordinal)
            .ToArray();

        Assert.Empty(offenders);
    }

    private static Type[] GetLoadableTypes(Assembly assembly)
    {
        try
        {
            return assembly.GetTypes();
        }
        catch (ReflectionTypeLoadException ex)
        {
            return ex.Types.Where(static type => type is not null).Cast<Type>().ToArray();
        }
    }
}
