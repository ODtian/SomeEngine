namespace SomeEngine.RHI;

internal static class HandleValidation
{
    public static bool IsValid(uint index, uint generation) => index != 0 && generation != 0;
}

public readonly record struct AdapterHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static AdapterHandle Invalid => default;
}

public readonly record struct QueueHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static QueueHandle Invalid => default;
}

public readonly record struct SwapChainHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static SwapChainHandle Invalid => default;
}

public readonly record struct FenceHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static FenceHandle Invalid => default;
}

public readonly record struct ResourceHeapHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static ResourceHeapHandle Invalid => default;
}

public readonly record struct BufferHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static BufferHandle Invalid => default;
}

public readonly record struct TextureHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static TextureHandle Invalid => default;
}

public readonly record struct BufferViewHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static BufferViewHandle Invalid => default;
}

public readonly record struct TextureViewHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static TextureViewHandle Invalid => default;
}

public readonly record struct SamplerHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static SamplerHandle Invalid => default;
}

public readonly record struct ShaderModuleHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static ShaderModuleHandle Invalid => default;
}

public readonly record struct PipelineLayoutHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static PipelineLayoutHandle Invalid => default;
}

public readonly record struct ComputePipelineHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static ComputePipelineHandle Invalid => default;
}

public readonly record struct GraphicsPipelineHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static GraphicsPipelineHandle Invalid => default;
}

public readonly record struct DescriptorSetLayoutHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static DescriptorSetLayoutHandle Invalid => default;
}

public readonly record struct DescriptorSetHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static DescriptorSetHandle Invalid => default;
}

public readonly record struct QueryPoolHandle(uint Index, uint Generation)
{
    public bool IsValid => HandleValidation.IsValid(Index, Generation);
    public static QueryPoolHandle Invalid => default;
}
