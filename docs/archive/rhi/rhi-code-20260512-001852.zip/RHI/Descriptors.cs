using System;

namespace SomeEngine.RHI;

public readonly record struct BackendInfo(
    BackendKind Kind,
    string Name,
    string BindingLayer);

public readonly record struct DeviceLimits(
    uint ConstantBufferOffsetAlignment,
    uint StorageBufferOffsetAlignment,
    uint MaxDescriptorSets,
    uint MaxDescriptorsPerSet,
    uint MaxPushConstantBytes,
    bool SupportsPlacedResources,
    bool SupportsDescriptorIndexing,
    bool SupportsRayTracing,
    bool SupportsTimestampQueries,
    bool AllowBufferTextureInSameHeap);

public readonly record struct SwapChainDesc(
    string? DebugName,
    IntPtr NativeWindowHandle,
    uint Width,
    uint Height,
    Format ColorFormat,
    uint BufferCount,
    PresentMode PresentMode,
    bool AllowTearing);

public readonly record struct PresentOptions(
    uint SyncInterval,
    bool AllowTearing,
    bool TestOnly);

public readonly record struct FenceDesc(
    string? DebugName,
    ulong InitialValue);

public readonly record struct QueryPoolDesc(
    string? DebugName,
    QueryType Type,
    uint Count);

public readonly record struct DescriptorBindingKey(
    uint Set,
    uint Binding,
    DescriptorType Type,
    ShaderStageFlags Stages);

public readonly record struct DescriptorBindingDesc(
    uint Binding,
    DescriptorType Type,
    ShaderStageFlags Stages,
    uint Count,
    bool HasDynamicOffset,
    string? DebugName);

public readonly record struct DescriptorSetLayoutDesc(
    string? DebugName,
    uint Set,
    ReadOnlyMemory<DescriptorBindingDesc> Bindings);

public readonly record struct DescriptorWrite(
    uint Binding,
    uint ArrayElement,
    DescriptorValue Value);

public readonly record struct DescriptorValue(
    DescriptorType Type,
    BufferViewHandle BufferView,
    TextureViewHandle TextureView,
    SamplerHandle Sampler)
{
    public bool IsNull => !BufferView.IsValid && !TextureView.IsValid && !Sampler.IsValid;

    public static DescriptorValue Null(DescriptorType type) => new(type, default, default, default);

    public static DescriptorValue ConstantBuffer(BufferViewHandle view) =>
        FromBufferView(DescriptorType.ConstantBuffer, view);

    public static DescriptorValue StructuredBuffer(BufferViewHandle view) =>
        FromBufferView(DescriptorType.StructuredBuffer, view);

    public static DescriptorValue ByteAddressBuffer(BufferViewHandle view) =>
        FromBufferView(DescriptorType.ByteAddressBuffer, view);

    public static DescriptorValue ReadWriteStructuredBuffer(BufferViewHandle view) =>
        FromBufferView(DescriptorType.ReadWriteStructuredBuffer, view);

    public static DescriptorValue ReadWriteByteAddressBuffer(BufferViewHandle view) =>
        FromBufferView(DescriptorType.ReadWriteByteAddressBuffer, view);

    public static DescriptorValue Texture(TextureViewHandle view) =>
        FromTextureView(DescriptorType.Texture, view);

    public static DescriptorValue ReadWriteTexture(TextureViewHandle view) =>
        FromTextureView(DescriptorType.ReadWriteTexture, view);

    public static DescriptorValue FromSampler(SamplerHandle sampler)
    {
        if (!sampler.IsValid)
            throw new ArgumentException("Sampler descriptor value requires a valid sampler handle.", nameof(sampler));

        return new DescriptorValue(DescriptorType.Sampler, default, default, sampler);
    }

    private static DescriptorValue FromBufferView(DescriptorType type, BufferViewHandle view)
    {
        if (!view.IsValid)
            throw new ArgumentException("Buffer descriptor value requires a valid buffer view handle.", nameof(view));

        return new DescriptorValue(type, view, default, default);
    }

    private static DescriptorValue FromTextureView(DescriptorType type, TextureViewHandle view)
    {
        if (!view.IsValid)
            throw new ArgumentException("Texture descriptor value requires a valid texture view handle.", nameof(view));

        return new DescriptorValue(type, default, view, default);
    }
}

public readonly record struct PushConstantRange(
    ShaderStageFlags Stages,
    ushort SizeInBytes);

public readonly record struct PipelineLayoutDesc(
    string? DebugName,
    ReadOnlyMemory<DescriptorSetLayoutHandle> Sets,
    PushConstantRange PushConstants);

public readonly record struct ResourcePlacement(
    ResourcePlacementKind Kind,
    MemoryUsage MemoryUsage,
    ResourceHeapHandle Heap,
    ulong HeapOffset)
{
    public static ResourcePlacement Committed(MemoryUsage memoryUsage) =>
        new(ResourcePlacementKind.Committed, memoryUsage, default, 0);

    public static ResourcePlacement Placed(
        MemoryUsage memoryUsage,
        ResourceHeapHandle heap,
        ulong heapOffset)
    {
        if (!heap.IsValid)
            throw new ArgumentException("Placed resource requires a valid resource heap handle.", nameof(heap));

        return new ResourcePlacement(ResourcePlacementKind.Placed, memoryUsage, heap, heapOffset);
    }
}

public readonly record struct ResourceHeapDesc(
    string? DebugName,
    MemoryUsage MemoryUsage,
    ulong SizeInBytes,
    ulong Alignment);

public readonly record struct ResourceMemoryRequirements(
    ulong SizeInBytes,
    ulong Alignment);

public readonly record struct BufferDesc(
    string? DebugName,
    ulong SizeInBytes,
    BufferUsageFlags Usage,
    ResourcePlacement Placement);

public readonly record struct TextureDesc(
    string? DebugName,
    TextureDimension Dimension,
    Format Format,
    uint Width,
    uint Height,
    ushort DepthOrArrayLayers,
    ushort MipLevels,
    ushort SampleCount,
    TextureUsageFlags Usage,
    ClearValue ClearValue,
    ResourcePlacement Placement);

public enum ClearValueKind : byte
{
    None,
    Color,
    DepthStencil,
}

public readonly record struct ClearValue(
    ClearValueKind Kind,
    Format Format,
    float R,
    float G,
    float B,
    float A,
    float Depth,
    byte Stencil)
{
    public static ClearValue None => default;

    public static ClearValue Color(Format format, float r, float g, float b, float a) =>
        new(ClearValueKind.Color, format, r, g, b, a, 0, 0);

    public static ClearValue DepthStencil(Format format, float depth, byte stencil = 0) =>
        new(ClearValueKind.DepthStencil, format, 0, 0, 0, 0, depth, stencil);
}

public readonly record struct BufferViewDesc(
    string? DebugName,
    BufferViewKind Kind,
    ulong Offset,
    ulong SizeInBytes,
    uint StrideInBytes);

public readonly record struct TextureViewDesc(
    string? DebugName,
    TextureViewKind Kind,
    Format Format,
    uint BaseMipLevel,
    uint MipLevelCount,
    uint BaseArrayLayer,
    uint ArrayLayerCount);

public readonly record struct SamplerDesc(
    string? DebugName,
    FilterMode MinFilter,
    FilterMode MagFilter,
    FilterMode MipFilter,
    TextureAddressMode AddressU,
    TextureAddressMode AddressV,
    TextureAddressMode AddressW,
    float MipLodBias,
    ushort MaxAnisotropy,
    CompareOp CompareOp,
    BorderColor BorderColor,
    float MinLod,
    float MaxLod);

public readonly record struct ShaderModuleDesc(
    string? DebugName,
    ShaderStage Stage,
    string EntryPoint,
    ReadOnlyMemory<byte> Bytecode,
    ShaderBytecodeFormat Format);

public readonly record struct ComputePipelineDesc(
    string? DebugName,
    PipelineLayoutHandle Layout,
    ShaderModuleHandle Shader);

public readonly record struct GraphicsPipelineDesc(
    string? DebugName,
    PipelineLayoutHandle Layout,
    ShaderModuleHandle VertexShader,
    ShaderModuleHandle PixelShader,
    ShaderModuleHandle GeometryShader,
    ShaderModuleHandle HullShader,
    ShaderModuleHandle DomainShader,
    ShaderModuleHandle AmplificationShader,
    ShaderModuleHandle MeshShader,
    ReadOnlyMemory<Format> ColorFormats,
    Format DepthStencilFormat,
    InputLayoutDesc InputLayout,
    PrimitiveTopology PrimitiveTopology,
    RasterizerDesc Rasterizer,
    DepthStencilDesc DepthStencil,
    BlendDesc Blend,
    ushort SampleCount);

public readonly record struct ColorAttachmentDesc(
    TextureViewHandle View,
    TextureViewHandle ResolveView,
    AttachmentLoadOp LoadOp,
    AttachmentStoreOp StoreOp,
    ClearValue ClearValue);

public readonly record struct DepthStencilAttachmentDesc(
    TextureViewHandle View,
    AttachmentLoadOp DepthLoadOp,
    AttachmentStoreOp DepthStoreOp,
    AttachmentLoadOp StencilLoadOp,
    AttachmentStoreOp StencilStoreOp,
    ClearValue ClearValue);

public readonly record struct RenderPassDesc(
    ReadOnlyMemory<ColorAttachmentDesc> ColorAttachments,
    DepthStencilAttachmentDesc DepthStencil,
    uint Width,
    uint Height);

public readonly record struct Viewport(
    float X,
    float Y,
    float Width,
    float Height,
    float MinDepth,
    float MaxDepth);

public readonly record struct ScissorRect(
    int X,
    int Y,
    int Width,
    int Height);

public readonly record struct VertexBufferBinding(
    BufferHandle Buffer,
    ulong Offset,
    uint Stride);

public readonly record struct BufferCopyRegion(
    BufferHandle Source,
    ulong SourceOffset,
    BufferHandle Destination,
    ulong DestinationOffset,
    ulong SizeInBytes);

public readonly record struct TextureCopyRegion(
    TextureHandle Source,
    uint SourceMipLevel,
    uint SourceArrayLayer,
    uint SourceX,
    uint SourceY,
    uint SourceZ,
    TextureHandle Destination,
    uint DestinationMipLevel,
    uint DestinationArrayLayer,
    uint DestinationX,
    uint DestinationY,
    uint DestinationZ,
    uint Width,
    uint Height,
    uint Depth);

public readonly record struct BufferTextureCopyRegion(
    BufferHandle Buffer,
    ulong BufferOffset,
    uint BufferRowPitch,
    uint BufferSlicePitch,
    TextureHandle Texture,
    uint MipLevel,
    uint ArrayLayer,
    uint X,
    uint Y,
    uint Z,
    uint Width,
    uint Height,
    uint Depth);

public readonly record struct MappedBuffer(
    BufferHandle Buffer,
    MapMode Mode,
    IntPtr CpuPointer,
    ulong SizeInBytes);

public readonly record struct MappedTexture(
    TextureHandle Texture,
    uint Subresource,
    MapMode Mode,
    IntPtr CpuPointer,
    ulong RowPitch,
    ulong SlicePitch);

public readonly record struct TextureCopyLayout(
    ulong Offset,
    ulong RowPitch,
    ulong SlicePitch,
    uint RowCount);

public readonly record struct SubresourceRange(
    uint BaseMipLevel,
    uint MipLevelCount,
    uint BaseArrayLayer,
    uint ArrayLayerCount)
{
    public static SubresourceRange All => new(0, uint.MaxValue, 0, uint.MaxValue);
}

public readonly record struct ResourceBarrier(
    ResourceBarrierKind Kind,
    BufferHandle Buffer,
    TextureHandle Texture,
    ResourceState Before,
    ResourceState After,
    SubresourceRange Subresources,
    BarrierFlags Flags,
    BufferHandle AliasingBeforeBuffer,
    TextureHandle AliasingBeforeTexture,
    BufferHandle AliasingAfterBuffer,
    TextureHandle AliasingAfterTexture)
{
    public static ResourceBarrier BufferTransition(
        BufferHandle buffer,
        ResourceState before,
        ResourceState after,
        BarrierFlags flags = BarrierFlags.None)
    {
        if (!buffer.IsValid)
            throw new ArgumentException("Buffer barrier requires a valid buffer handle.", nameof(buffer));

        return new ResourceBarrier(
            ResourceBarrierKind.Transition,
            buffer,
            default,
            before,
            after,
            SubresourceRange.All,
            flags,
            default,
            default,
            default,
            default);
    }

    public static ResourceBarrier TextureTransition(
        TextureHandle texture,
        ResourceState before,
        ResourceState after,
        BarrierFlags flags = BarrierFlags.None) =>
        TextureTransition(texture, before, after, SubresourceRange.All, flags);

    public static ResourceBarrier TextureTransition(
        TextureHandle texture,
        ResourceState before,
        ResourceState after,
        SubresourceRange subresources,
        BarrierFlags flags = BarrierFlags.None)
    {
        if (!texture.IsValid)
            throw new ArgumentException("Texture barrier requires a valid texture handle.", nameof(texture));

        return new ResourceBarrier(
            ResourceBarrierKind.Transition,
            default,
            texture,
            before,
            after,
            subresources,
            flags,
            default,
            default,
            default,
            default);
    }

    public static ResourceBarrier BufferUnorderedAccess(BufferHandle buffer)
    {
        if (!buffer.IsValid)
            throw new ArgumentException("UAV barrier requires a valid buffer handle.", nameof(buffer));

        return new ResourceBarrier(
            ResourceBarrierKind.UnorderedAccess,
            buffer,
            default,
            ResourceState.UnorderedAccess,
            ResourceState.UnorderedAccess,
            SubresourceRange.All,
            BarrierFlags.None,
            default,
            default,
            default,
            default);
    }

    public static ResourceBarrier TextureUnorderedAccess(TextureHandle texture)
    {
        if (!texture.IsValid)
            throw new ArgumentException("UAV barrier requires a valid texture handle.", nameof(texture));

        return new ResourceBarrier(
            ResourceBarrierKind.UnorderedAccess,
            default,
            texture,
            ResourceState.UnorderedAccess,
            ResourceState.UnorderedAccess,
            SubresourceRange.All,
            BarrierFlags.None,
            default,
            default,
            default,
            default);
    }

    public static ResourceBarrier BufferAliasing(BufferHandle before, BufferHandle after)
    {
        if (!before.IsValid && !after.IsValid)
            throw new ArgumentException("Aliasing barrier requires at least one valid buffer handle.");

        return new ResourceBarrier(
            ResourceBarrierKind.Aliasing,
            default,
            default,
            ResourceState.Unknown,
            ResourceState.Unknown,
            SubresourceRange.All,
            BarrierFlags.None,
            before,
            default,
            after,
            default);
    }

    public static ResourceBarrier TextureAliasing(TextureHandle before, TextureHandle after)
    {
        if (!before.IsValid && !after.IsValid)
            throw new ArgumentException("Aliasing barrier requires at least one valid texture handle.");

        return new ResourceBarrier(
            ResourceBarrierKind.Aliasing,
            default,
            default,
            ResourceState.Unknown,
            ResourceState.Unknown,
            SubresourceRange.All,
            BarrierFlags.None,
            default,
            before,
            default,
            after);
    }

    public static ResourceBarrier BufferToTextureAliasing(BufferHandle before, TextureHandle after)
    {
        if (!before.IsValid || !after.IsValid)
            throw new ArgumentException("Buffer-to-texture aliasing barrier requires valid before and after handles.");

        return new ResourceBarrier(
            ResourceBarrierKind.Aliasing,
            default,
            default,
            ResourceState.Unknown,
            ResourceState.Unknown,
            SubresourceRange.All,
            BarrierFlags.None,
            before,
            default,
            default,
            after);
    }

    public static ResourceBarrier TextureToBufferAliasing(TextureHandle before, BufferHandle after)
    {
        if (!before.IsValid || !after.IsValid)
            throw new ArgumentException("Texture-to-buffer aliasing barrier requires valid before and after handles.");

        return new ResourceBarrier(
            ResourceBarrierKind.Aliasing,
            default,
            default,
            ResourceState.Unknown,
            ResourceState.Unknown,
            SubresourceRange.All,
            BarrierFlags.None,
            default,
            before,
            after,
            default);
    }
}

public readonly record struct UploadSlice(
    BufferHandle Buffer,
    ulong Offset,
    ulong Size,
    IntPtr CpuPointer);

public readonly record struct ReadbackSlice(
    BufferHandle Buffer,
    ulong Offset,
    ulong Size,
    ulong FenceValue);
