using System;
using System.Runtime.CompilerServices;

namespace SomeEngine.RHI;

public abstract class Device : IDisposable
{
    public abstract BackendInfo BackendInfo { get; }
    public abstract DeviceLimits Limits { get; }

    public abstract Queue GetQueue(QueueKind kind);

    public abstract SwapChainHandle CreateSwapChain(Queue queue, in SwapChainDesc desc);
    public abstract SwapChainDesc GetSwapChainDesc(SwapChainHandle swapChain);
    public abstract void ResizeSwapChain(SwapChainHandle swapChain, uint width, uint height);
    public abstract uint GetCurrentBackBufferIndex(SwapChainHandle swapChain);
    public abstract TextureHandle GetSwapChainBackBuffer(SwapChainHandle swapChain, uint index);
    public abstract TextureViewHandle GetSwapChainBackBufferView(SwapChainHandle swapChain, uint index);
    public TextureHandle GetCurrentBackBuffer(SwapChainHandle swapChain) =>
        GetSwapChainBackBuffer(swapChain, GetCurrentBackBufferIndex(swapChain));

    public TextureViewHandle GetCurrentBackBufferView(SwapChainHandle swapChain) =>
        GetSwapChainBackBufferView(swapChain, GetCurrentBackBufferIndex(swapChain));

    public void Present(SwapChainHandle swapChain, uint syncInterval) =>
        Present(swapChain, new PresentOptions(syncInterval, AllowTearing: false, TestOnly: false));

    public abstract void Present(SwapChainHandle swapChain, in PresentOptions options);
    public abstract void DestroySwapChain(SwapChainHandle swapChain);

    public abstract DescriptorSetLayoutHandle CreateDescriptorSetLayout(in DescriptorSetLayoutDesc desc);
    public abstract void DestroyDescriptorSetLayout(DescriptorSetLayoutHandle layout);
    public abstract DescriptorSetHandle CreateDescriptorSet(DescriptorSetLayoutHandle layout, string? debugName);
    public abstract void DestroyDescriptorSet(DescriptorSetHandle set);
    public abstract void UpdateDescriptorSet(DescriptorSetHandle set, ReadOnlySpan<DescriptorWrite> writes);

    public abstract ResourceHeapHandle CreateResourceHeap(in ResourceHeapDesc desc);
    public abstract void DestroyResourceHeap(ResourceHeapHandle heap);

    public abstract ResourceMemoryRequirements GetBufferMemoryRequirements(in BufferDesc desc);
    public abstract BufferHandle CreateBuffer(in BufferDesc desc);
    public abstract BufferDesc GetBufferDesc(BufferHandle buffer);
    public abstract void DestroyBuffer(BufferHandle buffer);

    public abstract ResourceMemoryRequirements GetTextureMemoryRequirements(in TextureDesc desc);
    public abstract TextureHandle CreateTexture(in TextureDesc desc);
    public abstract TextureDesc GetTextureDesc(TextureHandle texture);
    public abstract void DestroyTexture(TextureHandle texture);

    public abstract BufferViewHandle CreateBufferView(BufferHandle buffer, in BufferViewDesc desc);
    public abstract BufferViewDesc GetBufferViewDesc(BufferViewHandle view);
    public abstract BufferViewHandle GetDefaultBufferView(BufferHandle buffer, BufferViewKind kind);
    public abstract void DestroyBufferView(BufferViewHandle view);

    public abstract TextureViewHandle CreateTextureView(TextureHandle texture, in TextureViewDesc desc);
    public abstract TextureViewDesc GetTextureViewDesc(TextureViewHandle view);
    public abstract TextureViewHandle GetDefaultTextureView(TextureHandle texture, TextureViewKind kind);
    public abstract void DestroyTextureView(TextureViewHandle view);

    public abstract SamplerHandle CreateSampler(in SamplerDesc desc);
    public abstract void DestroySampler(SamplerHandle sampler);

    public abstract ShaderModuleHandle CreateShaderModule(in ShaderModuleDesc desc);
    public abstract void DestroyShaderModule(ShaderModuleHandle shader);

    public abstract PipelineLayoutHandle CreatePipelineLayout(in PipelineLayoutDesc desc);
    public abstract void DestroyPipelineLayout(PipelineLayoutHandle layout);
    public abstract ComputePipelineHandle CreateComputePipeline(in ComputePipelineDesc desc);
    public abstract void DestroyComputePipeline(ComputePipelineHandle pipeline);
    public abstract GraphicsPipelineHandle CreateGraphicsPipeline(in GraphicsPipelineDesc desc);
    public abstract void DestroyGraphicsPipeline(GraphicsPipelineHandle pipeline);

    public abstract FenceHandle CreateFence(in FenceDesc desc);
    public abstract ulong GetFenceCompletedValue(FenceHandle fence);
    public abstract void WaitForFence(FenceHandle fence, ulong value, TimeSpan? timeout = null);
    public abstract void DestroyFence(FenceHandle fence);
    public abstract void SignalFence(Queue queue, FenceHandle fence, ulong value);
    public abstract void WaitIdle(Queue queue);
    public abstract void WaitIdle();

    public abstract QueryPoolHandle CreateQueryPool(in QueryPoolDesc desc);
    public abstract void DestroyQueryPool(QueryPoolHandle queryPool);
    public abstract ulong GetTimestampFrequency(Queue queue);

    public abstract CommandList BeginCommandList(Queue queue, string? debugName);
    public abstract void EndCommandList(CommandList commandList);
    public abstract void Submit(Queue queue, CommandList commandList, FenceHandle signalFence, ulong signalValue);

    public abstract MappedBuffer MapBuffer(BufferHandle buffer, MapMode mode, MapFlags flags);
    public abstract void UnmapBuffer(BufferHandle buffer);
    public abstract MappedTexture MapTexture(TextureHandle texture, uint subresource, MapMode mode, MapFlags flags);
    public abstract void UnmapTexture(TextureHandle texture, uint subresource);
    public abstract TextureCopyLayout GetTextureCopyLayout(TextureHandle texture, uint subresource);

    public abstract UploadSlice AllocateUpload(ulong size, ulong alignment);

    public UploadSlice AllocateUpload<T>(uint count = 1) where T : unmanaged
    {
        if (count == 0)
            throw new ArgumentOutOfRangeException(nameof(count), "Upload count must be greater than zero.");

        checked
        {
            uint elementSize = (uint)Unsafe.SizeOf<T>();
            return AllocateUpload(elementSize * (ulong)count, elementSize);
        }
    }

    public abstract ReadbackSlice AllocateReadback(ulong size, ulong alignment);
    public abstract ReadOnlySpan<byte> MapReadback(ReadbackSlice slice);

    public abstract void Dispose();
}

public sealed class Queue
{
    internal Queue(QueueHandle handle, string? debugName, object owner)
    {
        Handle = handle;
        DebugName = debugName;
        Owner = owner;
    }

    public QueueHandle Handle { get; }
    public string? DebugName { get; }
    internal object Owner { get; }
}

public sealed class SwapChain
{
    internal SwapChain(SwapChainHandle handle, string? debugName)
    {
        Handle = handle;
        DebugName = debugName;
    }

    public SwapChainHandle Handle { get; }
    public string? DebugName { get; }
}

public sealed class UploadRing
{
    internal UploadRing(BufferHandle buffer, ulong sizeInBytes)
    {
        Buffer = buffer;
        SizeInBytes = sizeInBytes;
    }

    public BufferHandle Buffer { get; }
    public ulong SizeInBytes { get; }
}

public sealed class ReadbackRing
{
    internal ReadbackRing(BufferHandle buffer, ulong sizeInBytes)
    {
        Buffer = buffer;
        SizeInBytes = sizeInBytes;
    }

    public BufferHandle Buffer { get; }
    public ulong SizeInBytes { get; }
}
